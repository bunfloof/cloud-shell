/*    */ package com.pty4j;
/*    */ 
/*    */ import com.pty4j.unix.Pty;
/*    */ import com.pty4j.unix.UnixPtyProcess;
/*    */ import com.pty4j.windows.WinPtyProcess;
/*    */ import com.sun.jna.Platform;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PtyProcess
/*    */   extends Process
/*    */ {
/*    */   public abstract boolean isRunning();
/*    */   
/*    */   public abstract void setWinSize(WinSize paramWinSize);
/*    */   
/*    */   public abstract WinSize getWinSize() throws IOException;
/*    */   
/*    */   public abstract int getPid();
/*    */   
/*    */   public static PtyProcess exec(String[] command) throws IOException {
/* 41 */     return exec(command, (Map<String, String>)null);
/*    */   }
/*    */   
/*    */   public static PtyProcess exec(String[] command, Map<String, String> environment) throws IOException {
/* 45 */     return exec(command, environment, null, false, false, null);
/*    */   }
/*    */   
/*    */   public static PtyProcess exec(String[] command, Map<String, String> environment, String workingDirectory) throws IOException {
/* 49 */     return exec(command, environment, workingDirectory, false, false, null);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static PtyProcess exec(String[] command, String[] environment) throws IOException {
/* 54 */     return exec(command, environment, (String)null, false);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static PtyProcess exec(String[] command, String[] environment, String workingDirectory, boolean console) throws IOException {
/* 59 */     if (Platform.isWindows()) {
/* 60 */       return (PtyProcess)new WinPtyProcess(command, environment, workingDirectory, console);
/*    */     }
/* 62 */     return (PtyProcess)new UnixPtyProcess(command, environment, workingDirectory, new Pty(console), console ? new Pty() : null);
/*    */   }
/*    */ 
/*    */   
/*    */   public static PtyProcess exec(String[] command, Map<String, String> environment, String workingDirectory, boolean console) throws IOException {
/* 67 */     return exec(command, environment, workingDirectory, console, false, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static PtyProcess exec(String[] command, Map<String, String> environment, String workingDirectory, boolean console, boolean cygwin, File logFile) throws IOException {
/* 77 */     PtyProcessBuilder builder = (new PtyProcessBuilder(command)).setEnvironment(environment).setDirectory(workingDirectory).setConsole(console).setCygwin(cygwin).setLogFile(logFile);
/* 78 */     return builder.start();
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4j\PtyProcess.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */