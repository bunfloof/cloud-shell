/*     */ package com.pty4j.windows;
/*     */ 
/*     */ import com.sun.jna.Memory;
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.platform.win32.Kernel32;
/*     */ import com.sun.jna.platform.win32.WinBase;
/*     */ import com.sun.jna.platform.win32.WinNT;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamedPipe
/*     */ {
/*     */   private WinNT.HANDLE myHandle;
/*     */   boolean myCloseHandleOnFinalize;
/*     */   private WinNT.HANDLE shutdownEvent;
/*     */   private volatile boolean shutdownFlag = false;
/*     */   private volatile boolean myFinalizedFlag = false;
/*  24 */   private ReentrantLock readLock = new ReentrantLock();
/*  25 */   private ReentrantLock writeLock = new ReentrantLock();
/*     */   
/*  27 */   private Memory readBuffer = new Memory(16384L);
/*  28 */   private Memory writeBuffer = new Memory(16384L);
/*     */   
/*     */   private WinNT.HANDLE readEvent;
/*     */   
/*     */   private WinNT.HANDLE writeEvent;
/*     */   
/*     */   private WinNT.HANDLE[] readWaitHandles;
/*     */   private WinNT.HANDLE[] writeWaitHandles;
/*  36 */   private IntByReference readActual = new IntByReference();
/*  37 */   private IntByReference writeActual = new IntByReference();
/*  38 */   private IntByReference peekActual = new IntByReference();
/*     */   
/*  40 */   private WinBase.OVERLAPPED readOver = new WinBase.OVERLAPPED();
/*  41 */   private WinBase.OVERLAPPED writeOver = new WinBase.OVERLAPPED();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NamedPipe(WinNT.HANDLE handle, boolean closeHandleOnFinalize) {
/*  49 */     this.myHandle = handle;
/*  50 */     this.myCloseHandleOnFinalize = closeHandleOnFinalize;
/*  51 */     this.shutdownEvent = Kernel32.INSTANCE.CreateEvent(null, true, false, null);
/*  52 */     this.readEvent = Kernel32.INSTANCE.CreateEvent(null, true, false, null);
/*  53 */     this.writeEvent = Kernel32.INSTANCE.CreateEvent(null, true, false, null);
/*  54 */     this.readWaitHandles = new WinNT.HANDLE[] { this.readEvent, this.shutdownEvent };
/*  55 */     this.writeWaitHandles = new WinNT.HANDLE[] { this.writeEvent, this.shutdownEvent };
/*     */   }
/*     */   
/*     */   public static NamedPipe connectToServer(String name, int desiredAccess) throws IOException {
/*  59 */     WinNT.HANDLE handle = Kernel32.INSTANCE.CreateFile(name, desiredAccess, 0, null, 3, 0, null);
/*     */     
/*  61 */     if (handle == WinBase.INVALID_HANDLE_VALUE) {
/*  62 */       throw new IOException("Error connecting to pipe '" + name + "': " + Native.getLastError());
/*     */     }
/*  64 */     return new NamedPipe(handle, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] buf, int off, int len) {
/*  72 */     if (buf == null) {
/*  73 */       throw new NullPointerException();
/*     */     }
/*  75 */     if (off < 0 || len < 0 || len > buf.length - off) {
/*  76 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  78 */     this.readLock.lock();
/*     */     try {
/*  80 */       if (this.shutdownFlag) {
/*  81 */         return -1;
/*     */       }
/*  83 */       if (len == 0) {
/*  84 */         return 0;
/*     */       }
/*  86 */       if (this.readBuffer.size() < len) {
/*  87 */         this.readBuffer = new Memory(len);
/*     */       }
/*  89 */       this.readOver.hEvent = this.readEvent;
/*  90 */       this.readOver.write();
/*  91 */       this.readActual.setValue(0);
/*  92 */       boolean success = WinPty.KERNEL32.ReadFile(this.myHandle, (Pointer)this.readBuffer, len, this.readActual, this.readOver.getPointer());
/*  93 */       if (!success && Native.getLastError() == 997) {
/*  94 */         int waitRet = Kernel32.INSTANCE.WaitForMultipleObjects(this.readWaitHandles.length, this.readWaitHandles, false, -1);
/*     */         
/*  96 */         if (waitRet != 0) {
/*  97 */           WinPty.KERNEL32.CancelIo(this.myHandle);
/*     */         }
/*  99 */         success = WinPty.KERNEL32.GetOverlappedResult(this.myHandle, this.readOver.getPointer(), this.readActual, true);
/*     */       } 
/* 101 */       int actual = this.readActual.getValue();
/* 102 */       if (!success || actual <= 0) {
/* 103 */         return -1;
/*     */       }
/* 105 */       this.readBuffer.read(0L, buf, off, actual);
/* 106 */       return actual;
/*     */     } finally {
/* 108 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] buf, int off, int len) {
/* 116 */     if (buf == null) {
/* 117 */       throw new NullPointerException();
/*     */     }
/* 119 */     if (off < 0 || len < 0 || len > buf.length - off) {
/* 120 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 122 */     this.writeLock.lock();
/*     */     try {
/* 124 */       if (this.shutdownFlag) {
/*     */         return;
/*     */       }
/* 127 */       if (len == 0) {
/*     */         return;
/*     */       }
/* 130 */       if (this.writeBuffer.size() < len) {
/* 131 */         this.writeBuffer = new Memory(len);
/*     */       }
/* 133 */       this.writeBuffer.write(0L, buf, off, len);
/* 134 */       this.writeOver.hEvent = this.writeEvent;
/* 135 */       this.writeOver.write();
/* 136 */       this.writeActual.setValue(0);
/* 137 */       boolean success = WinPty.KERNEL32.WriteFile(this.myHandle, (Pointer)this.writeBuffer, len, this.writeActual, this.writeOver.getPointer());
/* 138 */       if (!success && Native.getLastError() == 997) {
/* 139 */         int waitRet = Kernel32.INSTANCE.WaitForMultipleObjects(this.writeWaitHandles.length, this.writeWaitHandles, false, -1);
/*     */         
/* 141 */         if (waitRet != 0) {
/* 142 */           WinPty.KERNEL32.CancelIo(this.myHandle);
/*     */         }
/* 144 */         WinPty.KERNEL32.GetOverlappedResult(this.myHandle, this.writeOver.getPointer(), this.writeActual, true);
/*     */       } 
/*     */     } finally {
/* 147 */       this.writeLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public int available() throws IOException {
/* 152 */     this.readLock.lock();
/*     */     try {
/* 154 */       if (this.shutdownFlag) {
/* 155 */         return -1;
/*     */       }
/* 157 */       this.peekActual.setValue(0);
/* 158 */       if (!WinPty.KERNEL32.PeekNamedPipe(this.myHandle, null, 0, null, this.peekActual, null)) {
/* 159 */         throw new IOException("PeekNamedPipe failed");
/*     */       }
/* 161 */       return this.peekActual.getValue();
/*     */     } finally {
/* 163 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void markClosed() {
/* 171 */     closeImpl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void close() throws IOException {
/* 183 */     if (!closeImpl()) {
/*     */       return;
/*     */     }
/* 186 */     if (!Kernel32.INSTANCE.CloseHandle(this.myHandle)) {
/* 187 */       throw new IOException("Close error:" + Native.getLastError());
/*     */     }
/*     */   }
/*     */   
/*     */   private synchronized boolean closeImpl() {
/* 192 */     if (this.shutdownFlag)
/*     */     {
/* 194 */       return false;
/*     */     }
/* 196 */     this.shutdownFlag = true;
/* 197 */     Kernel32.INSTANCE.SetEvent(this.shutdownEvent);
/* 198 */     if (!this.myFinalizedFlag) {
/* 199 */       this.readLock.lock();
/* 200 */       this.writeLock.lock();
/* 201 */       this.writeLock.unlock();
/* 202 */       this.readLock.unlock();
/*     */     } 
/* 204 */     Kernel32.INSTANCE.CloseHandle(this.shutdownEvent);
/* 205 */     Kernel32.INSTANCE.CloseHandle(this.readEvent);
/* 206 */     Kernel32.INSTANCE.CloseHandle(this.writeEvent);
/* 207 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void finalize() throws Throwable {
/* 217 */     this.myFinalizedFlag = true;
/* 218 */     if (this.myCloseHandleOnFinalize) {
/* 219 */       close();
/*     */     }
/* 221 */     super.finalize();
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4j\windows\NamedPipe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */