/*     */ package com.pty4j.windows;
/*     */ 
/*     */ import com.pty4j.PtyProcess;
/*     */ import com.pty4j.WinSize;
/*     */ import com.pty4j.util.PtyUtil;
/*     */ import com.sun.jna.platform.win32.WinBase;
/*     */ import com.sun.jna.platform.win32.WinNT;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CygwinPtyProcess
/*     */   extends PtyProcess
/*     */ {
/*     */   private static final int CONNECT_PIPE_TIMEOUT = 1000;
/*     */   private static final int PIPE_ACCESS_INBOUND = 1;
/*     */   private static final int PIPE_ACCESS_OUTBOUND = 2;
/*  26 */   private static final AtomicInteger processCounter = new AtomicInteger();
/*     */   
/*     */   private final Process myProcess;
/*     */   
/*     */   private final NamedPipe myInputPipe;
/*     */   private final NamedPipe myOutputPipe;
/*     */   private final NamedPipe myErrorPipe;
/*     */   private final WinNT.HANDLE myInputHandle;
/*     */   private final WinNT.HANDLE myOutputHandle;
/*     */   private final WinNT.HANDLE myErrorHandle;
/*     */   
/*     */   public CygwinPtyProcess(String[] command, Map<String, String> environment, String workingDirectory, File logFile, boolean console) throws IOException {
/*  38 */     String pipePrefix = String.format("\\\\.\\pipe\\cygwinpty-%d-%d-", new Object[] { Integer.valueOf(WinPty.KERNEL32.GetCurrentProcessId()), Integer.valueOf(processCounter.getAndIncrement()) });
/*  39 */     String inPipeName = pipePrefix + "in";
/*  40 */     String outPipeName = pipePrefix + "out";
/*  41 */     String errPipeName = pipePrefix + "err";
/*     */     
/*  43 */     this.myInputHandle = WinPty.KERNEL32.CreateNamedPipeA(inPipeName, 1073741826, 0, 1, 0, 0, 0, null);
/*  44 */     this.myOutputHandle = WinPty.KERNEL32.CreateNamedPipeA(outPipeName, 1073741825, 0, 1, 0, 0, 0, null);
/*  45 */     this
/*  46 */       .myErrorHandle = console ? WinPty.KERNEL32.CreateNamedPipeA(errPipeName, 1073741825, 0, 1, 0, 0, 0, null) : null;
/*     */     
/*  48 */     if (this.myInputHandle == WinBase.INVALID_HANDLE_VALUE || this.myOutputHandle == WinBase.INVALID_HANDLE_VALUE || this.myErrorHandle == WinBase.INVALID_HANDLE_VALUE) {
/*     */ 
/*     */       
/*  51 */       closeHandles();
/*  52 */       throw new IOException("Unable to create a named pipe");
/*     */     } 
/*     */     
/*  55 */     this.myInputPipe = new NamedPipe(this.myInputHandle, false);
/*  56 */     this.myOutputPipe = new NamedPipe(this.myOutputHandle, false);
/*  57 */     this.myErrorPipe = (this.myErrorHandle != null) ? new NamedPipe(this.myErrorHandle, false) : null;
/*     */     
/*  59 */     this.myProcess = startProcess(inPipeName, outPipeName, errPipeName, workingDirectory, command, environment, logFile, console);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Process startProcess(String inPipeName, String outPipeName, String errPipeName, String workingDirectory, String[] command, Map<String, String> environment, File logFile, boolean console) throws IOException {
/*     */     File nativeFile;
/*     */     try {
/*  72 */       nativeFile = PtyUtil.resolveNativeFile("cyglaunch.exe");
/*  73 */     } catch (Exception e) {
/*  74 */       throw new IOException(e);
/*     */     } 
/*  76 */     String logPath = (logFile == null) ? "null" : logFile.getAbsolutePath();
/*     */     
/*  78 */     ProcessBuilder processBuilder = new ProcessBuilder(new String[] { nativeFile.getAbsolutePath(), logPath, console ? "1" : "0", inPipeName, outPipeName, errPipeName });
/*  79 */     for (String s : command) {
/*  80 */       processBuilder.command().add(s);
/*     */     }
/*  82 */     processBuilder.directory(new File(workingDirectory));
/*  83 */     processBuilder.environment().clear();
/*  84 */     processBuilder.environment().putAll(environment);
/*  85 */     final Process process = processBuilder.start();
/*     */     
/*     */     try {
/*  88 */       waitForPipe(this.myInputHandle);
/*  89 */       waitForPipe(this.myOutputHandle);
/*  90 */       if (this.myErrorHandle != null) waitForPipe(this.myErrorHandle); 
/*  91 */     } catch (IOException e) {
/*  92 */       process.destroy();
/*  93 */       closeHandles();
/*  94 */       throw e;
/*     */     } 
/*     */     
/*  97 */     (new Thread()
/*     */       {
/*     */         public void run() {
/*     */           while (true) {
/*     */             try {
/* 102 */               process.waitFor();
/*     */               
/*     */               break;
/* 105 */             } catch (InterruptedException interruptedException) {}
/*     */           } 
/*     */           
/* 108 */           CygwinPtyProcess.this.closePipes();
/*     */         }
/* 110 */       }).start();
/*     */     
/* 112 */     return process;
/*     */   }
/*     */   
/*     */   private static void waitForPipe(WinNT.HANDLE handle) throws IOException {
/* 116 */     WinNT.HANDLE connectEvent = WinPty.KERNEL32.CreateEventA(null, true, false, null);
/*     */     
/* 118 */     WinBase.OVERLAPPED povl = new WinBase.OVERLAPPED();
/* 119 */     povl.hEvent = connectEvent;
/*     */     
/* 121 */     boolean success = WinPty.KERNEL32.ConnectNamedPipe(handle, povl);
/* 122 */     if (!success) {
/* 123 */       switch (WinPty.KERNEL32.GetLastError()) {
/*     */         case 535:
/* 125 */           success = true;
/*     */           break;
/*     */         case 997:
/* 128 */           if (WinPty.KERNEL32.WaitForSingleObject(connectEvent, 1000) != 0) {
/* 129 */             WinPty.KERNEL32.CancelIo(handle);
/*     */             
/* 131 */             success = false;
/*     */             break;
/*     */           } 
/* 134 */           success = true;
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 141 */     WinPty.KERNEL32.CloseHandle(connectEvent);
/*     */     
/* 143 */     if (!success) throw new IOException("Cannot connect to a named pipe");
/*     */   
/*     */   }
/*     */   
/*     */   public boolean isRunning() {
/*     */     try {
/* 149 */       this.myProcess.exitValue();
/* 150 */       return false;
/* 151 */     } catch (IllegalThreadStateException e) {
/* 152 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWinSize(WinSize winSize) {
/* 158 */     throw new RuntimeException("Not implemented");
/*     */   }
/*     */ 
/*     */   
/*     */   public WinSize getWinSize() throws IOException {
/* 163 */     throw new RuntimeException("Not implemented");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPid() {
/* 169 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStream() {
/* 174 */     return new CygwinPTYOutputStream(this.myInputPipe);
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() {
/* 179 */     return new CygwinPTYInputStream(this.myOutputPipe);
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getErrorStream() {
/* 184 */     if (this.myErrorPipe == null) {
/* 185 */       return new InputStream()
/*     */         {
/*     */           public int read() throws IOException {
/* 188 */             return -1;
/*     */           }
/*     */         };
/*     */     }
/* 192 */     return new CygwinPTYInputStream(this.myErrorPipe);
/*     */   }
/*     */ 
/*     */   
/*     */   public int waitFor() throws InterruptedException {
/* 197 */     return this.myProcess.waitFor();
/*     */   }
/*     */ 
/*     */   
/*     */   public int exitValue() {
/* 202 */     return this.myProcess.exitValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 207 */     this.myProcess.destroy();
/*     */   }
/*     */   
/*     */   private void closeHandles() {
/* 211 */     WinPty.KERNEL32.CloseHandle(this.myInputHandle);
/* 212 */     WinPty.KERNEL32.CloseHandle(this.myOutputHandle);
/* 213 */     if (this.myErrorHandle != null) WinPty.KERNEL32.CloseHandle(this.myErrorHandle); 
/*     */   }
/*     */   
/*     */   private void closePipes() {
/* 217 */     this.myInputPipe.markClosed();
/* 218 */     this.myOutputPipe.markClosed();
/* 219 */     if (this.myErrorPipe != null) this.myErrorPipe.markClosed(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4j\windows\CygwinPtyProcess.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */