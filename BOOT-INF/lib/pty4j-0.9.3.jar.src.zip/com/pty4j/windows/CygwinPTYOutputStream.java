/*    */ package com.pty4j.windows;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CygwinPTYOutputStream
/*    */   extends OutputStream
/*    */ {
/*    */   private final NamedPipe myNamedPipe;
/*    */   private boolean myClosed;
/*    */   
/*    */   public CygwinPTYOutputStream(NamedPipe namedPipe) {
/* 18 */     this.myNamedPipe = namedPipe;
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(byte[] b, int off, int len) throws IOException {
/* 23 */     if (this.myClosed) {
/*    */       return;
/*    */     }
/*    */     
/* 27 */     if (b == null) {
/* 28 */       throw new NullPointerException();
/*    */     }
/* 30 */     if (off < 0 || off > b.length || len < 0 || off + len > b.length || off + len < 0) {
/* 31 */       throw new IndexOutOfBoundsException();
/*    */     }
/* 33 */     if (len == 0) {
/*    */       return;
/*    */     }
/*    */     
/* 37 */     this.myNamedPipe.write(b, off, len);
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(int b) throws IOException {
/* 42 */     byte[] buf = new byte[1];
/* 43 */     buf[0] = (byte)b;
/* 44 */     write(buf, 0, 1);
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() throws IOException {
/* 49 */     this.myClosed = true;
/* 50 */     this.myNamedPipe.close();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void finalize() throws Throwable {
/* 55 */     close();
/* 56 */     super.finalize();
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4j\windows\CygwinPTYOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */