/*     */ package com.pty4j.windows;
/*     */ 
/*     */ import com.pty4j.PtyException;
/*     */ import com.pty4j.PtyProcess;
/*     */ import com.pty4j.PtyProcessOptions;
/*     */ import com.pty4j.WinSize;
/*     */ import com.sun.jna.platform.win32.Advapi32Util;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WinPtyProcess
/*     */   extends PtyProcess
/*     */ {
/*     */   private final WinPty myWinPty;
/*     */   private final WinPTYInputStream myInputStream;
/*     */   private final InputStream myErrorStream;
/*     */   private final WinPTYOutputStream myOutputStream;
/*     */   private boolean myUsedInputStream = false;
/*     */   private boolean myUsedOutputStream = false;
/*     */   private boolean myUsedErrorStream = false;
/*     */   
/*     */   @Deprecated
/*     */   public WinPtyProcess(String[] command, String[] environment, String workingDirectory, boolean consoleMode) throws IOException {
/*  32 */     this(command, convertEnvironment(environment), workingDirectory, consoleMode);
/*     */   }
/*     */   
/*     */   private static String convertEnvironment(String[] environment) {
/*  36 */     StringBuilder envString = new StringBuilder();
/*  37 */     for (String s : environment) {
/*  38 */       envString.append(s).append(false);
/*     */     }
/*  40 */     envString.append(false);
/*  41 */     return envString.toString();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public WinPtyProcess(String[] command, String environment, String workingDirectory, boolean consoleMode) throws IOException {
/*  46 */     this(command, environment, workingDirectory, null, null, consoleMode, false);
/*     */   }
/*     */   
/*     */   public WinPtyProcess(@NotNull PtyProcessOptions options, boolean consoleMode) throws IOException {
/*  50 */     this(options.getCommand(), 
/*  51 */         convertEnvironment(options.getEnvironment()), options
/*  52 */         .getDirectory(), options
/*  53 */         .getInitialColumns(), options
/*  54 */         .getInitialRows(), consoleMode, options
/*     */         
/*  56 */         .isWindowsAnsiColorEnabled());
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   private static String convertEnvironment(@Nullable Map<String, String> environment) {
/*  61 */     return Advapi32Util.getEnvironmentBlock((environment != null) ? environment : Collections.emptyMap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WinPtyProcess(@NotNull String[] command, @NotNull String environment, @Nullable String workingDirectory, @Nullable Integer initialColumns, @Nullable Integer initialRows, boolean consoleMode, boolean enableAnsiColor) throws IOException {
/*     */     try {
/*  72 */       this.myWinPty = new WinPty(joinCmdArgs(command), workingDirectory, environment, consoleMode, initialColumns, initialRows, enableAnsiColor);
/*     */     }
/*  74 */     catch (PtyException e) {
/*  75 */       throw new IOException("Couldn't create PTY", e);
/*     */     } 
/*  77 */     this.myInputStream = new WinPTYInputStream(this.myWinPty, this.myWinPty.getInputPipe());
/*  78 */     this.myOutputStream = new WinPTYOutputStream(this.myWinPty, this.myWinPty.getOutputPipe(), consoleMode, true);
/*  79 */     if (!consoleMode) {
/*  80 */       this.myErrorStream = new InputStream()
/*     */         {
/*     */           public int read() {
/*  83 */             return -1;
/*     */           }
/*     */         };
/*     */     } else {
/*  87 */       this.myErrorStream = new WinPTYInputStream(this.myWinPty, this.myWinPty.getErrorPipe());
/*     */     } 
/*     */   }
/*     */   
/*     */   static String joinCmdArgs(String[] commands) {
/*  92 */     StringBuilder cmd = new StringBuilder();
/*  93 */     boolean flag = false;
/*  94 */     for (String s : commands) {
/*  95 */       if (flag) {
/*  96 */         cmd.append(' ');
/*     */       } else {
/*  98 */         flag = true;
/*     */       } 
/*     */       
/* 101 */       if (s.indexOf(' ') >= 0 || s.indexOf('\t') >= 0) {
/* 102 */         if (s.charAt(0) != '"') {
/* 103 */           cmd.append('"').append(s);
/*     */           
/* 105 */           if (s.endsWith("\\")) {
/* 106 */             cmd.append("\\");
/*     */           }
/* 108 */           cmd.append('"');
/*     */         } else {
/* 110 */           cmd.append(s);
/*     */         } 
/*     */       } else {
/* 113 */         cmd.append(s);
/*     */       } 
/*     */     } 
/*     */     
/* 117 */     return cmd.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRunning() {
/* 122 */     return this.myWinPty.isRunning();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWinSize(WinSize winSize) {
/* 127 */     this.myWinPty.setWinSize(winSize);
/*     */   }
/*     */ 
/*     */   
/*     */   public WinSize getWinSize() throws IOException {
/* 132 */     return this.myWinPty.getWinSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPid() {
/* 137 */     return this.myWinPty.getChildProcessId();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public String getWorkingDirectory() throws IOException {
/* 142 */     return this.myWinPty.getWorkingDirectory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getConsoleProcessCount() throws IOException {
/* 151 */     return this.myWinPty.getConsoleProcessList();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized OutputStream getOutputStream() {
/* 156 */     this.myUsedOutputStream = true;
/* 157 */     return this.myOutputStream;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized InputStream getInputStream() {
/* 162 */     this.myUsedInputStream = true;
/* 163 */     return this.myInputStream;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized InputStream getErrorStream() {
/* 168 */     this.myUsedErrorStream = true;
/* 169 */     return this.myErrorStream;
/*     */   }
/*     */ 
/*     */   
/*     */   public int waitFor() throws InterruptedException {
/* 174 */     return this.myWinPty.waitFor();
/*     */   }
/*     */   
/*     */   public int getChildProcessId() {
/* 178 */     return this.myWinPty.getChildProcessId();
/*     */   }
/*     */ 
/*     */   
/*     */   public int exitValue() {
/* 183 */     return this.myWinPty.exitValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void destroy() {
/* 188 */     this.myWinPty.close();
/*     */ 
/*     */     
/* 191 */     if (!this.myUsedInputStream) {
/*     */       try {
/* 193 */         this.myInputStream.close();
/* 194 */       } catch (IOException iOException) {}
/*     */     }
/* 196 */     if (!this.myUsedOutputStream) {
/*     */       try {
/* 198 */         this.myOutputStream.close();
/* 199 */       } catch (IOException iOException) {}
/*     */     }
/* 201 */     if (!this.myUsedErrorStream)
/*     */       try {
/* 203 */         this.myErrorStream.close();
/* 204 */       } catch (IOException iOException) {} 
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4j\windows\WinPtyProcess.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */