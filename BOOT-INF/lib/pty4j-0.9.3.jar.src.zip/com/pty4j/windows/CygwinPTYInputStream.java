/*    */ package com.pty4j.windows;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CygwinPTYInputStream
/*    */   extends InputStream
/*    */ {
/*    */   private final NamedPipe myNamedPipe;
/*    */   private boolean myClosed;
/*    */   
/*    */   public CygwinPTYInputStream(NamedPipe namedPipe) {
/* 19 */     this.myNamedPipe = namedPipe;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int read() throws IOException {
/* 29 */     byte[] b = new byte[1];
/* 30 */     if (1 != read(b, 0, 1)) {
/* 31 */       return -1;
/*    */     }
/* 33 */     return b[0];
/*    */   }
/*    */ 
/*    */   
/*    */   public int read(byte[] buf, int off, int len) throws IOException {
/* 38 */     if (this.myClosed) {
/* 39 */       return 0;
/*    */     }
/* 41 */     return this.myNamedPipe.read(buf, off, len);
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() throws IOException {
/* 46 */     this.myClosed = true;
/* 47 */     this.myNamedPipe.markClosed();
/*    */   }
/*    */ 
/*    */   
/*    */   public int available() throws IOException {
/* 52 */     return this.myNamedPipe.available();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void finalize() throws Throwable {
/* 57 */     close();
/* 58 */     super.finalize();
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4j\windows\CygwinPTYInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */