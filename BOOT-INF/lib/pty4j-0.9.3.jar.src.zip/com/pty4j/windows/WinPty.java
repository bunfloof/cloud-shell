/*     */ package com.pty4j.windows;
/*     */ 
/*     */ import com.pty4j.PtyException;
/*     */ import com.pty4j.WinSize;
/*     */ import com.pty4j.util.PtyUtil;
/*     */ import com.sun.jna.Library;
/*     */ import com.sun.jna.Memory;
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.WString;
/*     */ import com.sun.jna.platform.win32.Kernel32;
/*     */ import com.sun.jna.platform.win32.WinBase;
/*     */ import com.sun.jna.platform.win32.WinNT;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import com.sun.jna.ptr.PointerByReference;
/*     */ import java.io.IOException;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WinPty
/*     */ {
/*  27 */   private static final Logger LOG = Logger.getLogger(WinPty.class);
/*     */   
/*     */   private static final String SUPPORT_ANSI_IN_CONSOLE_MODE__SYS_PROP_NAME = "pty4j.win.support.ansi.in.console.mode";
/*     */   
/*  31 */   private static final boolean DEFAULT_MIN_INITIAL_TERMINAL_WINDOW_HEIGHT = !Boolean.getBoolean("disable.minimal.initial.terminal.window.height");
/*     */   
/*     */   private Pointer myWinpty;
/*     */   
/*  35 */   private WinNT.HANDLE myProcess = null;
/*     */   
/*     */   private NamedPipe myConinPipe;
/*     */   private NamedPipe myConoutPipe;
/*     */   private NamedPipe myConerrPipe;
/*     */   private boolean myChildExited = false;
/*  41 */   private int myStatus = -1;
/*     */   
/*     */   private boolean myClosed = false;
/*     */   private WinSize myLastWinSize;
/*  45 */   private int openInputStreamCount = 0;
/*     */   
/*     */   public WinPty(String cmdline, String cwd, String env, boolean consoleMode) throws PtyException, IOException {
/*  48 */     this(cmdline, cwd, env, consoleMode, null, null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   WinPty(@NotNull String cmdline, @Nullable String cwd, @NotNull String env, boolean consoleMode, @Nullable Integer initialColumns, @Nullable Integer initialRows, boolean enableAnsiColor) throws PtyException, IOException {
/*  58 */     int cols = ((initialColumns != null) ? initialColumns : Integer.getInteger("win.pty.cols", 80)).intValue();
/*  59 */     int rows = getInitialRows(initialRows);
/*  60 */     IntByReference errCode = new IntByReference();
/*  61 */     PointerByReference errPtr = new PointerByReference(null);
/*  62 */     Pointer agentCfg = null;
/*  63 */     Pointer spawnCfg = null;
/*  64 */     Pointer winpty = null;
/*  65 */     WinNT.HANDLEByReference processHandle = new WinNT.HANDLEByReference();
/*  66 */     NamedPipe coninPipe = null;
/*  67 */     NamedPipe conoutPipe = null;
/*  68 */     NamedPipe conerrPipe = null;
/*     */ 
/*     */     
/*     */     try {
/*  72 */       long agentFlags = 0L;
/*  73 */       if (consoleMode) {
/*  74 */         agentFlags |= 0x1L;
/*  75 */         if (!Boolean.getBoolean("pty4j.win.support.ansi.in.console.mode")) {
/*  76 */           agentFlags |= 0x2L;
/*     */         }
/*  78 */         if (enableAnsiColor) {
/*  79 */           agentFlags |= 0x4L;
/*     */         }
/*     */       } 
/*  82 */       agentCfg = INSTANCE.winpty_config_new(agentFlags, null);
/*  83 */       if (agentCfg == null) {
/*  84 */         throw new PtyException("winpty agent cfg is null");
/*     */       }
/*  86 */       INSTANCE.winpty_config_set_initial_size(agentCfg, cols, rows);
/*  87 */       this.myLastWinSize = new WinSize(cols, rows, 0, 0);
/*     */ 
/*     */       
/*  90 */       winpty = INSTANCE.winpty_open(agentCfg, errPtr);
/*  91 */       if (winpty == null) {
/*  92 */         WString errMsg = INSTANCE.winpty_error_msg(errPtr.getValue());
/*  93 */         throw new PtyException("Error starting winpty: " + errMsg.toString());
/*     */       } 
/*     */ 
/*     */       
/*  97 */       coninPipe = NamedPipe.connectToServer(INSTANCE.winpty_conin_name(winpty).toString(), 1073741824);
/*  98 */       conoutPipe = NamedPipe.connectToServer(INSTANCE.winpty_conout_name(winpty).toString(), -2147483648);
/*  99 */       if (consoleMode) {
/* 100 */         conerrPipe = NamedPipe.connectToServer(INSTANCE.winpty_conerr_name(winpty).toString(), -2147483648);
/*     */       }
/*     */       
/* 103 */       for (int i = 0; i < 5; i++) {
/* 104 */         boolean result = INSTANCE.winpty_set_size(winpty, cols, rows, null);
/* 105 */         if (!result) {
/* 106 */           LOG.info("Cannot resize to workaround extra newlines issue");
/*     */           break;
/*     */         } 
/*     */         try {
/* 110 */           Thread.sleep(10L);
/*     */         }
/* 112 */         catch (InterruptedException e) {
/* 113 */           e.printStackTrace();
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 118 */       spawnCfg = INSTANCE.winpty_spawn_config_new(3L, null, 
/*     */ 
/*     */ 
/*     */           
/* 122 */           toWString(cmdline), 
/* 123 */           toWString(cwd), 
/* 124 */           toWString(env), null);
/*     */       
/* 126 */       if (spawnCfg == null) {
/* 127 */         throw new PtyException("winpty spawn cfg is null");
/*     */       }
/* 129 */       if (!INSTANCE.winpty_spawn(winpty, spawnCfg, processHandle, null, errCode, errPtr)) {
/* 130 */         WString errMsg = INSTANCE.winpty_error_msg(errPtr.getValue());
/* 131 */         throw new PtyException("Error running process: " + errMsg.toString() + ". Code " + errCode.getValue());
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 136 */       this.myWinpty = winpty;
/* 137 */       this.myProcess = processHandle.getValue();
/* 138 */       this.myConinPipe = coninPipe;
/* 139 */       this.myConoutPipe = conoutPipe;
/* 140 */       this.myConerrPipe = conerrPipe;
/* 141 */       this.openInputStreamCount = consoleMode ? 2 : 1;
/*     */ 
/*     */       
/* 144 */       Thread waitForExit = new WaitForExitThread();
/* 145 */       waitForExit.setDaemon(true);
/* 146 */       waitForExit.start();
/*     */       
/* 148 */       winpty = null;
/* 149 */       processHandle.setValue(null);
/* 150 */       coninPipe = conoutPipe = conerrPipe = null;
/*     */     } finally {
/*     */       
/* 153 */       INSTANCE.winpty_error_free(errPtr.getValue());
/* 154 */       INSTANCE.winpty_config_free(agentCfg);
/* 155 */       INSTANCE.winpty_spawn_config_free(spawnCfg);
/* 156 */       INSTANCE.winpty_free(winpty);
/* 157 */       if (processHandle.getValue() != null) {
/* 158 */         Kernel32.INSTANCE.CloseHandle(processHandle.getValue());
/*     */       }
/* 160 */       closeNamedPipeQuietly(coninPipe);
/* 161 */       closeNamedPipeQuietly(conoutPipe);
/* 162 */       closeNamedPipeQuietly(conerrPipe);
/*     */     } 
/*     */   }
/*     */   
/*     */   private int getInitialRows(@Nullable Integer initialRows) {
/* 167 */     if (initialRows != null) {
/* 168 */       return initialRows.intValue();
/*     */     }
/* 170 */     Integer rows = Integer.getInteger("win.pty.rows");
/* 171 */     if (rows != null) {
/* 172 */       return rows.intValue();
/*     */     }
/*     */     try {
/* 175 */       WindowsVersion.getVersion();
/*     */       
/* 177 */       return DEFAULT_MIN_INITIAL_TERMINAL_WINDOW_HEIGHT ? 1 : 25;
/*     */     }
/* 179 */     catch (Exception e) {
/* 180 */       e.printStackTrace();
/* 181 */       return 25;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void closeNamedPipeQuietly(NamedPipe pipe) {
/*     */     try {
/* 187 */       if (pipe != null) {
/* 188 */         pipe.close();
/*     */       }
/* 190 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private static WString toWString(String string) {
/* 195 */     return (string == null) ? null : new WString(string);
/*     */   }
/*     */   
/*     */   public synchronized void setWinSize(WinSize winSize) {
/* 199 */     if (this.myClosed) {
/*     */       return;
/*     */     }
/* 202 */     boolean result = INSTANCE.winpty_set_size(this.myWinpty, winSize.ws_col, winSize.ws_row, null);
/* 203 */     if (result) {
/* 204 */       this.myLastWinSize = new WinSize(winSize.ws_col, winSize.ws_row, 0, 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public synchronized WinSize getWinSize() {
/* 211 */     WinSize size = this.myLastWinSize;
/* 212 */     if (this.myClosed || size == null) {
/* 213 */       return null;
/*     */     }
/* 215 */     return new WinSize(size.ws_col, size.ws_row, 0, 0);
/*     */   }
/*     */   
/*     */   synchronized void decrementOpenInputStreamCount() {
/* 219 */     this.openInputStreamCount--;
/* 220 */     if (this.openInputStreamCount == 0) {
/* 221 */       close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void close() {
/* 233 */     if (this.myClosed) {
/*     */       return;
/*     */     }
/* 236 */     INSTANCE.winpty_free(this.myWinpty);
/* 237 */     this.myWinpty = null;
/* 238 */     this.myClosed = true;
/* 239 */     closeUnusedProcessHandle();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void closeUnusedProcessHandle() {
/* 250 */     if (this.myClosed && this.myChildExited && this.myProcess != null) {
/* 251 */       Kernel32.INSTANCE.CloseHandle(this.myProcess);
/* 252 */       this.myProcess = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean isRunning() {
/* 260 */     return !this.myChildExited;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized int waitFor() throws InterruptedException {
/* 265 */     while (!this.myChildExited) {
/* 266 */       wait();
/*     */     }
/* 268 */     return this.myStatus;
/*     */   }
/*     */   
/*     */   public synchronized int getChildProcessId() {
/* 272 */     if (this.myClosed) {
/* 273 */       return -1;
/*     */     }
/* 275 */     return Kernel32.INSTANCE.GetProcessId(this.myProcess);
/*     */   }
/*     */   
/*     */   public synchronized int exitValue() {
/* 279 */     if (!this.myChildExited) {
/* 280 */       throw new IllegalThreadStateException("Process not Terminated");
/*     */     }
/* 282 */     return this.myStatus;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void finalize() throws Throwable {
/* 287 */     close();
/* 288 */     super.finalize();
/*     */   }
/*     */   
/*     */   public NamedPipe getInputPipe() {
/* 292 */     return this.myConoutPipe;
/*     */   }
/*     */   
/*     */   public NamedPipe getOutputPipe() {
/* 296 */     return this.myConinPipe;
/*     */   }
/*     */   
/*     */   public NamedPipe getErrorPipe() {
/* 300 */     return this.myConerrPipe;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   String getWorkingDirectory() throws IOException {
/* 305 */     if (this.myClosed) {
/* 306 */       return null;
/*     */     }
/* 308 */     int bufferLength = 1024;
/* 309 */     Memory memory = new Memory((Native.WCHAR_SIZE * bufferLength));
/* 310 */     PointerByReference errPtr = new PointerByReference();
/*     */     try {
/* 312 */       int result = INSTANCE.winpty_get_current_directory(this.myWinpty, bufferLength, (Pointer)memory, errPtr);
/* 313 */       if (result > 0) {
/* 314 */         return memory.getWideString(0L);
/*     */       }
/* 316 */       WString message = INSTANCE.winpty_error_msg(errPtr.getValue());
/* 317 */       int code = INSTANCE.winpty_error_code(errPtr.getValue());
/* 318 */       throw new IOException("winpty_get_current_directory failed, code: " + code + ", message: " + message);
/*     */     } finally {
/*     */       
/* 321 */       INSTANCE.winpty_error_free(errPtr.getValue());
/*     */     } 
/*     */   } static interface WinPtyLib extends Library {
/*     */     public static final long WINPTY_FLAG_CONERR = 1L; public static final long WINPTY_FLAG_PLAIN_OUTPUT = 2L; public static final long WINPTY_FLAG_COLOR_ESCAPES = 4L; public static final long WINPTY_SPAWN_FLAG_AUTO_SHUTDOWN = 1L; public static final long WINPTY_SPAWN_FLAG_EXIT_AFTER_SHUTDOWN = 2L; int winpty_error_code(Pointer param1Pointer); WString winpty_error_msg(Pointer param1Pointer); void winpty_error_free(Pointer param1Pointer); Pointer winpty_config_new(long param1Long, PointerByReference param1PointerByReference); void winpty_config_free(Pointer param1Pointer); void winpty_config_set_initial_size(Pointer param1Pointer, int param1Int1, int param1Int2); Pointer winpty_open(Pointer param1Pointer, PointerByReference param1PointerByReference); WString winpty_conin_name(Pointer param1Pointer); WString winpty_conout_name(Pointer param1Pointer); WString winpty_conerr_name(Pointer param1Pointer); Pointer winpty_spawn_config_new(long param1Long, WString param1WString1, WString param1WString2, WString param1WString3, WString param1WString4, PointerByReference param1PointerByReference); void winpty_spawn_config_free(Pointer param1Pointer); boolean winpty_spawn(Pointer param1Pointer1, Pointer param1Pointer2, WinNT.HANDLEByReference param1HANDLEByReference1, WinNT.HANDLEByReference param1HANDLEByReference2, IntByReference param1IntByReference, PointerByReference param1PointerByReference); boolean winpty_set_size(Pointer param1Pointer, int param1Int1, int param1Int2, PointerByReference param1PointerByReference); int winpty_get_console_process_list(Pointer param1Pointer1, Pointer param1Pointer2, int param1Int, PointerByReference param1PointerByReference); int winpty_get_current_directory(Pointer param1Pointer1, int param1Int, Pointer param1Pointer2, PointerByReference param1PointerByReference); void winpty_free(Pointer param1Pointer); }
/*     */   int getConsoleProcessList() throws IOException {
/* 326 */     if (this.myClosed) {
/* 327 */       return 0;
/*     */     }
/* 329 */     int MAX_COUNT = 64;
/* 330 */     Memory memory = new Memory((Native.LONG_SIZE * MAX_COUNT));
/* 331 */     PointerByReference errPtr = new PointerByReference();
/*     */     try {
/* 333 */       int actualProcessCount = INSTANCE.winpty_get_console_process_list(this.myWinpty, (Pointer)memory, MAX_COUNT, errPtr);
/* 334 */       if (actualProcessCount == 0) {
/* 335 */         WString message = INSTANCE.winpty_error_msg(errPtr.getValue());
/* 336 */         int code = INSTANCE.winpty_error_code(errPtr.getValue());
/* 337 */         throw new IOException("winpty_get_console_process_list failed, code: " + code + ", message: " + message);
/*     */       } 
/*     */       
/* 340 */       return actualProcessCount;
/*     */     } finally {
/*     */       
/* 343 */       INSTANCE.winpty_error_free(errPtr.getValue());
/*     */     } 
/*     */   } static interface Kern32 extends Library {
/*     */     boolean PeekNamedPipe(WinNT.HANDLE param1HANDLE, Pointer param1Pointer, int param1Int, IntByReference param1IntByReference1, IntByReference param1IntByReference2, IntByReference param1IntByReference3); boolean ReadFile(WinNT.HANDLE param1HANDLE, Pointer param1Pointer1, int param1Int, IntByReference param1IntByReference, Pointer param1Pointer2); boolean WriteFile(WinNT.HANDLE param1HANDLE, Pointer param1Pointer1, int param1Int, IntByReference param1IntByReference, Pointer param1Pointer2); boolean GetOverlappedResult(WinNT.HANDLE param1HANDLE, Pointer param1Pointer, IntByReference param1IntByReference, boolean param1Boolean);
/*     */     WinNT.HANDLE CreateNamedPipeA(String param1String, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, WinBase.SECURITY_ATTRIBUTES param1SECURITY_ATTRIBUTES);
/*     */     boolean ConnectNamedPipe(WinNT.HANDLE param1HANDLE, WinBase.OVERLAPPED param1OVERLAPPED);
/*     */     boolean CloseHandle(WinNT.HANDLE param1HANDLE);
/*     */     WinNT.HANDLE CreateEventA(WinBase.SECURITY_ATTRIBUTES param1SECURITY_ATTRIBUTES, boolean param1Boolean1, boolean param1Boolean2, String param1String);
/*     */     int GetLastError();
/*     */     int WaitForSingleObject(WinNT.HANDLE param1HANDLE, int param1Int);
/*     */     boolean CancelIo(WinNT.HANDLE param1HANDLE);
/*     */     int GetCurrentProcessId(); }
/* 355 */   private class WaitForExitThread extends Thread { private IntByReference myStatusByRef = new IntByReference(-1);
/*     */ 
/*     */     
/*     */     public void run() {
/* 359 */       Kernel32.INSTANCE.WaitForSingleObject(WinPty.this.myProcess, -1);
/* 360 */       Kernel32.INSTANCE.GetExitCodeProcess(WinPty.this.myProcess, this.myStatusByRef);
/* 361 */       synchronized (WinPty.this) {
/* 362 */         WinPty.this.myChildExited = true;
/* 363 */         WinPty.this.myStatus = this.myStatusByRef.getValue();
/* 364 */         WinPty.this.closeUnusedProcessHandle();
/* 365 */         WinPty.this.notifyAll();
/*     */       } 
/*     */     }
/*     */     
/*     */     private WaitForExitThread() {} }
/* 370 */   public static final Kern32 KERNEL32 = (Kern32)Native.loadLibrary("kernel32", Kern32.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 410 */   public static WinPtyLib INSTANCE = (WinPtyLib)Native.loadLibrary(getLibraryPath(), WinPtyLib.class);
/*     */   
/*     */   private static String getLibraryPath() {
/*     */     try {
/* 414 */       return PtyUtil.resolveNativeLibrary().getAbsolutePath();
/*     */     }
/* 416 */     catch (Exception e) {
/* 417 */       throw new IllegalStateException("Couldn't detect jar containing folder", e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4j\windows\WinPty.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */