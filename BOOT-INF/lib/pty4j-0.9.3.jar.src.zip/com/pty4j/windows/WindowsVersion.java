/*    */ package com.pty4j.windows;
/*    */ 
/*    */ import com.pty4j.util.LazyValue;
/*    */ import com.sun.jna.platform.win32.VerRsrc;
/*    */ import com.sun.jna.platform.win32.VersionUtil;
/*    */ import java.util.concurrent.Callable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ class WindowsVersion
/*    */ {
/* 13 */   private static final Logger LOG = Logger.getLogger(WindowsVersion.class);
/* 14 */   private static LazyValue<Version> myVersionValue = new LazyValue(new Callable<Version>()
/*    */       {
/*    */         public WindowsVersion.Version call() throws Exception {
/* 17 */           return WindowsVersion.getVersion();
/*    */         }
/*    */       });
/*    */   
/*    */   @NotNull
/*    */   public static Version getVersion() {
/*    */     try {
/* 24 */       VerRsrc.VS_FIXEDFILEINFO x = VersionUtil.getFileVersionInfo("kernel32.dll");
/* 25 */       Version version = new Version(x.getProductVersionMajor(), x.getProductVersionMinor(), x.getProductVersionRevision());
/* 26 */       LOG.info("Windows version: " + version);
/* 27 */       return version;
/*    */     }
/* 29 */     catch (Exception e) {
/* 30 */       LOG.info("Cannot get Windows version", e);
/*    */       
/* 32 */       return new Version(-1L, -1L, -1L);
/*    */     } 
/*    */   }
/*    */   static boolean isEqualTo(long majorVersion, long minorVersion, long buildNumber) {
/*    */     Version version;
/*    */     try {
/* 38 */       version = (Version)myVersionValue.getValue();
/*    */     }
/* 40 */     catch (Exception e) {
/* 41 */       throw new RuntimeException(e);
/*    */     } 
/* 43 */     return (majorVersion == version.myMajorVersion && minorVersion == version
/* 44 */       .myMinorVersion && buildNumber == version
/* 45 */       .myBuildNumber);
/*    */   }
/*    */   
/*    */   private static class Version
/*    */   {
/*    */     private final long myMajorVersion;
/*    */     private final long myMinorVersion;
/*    */     private final long myBuildNumber;
/*    */     
/*    */     Version(long majorVersion, long minorVersion, long buildNumber) {
/* 55 */       this.myMajorVersion = majorVersion;
/* 56 */       this.myMinorVersion = minorVersion;
/* 57 */       this.myBuildNumber = buildNumber;
/*    */     }
/*    */ 
/*    */     
/*    */     public String toString() {
/* 62 */       return this.myMajorVersion + "." + this.myMinorVersion + "." + this.myBuildNumber;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4j\windows\WindowsVersion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */