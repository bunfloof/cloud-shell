/*     */ package com.pty4j.unix.linux;
/*     */ 
/*     */ import com.pty4j.WinSize;
/*     */ import com.pty4j.unix.PtyHelpers;
/*     */ import com.sun.jna.Library;
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.NativeLong;
/*     */ import com.sun.jna.StringArray;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import jtermios.JTermios;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OSFacadeImpl
/*     */   implements PtyHelpers.OSFacade
/*     */ {
/*     */   private static long TIOCGWINSZ;
/*     */   private static long TIOCSWINSZ;
/*     */   
/*     */   static {
/*  94 */     String arch = System.getProperty("os.arch");
/*     */     
/*  96 */     if (arch.equals("ppc64le")) {
/*     */       
/*  98 */       TIOCGWINSZ = 1074295912L;
/*  99 */       TIOCSWINSZ = 2148037735L;
/*     */     } else {
/*     */       
/* 102 */       TIOCGWINSZ = 21523L;
/* 103 */       TIOCSWINSZ = 21524L;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 109 */   private static C_lib m_Clib = (C_lib)Native.loadLibrary("c", C_lib.class);
/*     */   
/* 111 */   private static Linux_Util_lib m_Utillib = (Linux_Util_lib)Native.loadLibrary("util", Linux_Util_lib.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OSFacadeImpl() {
/* 119 */     PtyHelpers.ONLCR = 4;
/*     */     
/* 121 */     PtyHelpers.VINTR = 0;
/* 122 */     PtyHelpers.VQUIT = 1;
/* 123 */     PtyHelpers.VERASE = 2;
/* 124 */     PtyHelpers.VKILL = 3;
/* 125 */     PtyHelpers.VSUSP = 10;
/* 126 */     PtyHelpers.VREPRINT = 12;
/* 127 */     PtyHelpers.VWERASE = 14;
/*     */     
/* 129 */     PtyHelpers.ECHOKE = 1;
/* 130 */     PtyHelpers.ECHOCTL = 64;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int execve(String command, String[] argv, String[] env) {
/* 137 */     StringArray argvp = (argv == null) ? new StringArray(new String[] { command }) : new StringArray(argv);
/* 138 */     StringArray envp = (env == null) ? null : new StringArray(env);
/* 139 */     return m_Clib.execve(command, argvp, envp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWinSize(int fd, WinSize winSize) {
/* 146 */     PtyHelpers.winsize ws = new PtyHelpers.winsize(); int r;
/* 147 */     if ((r = m_Clib.ioctl(fd, new NativeLong(TIOCGWINSZ), ws)) < 0) {
/* 148 */       return r;
/*     */     }
/* 150 */     ws.update(winSize);
/*     */     
/* 152 */     return r;
/*     */   }
/*     */ 
/*     */   
/*     */   public int kill(int pid, int signal) {
/* 157 */     return m_Clib.kill(pid, signal);
/*     */   }
/*     */ 
/*     */   
/*     */   public int setWinSize(int fd, WinSize winSize) {
/* 162 */     PtyHelpers.winsize ws = new PtyHelpers.winsize(winSize);
/* 163 */     return m_Clib.ioctl(fd, new NativeLong(TIOCSWINSZ), ws);
/*     */   }
/*     */ 
/*     */   
/*     */   public int waitpid(int pid, int[] stat, int options) {
/* 168 */     return m_Clib.waitpid(pid, stat, options);
/*     */   }
/*     */ 
/*     */   
/*     */   public int sigprocmask(int how, IntByReference set, IntByReference oldset) {
/* 173 */     return m_Clib.sigprocmask(how, set, oldset);
/*     */   }
/*     */ 
/*     */   
/*     */   public String strerror(int errno) {
/* 178 */     return m_Clib.strerror(errno);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getpt() {
/* 183 */     return JTermios.open("/dev/ptmx", JTermios.O_RDWR | JTermios.O_NOCTTY);
/*     */   }
/*     */ 
/*     */   
/*     */   public int grantpt(int fd) {
/* 188 */     return m_Clib.grantpt(fd);
/*     */   }
/*     */ 
/*     */   
/*     */   public int unlockpt(int fd) {
/* 193 */     return m_Clib.unlockpt(fd);
/*     */   }
/*     */ 
/*     */   
/*     */   public int close(int fd) {
/* 198 */     return m_Clib.close(fd);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ptsname(int fd) {
/* 203 */     return m_Clib.ptsname(fd);
/*     */   }
/*     */ 
/*     */   
/*     */   public int killpg(int pid, int sig) {
/* 208 */     return m_Clib.killpg(pid, sig);
/*     */   }
/*     */ 
/*     */   
/*     */   public int fork() {
/* 213 */     return m_Clib.fork();
/*     */   }
/*     */ 
/*     */   
/*     */   public int pipe(int[] pipe2) {
/* 218 */     return JTermios.pipe(pipe2);
/*     */   }
/*     */ 
/*     */   
/*     */   public int setsid() {
/* 223 */     return m_Clib.setsid();
/*     */   }
/*     */ 
/*     */   
/*     */   public void execv(String path, String[] argv) {
/* 228 */     StringArray argvp = (argv == null) ? new StringArray(new String[] { path }) : new StringArray(argv);
/* 229 */     m_Clib.execv(path, argvp);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getpid() {
/* 234 */     return m_Clib.getpid();
/*     */   }
/*     */ 
/*     */   
/*     */   public int setpgid(int pid, int pgid) {
/* 239 */     return m_Clib.setpgid(pid, pgid);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dup2(int fds, int fileno) {
/* 244 */     m_Clib.dup2(fds, fileno);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getppid() {
/* 249 */     return m_Clib.getppid();
/*     */   }
/*     */ 
/*     */   
/*     */   public void unsetenv(String s) {
/* 254 */     m_Clib.unsetenv(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public int login_tty(int fd) {
/* 259 */     return m_Utillib.login_tty(fd);
/*     */   }
/*     */ 
/*     */   
/*     */   public void chdir(String dirpath) {
/* 264 */     m_Clib.chdir(dirpath);
/*     */   }
/*     */   
/*     */   public static interface Linux_Util_lib extends Library {
/*     */     int login_tty(int param1Int);
/*     */   }
/*     */   
/*     */   public static interface C_lib extends Library {
/*     */     int execv(String param1String, StringArray param1StringArray);
/*     */     
/*     */     int execve(String param1String, StringArray param1StringArray1, StringArray param1StringArray2);
/*     */     
/*     */     int ioctl(int param1Int, NativeLong param1NativeLong, PtyHelpers.winsize param1winsize);
/*     */     
/*     */     int kill(int param1Int1, int param1Int2);
/*     */     
/*     */     int waitpid(int param1Int1, int[] param1ArrayOfint, int param1Int2);
/*     */     
/*     */     int sigprocmask(int param1Int, IntByReference param1IntByReference1, IntByReference param1IntByReference2);
/*     */     
/*     */     String strerror(int param1Int);
/*     */     
/*     */     int grantpt(int param1Int);
/*     */     
/*     */     int unlockpt(int param1Int);
/*     */     
/*     */     int close(int param1Int);
/*     */     
/*     */     String ptsname(int param1Int);
/*     */     
/*     */     int open(String param1String, int param1Int);
/*     */     
/*     */     int killpg(int param1Int1, int param1Int2);
/*     */     
/*     */     int fork();
/*     */     
/*     */     int setsid();
/*     */     
/*     */     int getpid();
/*     */     
/*     */     int setpgid(int param1Int1, int param1Int2);
/*     */     
/*     */     void dup2(int param1Int1, int param1Int2);
/*     */     
/*     */     int getppid();
/*     */     
/*     */     void unsetenv(String param1String);
/*     */     
/*     */     void chdir(String param1String);
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4\\unix\linux\OSFacadeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */