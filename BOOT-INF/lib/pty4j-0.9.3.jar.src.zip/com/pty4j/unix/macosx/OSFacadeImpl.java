/*     */ package com.pty4j.unix.macosx;
/*     */ 
/*     */ import com.pty4j.WinSize;
/*     */ import com.pty4j.unix.PtyHelpers;
/*     */ import com.sun.jna.Library;
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.NativeLong;
/*     */ import com.sun.jna.StringArray;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import jtermios.JTermios;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OSFacadeImpl
/*     */   implements PtyHelpers.OSFacade
/*     */ {
/*     */   private static final long TIOCGWINSZ = 1074295912L;
/*     */   private static final long TIOCSWINSZ = 2148037735L;
/*  91 */   private static MacOSX_C_lib m_Clib = (MacOSX_C_lib)Native.loadLibrary("c", MacOSX_C_lib.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OSFacadeImpl() {
/*  99 */     PtyHelpers.ONLCR = 2;
/*     */     
/* 101 */     PtyHelpers.VERASE = 3;
/* 102 */     PtyHelpers.VWERASE = 4;
/* 103 */     PtyHelpers.VKILL = 5;
/* 104 */     PtyHelpers.VREPRINT = 6;
/* 105 */     PtyHelpers.VINTR = 8;
/* 106 */     PtyHelpers.VQUIT = 9;
/* 107 */     PtyHelpers.VSUSP = 10;
/*     */     
/* 109 */     PtyHelpers.ECHOKE = 1;
/* 110 */     PtyHelpers.ECHOCTL = 64;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int execve(String command, String[] argv, String[] env) {
/* 117 */     StringArray argvp = (argv == null) ? new StringArray(new String[] { command }) : new StringArray(argv);
/* 118 */     StringArray envp = (env == null) ? null : new StringArray(env);
/* 119 */     return m_Clib.execve(command, argvp, envp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWinSize(int fd, WinSize winSize) {
/* 126 */     PtyHelpers.winsize ws = new PtyHelpers.winsize(); int r;
/* 127 */     if ((r = m_Clib.ioctl(fd, new NativeLong(1074295912L), ws)) < 0) {
/* 128 */       return r;
/*     */     }
/* 130 */     ws.update(winSize);
/*     */     
/* 132 */     return r;
/*     */   }
/*     */ 
/*     */   
/*     */   public int kill(int pid, int signal) {
/* 137 */     return m_Clib.kill(pid, signal);
/*     */   }
/*     */ 
/*     */   
/*     */   public int setWinSize(int fd, WinSize winSize) {
/* 142 */     PtyHelpers.winsize ws = new PtyHelpers.winsize(winSize);
/* 143 */     return m_Clib.ioctl(fd, new NativeLong(2148037735L), ws);
/*     */   }
/*     */ 
/*     */   
/*     */   public int waitpid(int pid, int[] stat, int options) {
/* 148 */     return m_Clib.waitpid(pid, stat, options);
/*     */   }
/*     */ 
/*     */   
/*     */   public int sigprocmask(int how, IntByReference set, IntByReference oldset) {
/* 153 */     return m_Clib.sigprocmask(how, set, oldset);
/*     */   }
/*     */ 
/*     */   
/*     */   public String strerror(int errno) {
/* 158 */     return m_Clib.strerror(errno);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getpt() {
/* 163 */     return JTermios.open("/dev/ptmx", JTermios.O_RDWR | JTermios.O_NOCTTY);
/*     */   }
/*     */ 
/*     */   
/*     */   public int grantpt(int fd) {
/* 168 */     return m_Clib.grantpt(fd);
/*     */   }
/*     */ 
/*     */   
/*     */   public int unlockpt(int fd) {
/* 173 */     return m_Clib.unlockpt(fd);
/*     */   }
/*     */ 
/*     */   
/*     */   public int close(int fd) {
/* 178 */     return m_Clib.close(fd);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ptsname(int fd) {
/* 183 */     return m_Clib.ptsname(fd);
/*     */   }
/*     */ 
/*     */   
/*     */   public int killpg(int pid, int sig) {
/* 188 */     return m_Clib.killpg(pid, sig);
/*     */   }
/*     */ 
/*     */   
/*     */   public int fork() {
/* 193 */     return m_Clib.fork();
/*     */   }
/*     */ 
/*     */   
/*     */   public int pipe(int[] pipe2) {
/* 198 */     return JTermios.pipe(pipe2);
/*     */   }
/*     */ 
/*     */   
/*     */   public int setsid() {
/* 203 */     return m_Clib.setsid();
/*     */   }
/*     */ 
/*     */   
/*     */   public void execv(String path, String[] argv) {
/* 208 */     StringArray argvp = (argv == null) ? new StringArray(new String[] { path }) : new StringArray(argv);
/* 209 */     m_Clib.execv(path, argvp);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getpid() {
/* 214 */     return m_Clib.getpid();
/*     */   }
/*     */ 
/*     */   
/*     */   public int setpgid(int pid, int pgid) {
/* 219 */     return m_Clib.setpgid(pid, pgid);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dup2(int fds, int fileno) {
/* 224 */     m_Clib.dup2(fds, fileno);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getppid() {
/* 229 */     return m_Clib.getppid();
/*     */   }
/*     */ 
/*     */   
/*     */   public void unsetenv(String s) {
/* 234 */     m_Clib.unsetenv(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public int login_tty(int fd) {
/* 239 */     return m_Clib.login_tty(fd);
/*     */   }
/*     */ 
/*     */   
/*     */   public void chdir(String dirpath) {
/* 244 */     m_Clib.chdir(dirpath);
/*     */   }
/*     */   
/*     */   public static interface MacOSX_C_lib extends Library {
/*     */     int execv(String param1String, StringArray param1StringArray);
/*     */     
/*     */     int execve(String param1String, StringArray param1StringArray1, StringArray param1StringArray2);
/*     */     
/*     */     int ioctl(int param1Int, NativeLong param1NativeLong, PtyHelpers.winsize param1winsize);
/*     */     
/*     */     int kill(int param1Int1, int param1Int2);
/*     */     
/*     */     int waitpid(int param1Int1, int[] param1ArrayOfint, int param1Int2);
/*     */     
/*     */     int sigprocmask(int param1Int, IntByReference param1IntByReference1, IntByReference param1IntByReference2);
/*     */     
/*     */     String strerror(int param1Int);
/*     */     
/*     */     int grantpt(int param1Int);
/*     */     
/*     */     int unlockpt(int param1Int);
/*     */     
/*     */     int close(int param1Int);
/*     */     
/*     */     String ptsname(int param1Int);
/*     */     
/*     */     int open(String param1String, int param1Int);
/*     */     
/*     */     int killpg(int param1Int1, int param1Int2);
/*     */     
/*     */     int fork();
/*     */     
/*     */     int setsid();
/*     */     
/*     */     int getpid();
/*     */     
/*     */     int setpgid(int param1Int1, int param1Int2);
/*     */     
/*     */     void dup2(int param1Int1, int param1Int2);
/*     */     
/*     */     int getppid();
/*     */     
/*     */     void unsetenv(String param1String);
/*     */     
/*     */     int login_tty(int param1Int);
/*     */     
/*     */     void chdir(String param1String);
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4\\unix\macosx\OSFacadeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */