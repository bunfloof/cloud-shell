/*    */ package com.pty4j.unix;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PTYInputStream
/*    */   extends InputStream
/*    */ {
/*    */   Pty myPty;
/*    */   
/*    */   public PTYInputStream(Pty pty) {
/* 18 */     this.myPty = pty;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int read() throws IOException {
/* 28 */     byte[] b = new byte[1];
/* 29 */     if (1 != read(b, 0, 1)) {
/* 30 */       return -1;
/*    */     }
/* 32 */     return b[0];
/*    */   }
/*    */ 
/*    */   
/*    */   public int read(byte[] buf, int off, int len) throws IOException {
/* 37 */     if (buf == null) {
/* 38 */       throw new NullPointerException();
/*    */     }
/* 40 */     if (off < 0 || off > buf.length || len < 0 || off + len > buf.length || off + len < 0) {
/* 41 */       throw new IndexOutOfBoundsException();
/*    */     }
/* 43 */     if (len == 0) {
/* 44 */       return 0;
/*    */     }
/* 46 */     byte[] tmpBuf = new byte[len];
/* 47 */     len = this.myPty.read(tmpBuf, len);
/* 48 */     if (len <= 0) {
/* 49 */       return -1;
/*    */     }
/* 51 */     System.arraycopy(tmpBuf, 0, buf, off, len);
/*    */     
/* 53 */     return len;
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() throws IOException {
/* 58 */     this.myPty.close();
/*    */   }
/*    */ 
/*    */   
/*    */   public int available() throws IOException {
/* 63 */     if (this.myPty.isClosed()) {
/* 64 */       throw new IOException("File descriptor is closed");
/*    */     }
/* 66 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4\\unix\PTYInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */