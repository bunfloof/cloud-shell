/*     */ package com.pty4j.unix;
/*     */ 
/*     */ import com.google.common.base.MoreObjects;
/*     */ import com.pty4j.PtyProcess;
/*     */ import com.pty4j.PtyProcessOptions;
/*     */ import com.pty4j.WinSize;
/*     */ import com.pty4j.util.PtyUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Arrays;
/*     */ import jtermios.JTermios;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnixPtyProcess
/*     */   extends PtyProcess
/*     */ {
/*  25 */   public int NOOP = 0;
/*  26 */   public int SIGHUP = 1;
/*  27 */   public int SIGINT = 2;
/*  28 */   public int SIGKILL = 9;
/*  29 */   public int SIGTERM = 15;
/*  30 */   public int ENOTTY = 25;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   public int INT = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   public int CTRLC = 1000;
/*     */   
/*     */   private static final int SIGWINCH = 28;
/*  60 */   private int pid = 0;
/*     */   private int myStatus;
/*     */   private boolean isDone;
/*     */   private OutputStream out;
/*     */   private InputStream in;
/*     */   private InputStream err;
/*     */   private final Pty myPty;
/*     */   private final Pty myErrPty;
/*     */   
/*     */   @Deprecated
/*     */   public UnixPtyProcess(String[] cmdarray, String[] envp, String dir, Pty pty, Pty errPty) throws IOException {
/*  71 */     if (dir == null) {
/*  72 */       dir = ".";
/*     */     }
/*  74 */     if (pty == null) {
/*  75 */       throw new IOException("pty cannot be null");
/*     */     }
/*  77 */     this.myPty = pty;
/*  78 */     this.myErrPty = errPty;
/*  79 */     execInPty(cmdarray, envp, dir, pty, errPty);
/*     */   }
/*     */   
/*     */   public UnixPtyProcess(@NotNull PtyProcessOptions options, boolean consoleMode) throws IOException {
/*  83 */     this.myPty = new Pty(consoleMode);
/*  84 */     this.myErrPty = options.isRedirectErrorStream() ? null : (consoleMode ? new Pty() : null);
/*  85 */     String dir = (String)MoreObjects.firstNonNull(options.getDirectory(), ".");
/*  86 */     execInPty(options.getCommand(), PtyUtil.toStringArray(options.getEnvironment()), dir, this.myPty, this.myErrPty);
/*     */   }
/*     */   
/*     */   public Pty getPty() {
/*  90 */     return this.myPty;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void finalize() throws Throwable {
/*  95 */     closeUnusedStreams();
/*  96 */     super.finalize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized InputStream getInputStream() {
/* 104 */     if (null == this.in) {
/* 105 */       this.in = this.myPty.getInputStream();
/*     */     }
/* 107 */     return this.in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized OutputStream getOutputStream() {
/* 115 */     if (null == this.out) {
/* 116 */       this.out = this.myPty.getOutputStream();
/*     */     }
/* 118 */     return this.out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized InputStream getErrorStream() {
/* 126 */     if (null == this.err) {
/* 127 */       if (this.myErrPty == null || !this.myPty.isConsole()) {
/*     */ 
/*     */         
/* 130 */         this.err = new InputStream()
/*     */           {
/*     */             public int read() {
/* 133 */               return -1;
/*     */             }
/*     */           };
/*     */       } else {
/*     */         
/* 138 */         this.err = this.myErrPty.getInputStream();
/*     */       } 
/*     */     }
/* 141 */     return this.err;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int waitFor() throws InterruptedException {
/* 149 */     while (!this.isDone) {
/* 150 */       wait();
/*     */     }
/*     */     
/* 153 */     return this.myStatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int exitValue() {
/* 161 */     if (!this.isDone) {
/* 162 */       throw new IllegalThreadStateException("Process not Terminated");
/*     */     }
/* 164 */     return this.myStatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void destroy() {
/* 176 */     terminate();
/*     */     
/* 178 */     closeUnusedStreams();
/*     */ 
/*     */     
/* 181 */     if (!this.isDone) {
/*     */       try {
/* 183 */         wait(1000L);
/*     */       }
/* 185 */       catch (InterruptedException interruptedException) {}
/*     */     }
/*     */     
/* 188 */     if (!this.isDone) {
/* 189 */       kill();
/*     */     }
/*     */   }
/*     */   
/*     */   public int interrupt() {
/* 194 */     return Pty.raise(this.pid, this.INT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int interruptCTRLC() {
/* 201 */     return interrupt();
/*     */   }
/*     */   
/*     */   public int hangup() {
/* 205 */     return Pty.raise(this.pid, this.SIGHUP);
/*     */   }
/*     */   
/*     */   public int kill() {
/* 209 */     return Pty.raise(this.pid, this.SIGKILL);
/*     */   }
/*     */   
/*     */   public int terminate() {
/* 213 */     return Pty.raise(this.pid, this.SIGTERM);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRunning() {
/* 218 */     return (Pty.raise(this.pid, this.NOOP) == 0);
/*     */   }
/*     */   
/*     */   private void execInPty(String[] command, String[] environment, String workingDirectory, Pty pty, Pty errPty) throws IOException {
/* 222 */     String cmd = command[0];
/* 223 */     SecurityManager s = System.getSecurityManager();
/* 224 */     if (s != null) {
/* 225 */       s.checkExec(cmd);
/*     */     }
/* 227 */     if (environment == null) {
/* 228 */       environment = new String[0];
/*     */     }
/* 230 */     String slaveName = pty.getSlaveName();
/* 231 */     int masterFD = pty.getMasterFD();
/* 232 */     String errSlaveName = (errPty == null) ? null : errPty.getSlaveName();
/* 233 */     int errMasterFD = (errPty == null) ? -1 : errPty.getMasterFD();
/* 234 */     boolean console = pty.isConsole();
/*     */     
/* 236 */     Reaper reaper = new Reaper(command, environment, workingDirectory, slaveName, masterFD, errSlaveName, errMasterFD, console);
/*     */     
/* 238 */     reaper.setDaemon(true);
/* 239 */     reaper.start();
/*     */     
/* 241 */     synchronized (this) {
/* 242 */       while (this.pid == 0) {
/*     */         try {
/* 244 */           wait();
/*     */         }
/* 246 */         catch (InterruptedException e) {
/* 247 */           Thread.currentThread().interrupt();
/*     */         } 
/*     */       } 
/*     */       
/* 251 */       boolean init = Boolean.getBoolean("unix.pty.init");
/* 252 */       if (init) {
/* 253 */         int cols = Integer.getInteger("unix.pty.cols", 80).intValue();
/* 254 */         int rows = Integer.getInteger("unix.pty.rows", 25).intValue();
/* 255 */         WinSize size = new WinSize(cols, rows);
/*     */ 
/*     */ 
/*     */         
/* 259 */         boolean retry = true;
/* 260 */         for (int attempt = 0; attempt < 1000 && retry; attempt++) {
/* 261 */           retry = false;
/*     */           try {
/* 263 */             this.myPty.setTerminalSize(size);
/* 264 */           } catch (IllegalStateException e) {
/* 265 */             if (JTermios.errno() == this.ENOTTY)
/* 266 */               retry = true; 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 271 */     if (this.pid == -1) {
/* 272 */       throw new IOException("Exec_tty error:" + reaper.getErrorMessage(), reaper.getException());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void closeUnusedStreams() {
/*     */     try {
/* 299 */       if (null == this.err) {
/* 300 */         getErrorStream().close();
/*     */       }
/*     */     }
/* 303 */     catch (IOException iOException) {}
/*     */     
/*     */     try {
/* 306 */       if (null == this.in) {
/* 307 */         getInputStream().close();
/*     */       }
/*     */     }
/* 310 */     catch (IOException iOException) {}
/*     */     
/*     */     try {
/* 313 */       if (null == this.out) {
/* 314 */         getOutputStream().close();
/*     */       }
/*     */     }
/* 317 */     catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int exec(String[] cmd, String[] envp, String dirname, String slaveName, int masterFD, String errSlaveName, int errMasterFD, boolean console) throws IOException {
/* 323 */     int pid = -1;
/*     */     
/* 325 */     if (cmd == null) {
/* 326 */       return pid;
/*     */     }
/*     */     
/* 329 */     if (envp == null) {
/* 330 */       return pid;
/*     */     }
/*     */     
/* 333 */     return PtyHelpers.execPty(cmd[0], cmd, envp, dirname, slaveName, masterFD, errSlaveName, errMasterFD, console);
/*     */   }
/*     */   
/*     */   int waitFor(int processID) {
/* 337 */     return Pty.wait0(processID);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWinSize(WinSize winSize) {
/* 343 */     this.myPty.setTerminalSize(winSize);
/* 344 */     if (this.myErrPty != null) {
/* 345 */       this.myErrPty.setTerminalSize(winSize);
/*     */     }
/* 347 */     Pty.raise(this.pid, 28);
/*     */   }
/*     */ 
/*     */   
/*     */   public WinSize getWinSize() throws IOException {
/* 352 */     return this.myPty.getWinSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPid() {
/* 357 */     return this.pid;
/*     */   }
/*     */ 
/*     */   
/*     */   class Reaper
/*     */     extends Thread
/*     */   {
/*     */     private String[] myCommand;
/*     */     
/*     */     private String[] myEnv;
/*     */     private String myDir;
/*     */     private String mySlaveName;
/*     */     private int myMasterFD;
/*     */     private String myErrSlaveName;
/*     */     private int myErrMasterFD;
/*     */     private boolean myConsole;
/*     */     volatile Throwable myException;
/*     */     
/*     */     public Reaper(String[] command, String[] environment, String workingDirectory, String slaveName, int masterFD, String errSlaveName, int errMasterFD, boolean console) {
/* 376 */       super("PtyProcess Reaper for " + Arrays.toString((Object[])command));
/* 377 */       this.myCommand = command;
/* 378 */       this.myEnv = environment;
/* 379 */       this.myDir = workingDirectory;
/* 380 */       this.mySlaveName = slaveName;
/* 381 */       this.myMasterFD = masterFD;
/* 382 */       this.myErrSlaveName = errSlaveName;
/* 383 */       this.myErrMasterFD = errMasterFD;
/* 384 */       this.myConsole = console;
/* 385 */       this.myException = null;
/*     */     }
/*     */     
/*     */     int execute(String[] cmd, String[] env, String dir) throws IOException {
/* 389 */       return UnixPtyProcess.this.exec(cmd, env, dir, this.mySlaveName, this.myMasterFD, this.myErrSlaveName, this.myErrMasterFD, this.myConsole);
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       try {
/* 395 */         UnixPtyProcess.this.pid = execute(this.myCommand, this.myEnv, this.myDir);
/*     */       }
/* 397 */       catch (Exception e) {
/* 398 */         UnixPtyProcess.this.pid = -1;
/* 399 */         this.myException = e;
/*     */       } 
/*     */       
/* 402 */       synchronized (UnixPtyProcess.this) {
/* 403 */         UnixPtyProcess.this.notifyAll();
/*     */       } 
/* 405 */       if (UnixPtyProcess.this.pid != -1) {
/*     */         
/* 407 */         UnixPtyProcess.this.myStatus = UnixPtyProcess.this.waitFor(UnixPtyProcess.this.pid);
/* 408 */         synchronized (UnixPtyProcess.this) {
/* 409 */           UnixPtyProcess.this.isDone = true;
/* 410 */           UnixPtyProcess.this.notifyAll();
/*     */         } 
/* 412 */         UnixPtyProcess.this.myPty.breakRead();
/* 413 */         if (UnixPtyProcess.this.myErrPty != null) UnixPtyProcess.this.myErrPty.breakRead(); 
/*     */       } 
/*     */     }
/*     */     
/*     */     public String getErrorMessage() {
/* 418 */       return (this.myException != null) ? this.myException.getMessage() : "Unknown reason";
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public Throwable getException() {
/* 423 */       return this.myException;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4\\unix\UnixPtyProcess.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */