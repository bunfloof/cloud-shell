/*    */ package com.pty4j.unix;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PTYOutputStream
/*    */   extends OutputStream
/*    */ {
/*    */   Pty myPty;
/*    */   
/*    */   public PTYOutputStream(Pty pty) {
/* 17 */     this.myPty = pty;
/*    */   }
/*    */   
/*    */   public void write(byte[] b, int off, int len) throws IOException {
/* 21 */     if (b == null)
/* 22 */       throw new NullPointerException(); 
/* 23 */     if (off < 0 || off > b.length || len < 0 || off + len > b.length || off + len < 0)
/* 24 */       throw new IndexOutOfBoundsException(); 
/* 25 */     if (len == 0) {
/*    */       return;
/*    */     }
/* 28 */     byte[] tmpBuf = new byte[len];
/* 29 */     System.arraycopy(b, off, tmpBuf, off, len);
/* 30 */     this.myPty.write(tmpBuf, len);
/*    */   }
/*    */   
/*    */   public void write(int b) throws IOException {
/* 34 */     byte[] buf = new byte[1];
/* 35 */     buf[0] = (byte)b;
/* 36 */     write(buf, 0, 1);
/*    */   }
/*    */   
/*    */   public void close() throws IOException {
/* 40 */     this.myPty.close();
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4\\unix\PTYOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */