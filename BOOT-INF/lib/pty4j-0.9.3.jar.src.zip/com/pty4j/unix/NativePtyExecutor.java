/*    */ package com.pty4j.unix;
/*    */ 
/*    */ import com.sun.jna.Library;
/*    */ import com.sun.jna.Native;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ class NativePtyExecutor
/*    */   implements PtyExecutor
/*    */ {
/*    */   private final Pty4J myPty4j;
/*    */   
/*    */   NativePtyExecutor(@NotNull String libraryName) {
/* 14 */     this.myPty4j = (Pty4J)Native.loadLibrary(libraryName, Pty4J.class);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int execPty(String full_path, String[] argv, String[] envp, String dirpath, String pts_name, int fdm, String err_pts_name, int err_fdm, boolean console) {
/* 20 */     return this.myPty4j.exec_pty(full_path, argv, envp, dirpath, pts_name, fdm, err_pts_name, err_fdm, console);
/*    */   }
/*    */   
/*    */   public static interface Pty4J extends Library {
/*    */     int exec_pty(String param1String1, String[] param1ArrayOfString1, String[] param1ArrayOfString2, String param1String2, String param1String3, int param1Int1, String param1String4, int param1Int2, boolean param1Boolean);
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4\\unix\NativePtyExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */