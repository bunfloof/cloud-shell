/*     */ package com.pty4j.unix;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.pty4j.WinSize;
/*     */ import com.pty4j.unix.freebsd.OSFacadeImpl;
/*     */ import com.pty4j.unix.linux.OSFacadeImpl;
/*     */ import com.pty4j.unix.macosx.OSFacadeImpl;
/*     */ import com.pty4j.unix.openbsd.OSFacadeImpl;
/*     */ import com.pty4j.util.LazyValue;
/*     */ import com.pty4j.util.PtyUtil;
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.Platform;
/*     */ import com.sun.jna.Structure;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import java.io.File;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import jtermios.JTermios;
/*     */ import jtermios.Termios;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PtyHelpers
/*     */ {
/*  47 */   private static final Logger LOG = Logger.getLogger(PtyHelpers.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public static int ONLCR = 4;
/*     */   
/* 152 */   public static int VINTR = 0;
/* 153 */   public static int VQUIT = 1;
/* 154 */   public static int VERASE = 2;
/* 155 */   public static int VKILL = 3;
/* 156 */   public static int VSUSP = 10;
/* 157 */   public static int VREPRINT = 12;
/* 158 */   public static int VWERASE = 14;
/*     */   
/* 160 */   public static int ECHOCTL = 4096;
/* 161 */   public static int ECHOKE = 16384;
/* 162 */   public static int ECHOK = 4;
/*     */   
/* 164 */   public static int IMAXBEL = 8192;
/* 165 */   public static int HUPCL = 16384;
/*     */   
/* 167 */   public static int IUTF8 = 16384;
/*     */ 
/*     */   
/*     */   private static final int STDIN_FILENO = 0;
/*     */ 
/*     */   
/*     */   private static final int STDOUT_FILENO = 1;
/*     */ 
/*     */   
/*     */   private static final int STDERR_FILENO = 2;
/*     */   
/*     */   private static final int SIG_UNBLOCK = 2;
/*     */   
/* 180 */   public static int SIGHUP = 1;
/* 181 */   public static int SIGINT = 2;
/* 182 */   public static int SIGQUIT = 3;
/* 183 */   public static int SIGILL = 4;
/* 184 */   public static int SIGABORT = 6;
/* 185 */   public static int SIGFPE = 8;
/* 186 */   public static int SIGKILL = 9;
/* 187 */   public static int SIGSEGV = 11;
/* 188 */   public static int SIGPIPE = 13;
/* 189 */   public static int SIGALRM = 14;
/* 190 */   public static int SIGTERM = 15;
/* 191 */   public static int SIGCHLD = 20;
/*     */   
/* 193 */   public static int WNOHANG = 1;
/* 194 */   public static int WUNTRACED = 2;
/*     */   
/* 196 */   private static final LazyValue<OSFacade> OS_FACADE_VALUE = new LazyValue(new Callable<OSFacade>()
/*     */       {
/*     */         public PtyHelpers.OSFacade call() {
/* 199 */           if (Platform.isMac()) {
/* 200 */             return (PtyHelpers.OSFacade)new OSFacadeImpl();
/*     */           }
/* 202 */           if (Platform.isFreeBSD()) {
/* 203 */             return (PtyHelpers.OSFacade)new OSFacadeImpl();
/*     */           }
/* 205 */           if (Platform.isOpenBSD()) {
/* 206 */             return (PtyHelpers.OSFacade)new OSFacadeImpl();
/*     */           }
/* 208 */           if (Platform.isLinux() || Platform.isAndroid()) {
/* 209 */             return (PtyHelpers.OSFacade)new OSFacadeImpl();
/*     */           }
/* 211 */           if (Platform.isWindows()) {
/* 212 */             throw new IllegalArgumentException("WinPtyProcess should be used on Windows");
/*     */           }
/* 214 */           throw new RuntimeException("Pty4J has no support for OS " + System.getProperty("os.name"));
/*     */         }
/*     */       });
/*     */   
/* 218 */   private static final LazyValue<PtyExecutor> PTY_EXECUTOR_VALUE = new LazyValue(new Callable<PtyExecutor>()
/*     */       {
/*     */         public PtyExecutor call() throws Exception {
/* 221 */           File lib = PtyUtil.resolveNativeLibrary();
/* 222 */           return new NativePtyExecutor(lib.getAbsolutePath());
/*     */         }
/*     */       });
/*     */   
/*     */   static {
/*     */     try {
/* 228 */       getOsFacade();
/*     */     }
/* 230 */     catch (Throwable t) {
/* 231 */       LOG.error(t.getMessage(), t.getCause());
/*     */     } 
/*     */     try {
/* 234 */       getPtyExecutor();
/*     */     }
/* 236 */     catch (Throwable t) {
/* 237 */       LOG.error(t.getMessage(), t.getCause());
/*     */     } 
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   private static OSFacade getOsFacade() {
/*     */     try {
/* 244 */       return (OSFacade)OS_FACADE_VALUE.getValue();
/*     */     }
/* 246 */     catch (Throwable t) {
/* 247 */       throw new RuntimeException("Cannot load implementation of " + OSFacade.class, t);
/*     */     } 
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   private static PtyExecutor getPtyExecutor() {
/*     */     try {
/* 254 */       return (PtyExecutor)PTY_EXECUTOR_VALUE.getValue();
/*     */     }
/* 256 */     catch (Throwable t) {
/* 257 */       throw new RuntimeException("Cannot load native pty executor library", t);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static OSFacade getInstance() {
/* 262 */     return getOsFacade();
/*     */   }
/*     */   
/*     */   public static Termios createTermios() {
/* 266 */     Termios term = new Termios();
/*     */     
/* 268 */     boolean isUTF8 = true;
/* 269 */     term.c_iflag = JTermios.ICRNL | JTermios.IXON | JTermios.IXANY | IMAXBEL | JTermios.BRKINT | (isUTF8 ? IUTF8 : 0);
/* 270 */     term.c_oflag = JTermios.OPOST | ONLCR;
/* 271 */     term.c_cflag = JTermios.CREAD | JTermios.CS8 | HUPCL;
/* 272 */     term.c_lflag = JTermios.ICANON | JTermios.ISIG | JTermios.IEXTEN | JTermios.ECHO | JTermios.ECHOE | ECHOK | ECHOKE | ECHOCTL;
/*     */     
/* 274 */     term.c_cc[JTermios.VEOF] = CTRLKEY('D');
/*     */ 
/*     */     
/* 277 */     term.c_cc[VERASE] = Byte.MAX_VALUE;
/* 278 */     term.c_cc[VWERASE] = CTRLKEY('W');
/* 279 */     term.c_cc[VKILL] = CTRLKEY('U');
/* 280 */     term.c_cc[VREPRINT] = CTRLKEY('R');
/* 281 */     term.c_cc[VINTR] = CTRLKEY('C');
/* 282 */     term.c_cc[VQUIT] = 28;
/* 283 */     term.c_cc[VSUSP] = CTRLKEY('Z');
/*     */     
/* 285 */     term.c_cc[JTermios.VSTART] = CTRLKEY('Q');
/* 286 */     term.c_cc[JTermios.VSTOP] = CTRLKEY('S');
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 293 */     term.c_ispeed = JTermios.B38400;
/* 294 */     term.c_ospeed = JTermios.B38400;
/*     */     
/* 296 */     return term;
/*     */   }
/*     */   
/*     */   private static byte CTRLKEY(char c) {
/* 300 */     return (byte)((byte)c - 65 + 1);
/*     */   }
/*     */   
/*     */   private static int __sigbits(int __signo) {
/* 304 */     return (__signo > 32) ? 0 : (1 << __signo - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getWinSize(int fd, WinSize ws) {
/* 315 */     return getOsFacade().getWinSize(fd, ws);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isProcessAlive(int pid) {
/* 326 */     int[] stat = { -1 };
/* 327 */     int result = waitpid(pid, stat, WNOHANG);
/* 328 */     return (result == 0 && stat[0] < 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int setWinSize(int fd, WinSize ws) {
/* 339 */     return getOsFacade().setWinSize(fd, ws);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int signal(int pid, int signal) {
/* 352 */     return getOsFacade().kill(pid, signal);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int waitpid(int pid, int[] stat, int options) {
/* 365 */     return getOsFacade().waitpid(pid, stat, options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int errno() {
/* 374 */     return Native.getLastError();
/*     */   }
/*     */   
/*     */   public static String strerror() {
/* 378 */     return getOsFacade().strerror(errno());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int execve(String command, String[] argv, String[] env) {
/* 388 */     return getOsFacade().execve(command, argv, env);
/*     */   }
/*     */   
/*     */   public static void chdir(String dirpath) {
/* 392 */     getOsFacade().chdir(dirpath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] processArgv(String command, String[] arguments) {
/*     */     String[] argv;
/* 405 */     if (arguments == null) {
/* 406 */       argv = new String[] { command };
/*     */     
/*     */     }
/* 409 */     else if (!command.equals(arguments[0])) {
/* 410 */       argv = new String[arguments.length + 1];
/* 411 */       argv[0] = command;
/* 412 */       System.arraycopy(arguments, 0, argv, 1, arguments.length);
/*     */     } else {
/*     */       
/* 415 */       argv = Arrays.<String>copyOf(arguments, arguments.length);
/*     */     } 
/*     */     
/* 418 */     return argv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int execPty(String full_path, String[] argv, String[] envp, String dirpath, String pts_name, int fdm, String err_pts_name, int err_fdm, boolean console) {
/* 430 */     PtyExecutor executor = getPtyExecutor();
/* 431 */     return executor.execPty(full_path, argv, envp, dirpath, pts_name, fdm, err_pts_name, err_fdm, console);
/*     */   } public static interface OSFacade {
/*     */     int execve(String param1String, String[] param1ArrayOfString1, String[] param1ArrayOfString2); int getWinSize(int param1Int, WinSize param1WinSize); int kill(int param1Int1, int param1Int2); int setWinSize(int param1Int, WinSize param1WinSize); int waitpid(int param1Int1, int[] param1ArrayOfint, int param1Int2); int sigprocmask(int param1Int, IntByReference param1IntByReference1, IntByReference param1IntByReference2); String strerror(int param1Int); int getpt(); int grantpt(int param1Int); int unlockpt(int param1Int); int close(int param1Int); String ptsname(int param1Int); int killpg(int param1Int1, int param1Int2); int fork(); int pipe(int[] param1ArrayOfint); int setsid(); void execv(String param1String, String[] param1ArrayOfString); int getpid();
/*     */     int setpgid(int param1Int1, int param1Int2);
/*     */     void dup2(int param1Int1, int param1Int2);
/*     */     int getppid();
/*     */     void unsetenv(String param1String);
/*     */     int login_tty(int param1Int);
/*     */     void chdir(String param1String); }
/*     */   public static class winsize extends Structure { public short ws_row; public short ws_col;
/*     */     protected List getFieldOrder() {
/* 442 */       return Lists.newArrayList((Object[])new String[] { "ws_row", "ws_col", "ws_xpixel", "ws_ypixel" });
/*     */     }
/*     */     public short ws_xpixel; public short ws_ypixel;
/*     */     
/*     */     public winsize() {}
/*     */     
/*     */     public winsize(WinSize ws) {
/* 449 */       this.ws_row = ws.ws_row;
/* 450 */       this.ws_col = ws.ws_col;
/* 451 */       this.ws_xpixel = ws.ws_xpixel;
/* 452 */       this.ws_ypixel = ws.ws_ypixel;
/*     */     }
/*     */     
/*     */     public void update(WinSize winSize) {
/* 456 */       winSize.ws_col = this.ws_col;
/* 457 */       winSize.ws_row = this.ws_row;
/* 458 */       winSize.ws_xpixel = this.ws_xpixel;
/* 459 */       winSize.ws_ypixel = this.ws_ypixel;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4\\unix\PtyHelpers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */