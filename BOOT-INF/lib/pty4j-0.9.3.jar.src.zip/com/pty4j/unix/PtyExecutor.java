package com.pty4j.unix;

public interface PtyExecutor {
  int execPty(String paramString1, String[] paramArrayOfString1, String[] paramArrayOfString2, String paramString2, String paramString3, int paramInt1, String paramString4, int paramInt2, boolean paramBoolean);
}


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4\\unix\PtyExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */