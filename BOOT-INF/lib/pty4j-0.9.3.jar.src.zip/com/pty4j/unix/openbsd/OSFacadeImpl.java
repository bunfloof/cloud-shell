/*     */ package com.pty4j.unix.openbsd;
/*     */ 
/*     */ import com.pty4j.WinSize;
/*     */ import com.pty4j.unix.PtyHelpers;
/*     */ import com.sun.jna.Library;
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.NativeLong;
/*     */ import com.sun.jna.StringArray;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import jtermios.JTermios;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OSFacadeImpl
/*     */   implements PtyHelpers.OSFacade
/*     */ {
/*     */   private static final long TIOCGWINSZ = 1074295912L;
/*     */   private static final long TIOCSWINSZ = 2148037735L;
/*  99 */   private static OpenBSD_C_lib m_Clib = (OpenBSD_C_lib)Native.loadLibrary("c", OpenBSD_C_lib.class);
/* 100 */   private static OpenBSD_Util_lib m_Utillib = (OpenBSD_Util_lib)Native.loadLibrary("util", OpenBSD_Util_lib.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OSFacadeImpl() {
/* 108 */     PtyHelpers.ONLCR = 2;
/*     */     
/* 110 */     PtyHelpers.VERASE = 3;
/* 111 */     PtyHelpers.VWERASE = 4;
/* 112 */     PtyHelpers.VKILL = 5;
/* 113 */     PtyHelpers.VREPRINT = 6;
/* 114 */     PtyHelpers.VINTR = 8;
/* 115 */     PtyHelpers.VQUIT = 9;
/* 116 */     PtyHelpers.VSUSP = 10;
/*     */     
/* 118 */     PtyHelpers.ECHOKE = 1;
/* 119 */     PtyHelpers.ECHOCTL = 64;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int execve(String command, String[] argv, String[] env) {
/* 126 */     StringArray argvp = (argv == null) ? new StringArray(new String[] { command }) : new StringArray(argv);
/* 127 */     StringArray envp = (env == null) ? null : new StringArray(env);
/* 128 */     return m_Clib.execve(command, argvp, envp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWinSize(int fd, WinSize winSize) {
/* 135 */     PtyHelpers.winsize ws = new PtyHelpers.winsize(); int r;
/* 136 */     if ((r = m_Clib.ioctl(fd, new NativeLong(1074295912L), ws)) < 0) {
/* 137 */       return r;
/*     */     }
/* 139 */     ws.update(winSize);
/*     */     
/* 141 */     return r;
/*     */   }
/*     */ 
/*     */   
/*     */   public int kill(int pid, int signal) {
/* 146 */     return m_Clib.kill(pid, signal);
/*     */   }
/*     */ 
/*     */   
/*     */   public int setWinSize(int fd, WinSize winSize) {
/* 151 */     PtyHelpers.winsize ws = new PtyHelpers.winsize(winSize);
/* 152 */     return m_Clib.ioctl(fd, new NativeLong(2148037735L), ws);
/*     */   }
/*     */ 
/*     */   
/*     */   public int waitpid(int pid, int[] stat, int options) {
/* 157 */     return m_Clib.waitpid(pid, stat, options);
/*     */   }
/*     */ 
/*     */   
/*     */   public int sigprocmask(int how, IntByReference set, IntByReference oldset) {
/* 162 */     return m_Clib.sigprocmask(how, set, oldset);
/*     */   }
/*     */ 
/*     */   
/*     */   public String strerror(int errno) {
/* 167 */     return m_Clib.strerror(errno);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getpt() {
/* 172 */     return m_Clib.posix_openpt(JTermios.O_RDWR | JTermios.O_NOCTTY);
/*     */   }
/*     */ 
/*     */   
/*     */   public int grantpt(int fd) {
/* 177 */     return m_Clib.grantpt(fd);
/*     */   }
/*     */ 
/*     */   
/*     */   public int unlockpt(int fd) {
/* 182 */     return m_Clib.unlockpt(fd);
/*     */   }
/*     */ 
/*     */   
/*     */   public int close(int fd) {
/* 187 */     return m_Clib.close(fd);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ptsname(int fd) {
/* 192 */     return m_Clib.ptsname(fd);
/*     */   }
/*     */ 
/*     */   
/*     */   public int killpg(int pid, int sig) {
/* 197 */     return m_Clib.killpg(pid, sig);
/*     */   }
/*     */ 
/*     */   
/*     */   public int fork() {
/* 202 */     return m_Clib.fork();
/*     */   }
/*     */ 
/*     */   
/*     */   public int pipe(int[] pipe2) {
/* 207 */     return JTermios.pipe(pipe2);
/*     */   }
/*     */ 
/*     */   
/*     */   public int setsid() {
/* 212 */     return m_Clib.setsid();
/*     */   }
/*     */ 
/*     */   
/*     */   public void execv(String path, String[] argv) {
/* 217 */     StringArray argvp = (argv == null) ? new StringArray(new String[] { path }) : new StringArray(argv);
/* 218 */     m_Clib.execv(path, argvp);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getpid() {
/* 223 */     return m_Clib.getpid();
/*     */   }
/*     */ 
/*     */   
/*     */   public int setpgid(int pid, int pgid) {
/* 228 */     return m_Clib.setpgid(pid, pgid);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dup2(int fds, int fileno) {
/* 233 */     m_Clib.dup2(fds, fileno);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getppid() {
/* 238 */     return m_Clib.getppid();
/*     */   }
/*     */ 
/*     */   
/*     */   public void unsetenv(String s) {
/* 243 */     m_Clib.unsetenv(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public int login_tty(int fd) {
/* 248 */     return m_Utillib.login_tty(fd);
/*     */   }
/*     */ 
/*     */   
/*     */   public void chdir(String dirpath) {
/* 253 */     m_Clib.chdir(dirpath);
/*     */   }
/*     */   
/*     */   public static interface OpenBSD_Util_lib extends Library {
/*     */     int login_tty(int param1Int);
/*     */   }
/*     */   
/*     */   public static interface OpenBSD_C_lib extends Library {
/*     */     int posix_openpt(int param1Int);
/*     */     
/*     */     int execv(String param1String, StringArray param1StringArray);
/*     */     
/*     */     int execve(String param1String, StringArray param1StringArray1, StringArray param1StringArray2);
/*     */     
/*     */     int ioctl(int param1Int, NativeLong param1NativeLong, PtyHelpers.winsize param1winsize);
/*     */     
/*     */     int kill(int param1Int1, int param1Int2);
/*     */     
/*     */     int waitpid(int param1Int1, int[] param1ArrayOfint, int param1Int2);
/*     */     
/*     */     int sigprocmask(int param1Int, IntByReference param1IntByReference1, IntByReference param1IntByReference2);
/*     */     
/*     */     String strerror(int param1Int);
/*     */     
/*     */     int grantpt(int param1Int);
/*     */     
/*     */     int unlockpt(int param1Int);
/*     */     
/*     */     int close(int param1Int);
/*     */     
/*     */     String ptsname(int param1Int);
/*     */     
/*     */     int open(String param1String, int param1Int);
/*     */     
/*     */     int killpg(int param1Int1, int param1Int2);
/*     */     
/*     */     int fork();
/*     */     
/*     */     int setsid();
/*     */     
/*     */     int getpid();
/*     */     
/*     */     int setpgid(int param1Int1, int param1Int2);
/*     */     
/*     */     void dup2(int param1Int1, int param1Int2);
/*     */     
/*     */     int getppid();
/*     */     
/*     */     void unsetenv(String param1String);
/*     */     
/*     */     int login_tty(int param1Int);
/*     */     
/*     */     void chdir(String param1String);
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4\\unix\openbsd\OSFacadeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */