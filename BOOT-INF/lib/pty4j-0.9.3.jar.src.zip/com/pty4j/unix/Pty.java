/*     */ package com.pty4j.unix;
/*     */ 
/*     */ import com.pty4j.WinSize;
/*     */ import com.pty4j.util.Pair;
/*     */ import java.io.IOException;
/*     */ import java.util.Locale;
/*     */ import jtermios.FDSet;
/*     */ import jtermios.JTermios;
/*     */ import jtermios.Termios;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Pty
/*     */ {
/*     */   private final boolean myConsole;
/*     */   private String mySlaveName;
/*     */   private PTYInputStream myIn;
/*     */   private PTYOutputStream myOut;
/*  28 */   private final Object myFDLock = new Object();
/*  29 */   private final Object mySelectLock = new Object();
/*  30 */   private final int[] myPipe = new int[2];
/*     */   
/*     */   private volatile int myMaster;
/*     */   
/*     */   private static boolean setTerminalSizeErrorAlreadyLogged;
/*     */   
/*  36 */   private static final boolean useSelect = isOSXLessThanOrEqualTo106();
/*     */   
/*     */   private static boolean isOSXLessThanOrEqualTo106() {
/*  39 */     if (System.getProperty("os.name").toLowerCase(Locale.US).startsWith("mac")) {
/*  40 */       String version = System.getProperty("os.version").toLowerCase(Locale.US);
/*  41 */       String[] strings = version.split("\\.");
/*  42 */       if (strings.length > 1 && strings[0].equals("10") && Integer.valueOf(strings[1]).intValue() <= 6) return true; 
/*     */     } 
/*  44 */     return false;
/*     */   }
/*     */   
/*  47 */   private static final Object PTSNAME_LOCK = new Object();
/*     */   
/*     */   public Pty() throws IOException {
/*  50 */     this(false);
/*     */   }
/*     */   
/*     */   public Pty(boolean console) throws IOException {
/*  54 */     this.myConsole = console;
/*     */     
/*  56 */     Pair<Integer, String> masterSlave = openMaster(console);
/*  57 */     this.myMaster = ((Integer)masterSlave.first).intValue();
/*  58 */     this.mySlaveName = (String)masterSlave.second;
/*     */     
/*  60 */     if (this.mySlaveName == null) {
/*  61 */       throw new IOException("Util.exception.cannotCreatePty");
/*     */     }
/*     */     
/*  64 */     this.myIn = new PTYInputStream(this);
/*  65 */     this.myOut = new PTYOutputStream(this);
/*  66 */     JTermios.pipe(this.myPipe);
/*     */   }
/*     */   
/*     */   public String getSlaveName() {
/*  70 */     return this.mySlaveName;
/*     */   }
/*     */   
/*     */   public int getMasterFD() {
/*  74 */     return this.myMaster;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isConsole() {
/*  81 */     return this.myConsole;
/*     */   }
/*     */   
/*     */   public PTYOutputStream getOutputStream() {
/*  85 */     return this.myOut;
/*     */   }
/*     */   
/*     */   public PTYInputStream getInputStream() {
/*  89 */     return this.myIn;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public final void setTerminalSize(int width, int height) {
/*  94 */     setTerminalSize(new WinSize(width, height, 0, 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setTerminalSize(WinSize winSize) {
/*     */     try {
/* 112 */       int res = changeWindowSize(this.myMaster, winSize);
/* 113 */       if (res != 0) {
/* 114 */         throw new IllegalStateException("Can set new window size. ioctl returns " + res + ", errorno=" + JTermios.errno());
/*     */       }
/* 116 */     } catch (UnsatisfiedLinkError e) {
/* 117 */       if (!setTerminalSizeErrorAlreadyLogged) {
/* 118 */         setTerminalSizeErrorAlreadyLogged = true;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WinSize getWinSize() throws IOException {
/* 132 */     WinSize result = new WinSize();
/* 133 */     if (PtyHelpers.getWinSize(this.myMaster, result) < 0) {
/* 134 */       throw new IOException("Failed to get window size: " + PtyHelpers.errno());
/*     */     }
/* 136 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private Pair<Integer, String> ptyMasterOpen() {
/* 141 */     PtyHelpers.OSFacade m_jpty = PtyHelpers.getInstance();
/*     */     
/* 143 */     String name = "/dev/ptmx";
/*     */     
/* 145 */     int fdm = m_jpty.getpt();
/*     */     
/* 147 */     if (fdm < 0) {
/* 148 */       return Pair.create(Integer.valueOf(-1), name);
/*     */     }
/* 150 */     if (m_jpty.grantpt(fdm) < 0) {
/* 151 */       m_jpty.close(fdm);
/* 152 */       return Pair.create(Integer.valueOf(-2), name);
/*     */     } 
/* 154 */     if (m_jpty.unlockpt(fdm) < 0) {
/* 155 */       m_jpty.close(fdm);
/* 156 */       return Pair.create(Integer.valueOf(-3), name);
/*     */     } 
/*     */     
/* 159 */     String ptr = ptsname(m_jpty, fdm);
/*     */     
/* 161 */     if (ptr == null) {
/* 162 */       m_jpty.close(fdm);
/* 163 */       return Pair.create(Integer.valueOf(-4), name);
/*     */     } 
/* 165 */     return Pair.create(Integer.valueOf(fdm), ptr);
/*     */   }
/*     */   
/*     */   private static String ptsname(PtyHelpers.OSFacade m_jpty, int fdm) {
/* 169 */     synchronized (PTSNAME_LOCK) {
/*     */       
/* 171 */       return m_jpty.ptsname(fdm);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setNoEcho(int fd) {
/* 177 */     Termios stermios = new Termios();
/* 178 */     if (JTermios.tcgetattr(fd, stermios) < 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 183 */     stermios.c_lflag &= (JTermios.ECHO | JTermios.ECHOE | PtyHelpers.ECHOK | JTermios.ECHONL) ^ 0xFFFFFFFF;
/*     */ 
/*     */ 
/*     */     
/* 187 */     stermios.c_iflag |= JTermios.IGNCR;
/*     */     
/* 189 */     JTermios.tcsetattr(fd, JTermios.TCSANOW, stermios);
/*     */   }
/*     */   
/*     */   private Pair<Integer, String> openMaster(boolean console) {
/* 193 */     Pair<Integer, String> master = ptyMasterOpen();
/* 194 */     if (((Integer)master.first).intValue() >= 0)
/*     */     {
/* 196 */       if (console) {
/* 197 */         setNoEcho(((Integer)master.first).intValue());
/*     */       }
/*     */     }
/*     */     
/* 201 */     return master;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static int changeWindowsSize(int fd, int width, int height) {
/* 206 */     return changeWindowSize(fd, new WinSize(width, height));
/*     */   }
/*     */   
/*     */   private static int changeWindowSize(int fd, WinSize ws) {
/* 210 */     return PtyHelpers.getInstance().setWinSize(fd, ws);
/*     */   }
/*     */   
/*     */   public static int raise(int pid, int sig) {
/* 214 */     PtyHelpers.OSFacade m_jpty = PtyHelpers.getInstance();
/*     */     
/* 216 */     int status = m_jpty.killpg(pid, sig);
/*     */     
/* 218 */     if (status == -1) {
/* 219 */       status = m_jpty.kill(pid, sig);
/*     */     }
/*     */     
/* 222 */     return status;
/*     */   }
/*     */   
/*     */   public boolean isClosed() {
/* 226 */     return (this.myMaster == -1);
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 230 */     if (this.myMaster != -1) {
/* 231 */       synchronized (this.myFDLock) {
/* 232 */         if (this.myMaster != -1) {
/*     */           try {
/* 234 */             int status = close0(this.myMaster);
/* 235 */             if (status == -1) {
/* 236 */               throw new IOException("Close error");
/*     */             }
/*     */           } finally {
/* 239 */             this.myMaster = -1;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void finalize() throws Throwable {
/* 248 */     close();
/* 249 */     super.finalize();
/*     */   }
/*     */   
/*     */   private int close0(int fd) throws IOException {
/* 253 */     int ret = JTermios.close(fd);
/*     */     
/* 255 */     breakRead();
/*     */     
/* 257 */     synchronized (this.mySelectLock) {
/* 258 */       JTermios.close(this.myPipe[0]);
/* 259 */       JTermios.close(this.myPipe[1]);
/* 260 */       this.myPipe[0] = -1;
/* 261 */       this.myPipe[1] = -1;
/*     */     } 
/*     */     
/* 264 */     return ret;
/*     */   }
/*     */   
/*     */   void breakRead() {
/* 268 */     JTermios.write(this.myPipe[1], new byte[1], 1);
/*     */   }
/*     */   
/*     */   public static int wait0(int pid) {
/* 272 */     PtyHelpers.OSFacade m_jpty = PtyHelpers.getInstance();
/*     */     
/* 274 */     int[] status = new int[1];
/*     */     
/* 276 */     if (pid < 0) {
/* 277 */       return -1;
/*     */     }
/*     */ 
/*     */     
/* 281 */     while (m_jpty.waitpid(pid, status, 0) < 0 && 
/* 282 */       JTermios.errno() == JTermios.EINTR);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 289 */     if (WIFEXITED(status[0])) {
/* 290 */       return WEXITSTATUS(status[0]);
/*     */     }
/*     */     
/* 293 */     return status[0];
/*     */   }
/*     */   
/*     */   static int WEXITSTATUS(int status) {
/* 297 */     return status >> 8 & 0xFF;
/*     */   }
/*     */   
/*     */   static boolean WIFEXITED(int status) {
/* 301 */     return (_WSTATUS(status) == 0);
/*     */   }
/*     */   
/*     */   private static int _WSTATUS(int status) {
/* 305 */     return status & 0x7F;
/*     */   }
/*     */   int read(byte[] buf, int len) throws IOException {
/*     */     boolean haveBytes;
/* 309 */     int fd = this.myMaster;
/* 310 */     if (fd == -1) return -1;
/*     */ 
/*     */     
/* 313 */     synchronized (this.mySelectLock) {
/* 314 */       if (this.myPipe[0] == -1) return -1;
/*     */       
/* 316 */       haveBytes = useSelect ? select(this.myPipe[0], fd) : poll(this.myPipe[0], fd);
/*     */     } 
/*     */     
/* 319 */     return haveBytes ? JTermios.read(fd, buf, len) : -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean poll(int pipeFd, int fd) {
/* 324 */     int[] poll_fds = { pipeFd, JTermios.POLLIN, fd, JTermios.POLLIN };
/*     */     
/* 326 */     while (JTermios.poll(poll_fds, 2, -1) <= 0) {
/*     */       
/* 328 */       int errno = JTermios.errno();
/* 329 */       if (errno != JTermios.EAGAIN && errno != JTermios.EINTR) return false; 
/*     */     } 
/* 331 */     return ((poll_fds[3] >> 16 & JTermios.POLLIN) != 0);
/*     */   }
/*     */   
/*     */   private static boolean select(int pipeFd, int fd) {
/* 335 */     FDSet set = JTermios.newFDSet();
/*     */     
/* 337 */     JTermios.FD_SET(pipeFd, set);
/* 338 */     JTermios.FD_SET(fd, set);
/* 339 */     JTermios.select(Math.max(fd, pipeFd) + 1, set, null, null, null);
/*     */     
/* 341 */     return JTermios.FD_ISSET(fd, set);
/*     */   }
/*     */   
/*     */   int write(byte[] buf, int len) throws IOException {
/* 345 */     return JTermios.write(this.myMaster, buf, len);
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4\\unix\Pty.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */