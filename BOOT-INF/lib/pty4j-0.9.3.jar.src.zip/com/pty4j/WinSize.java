/*    */ package com.pty4j;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WinSize
/*    */ {
/*    */   public short ws_row;
/*    */   public short ws_col;
/*    */   public short ws_xpixel;
/*    */   public short ws_ypixel;
/*    */   
/*    */   public WinSize() {
/* 43 */     this(0, 0, 0, 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WinSize(int columns, int rows) {
/* 51 */     this(columns, rows, 0, 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WinSize(int columns, int rows, int width, int height) {
/* 60 */     this.ws_col = (short)columns;
/* 61 */     this.ws_row = (short)rows;
/* 62 */     this.ws_xpixel = (short)width;
/* 63 */     this.ws_ypixel = (short)height;
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4j\WinSize.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */