/*     */ package com.pty4j.util;
/*     */ 
/*     */ import com.google.common.base.Function;
/*     */ import com.google.common.collect.Lists;
/*     */ import com.pty4j.windows.WinPty;
/*     */ import com.sun.jna.Platform;
/*     */ import java.io.File;
/*     */ import java.net.URI;
/*     */ import java.security.CodeSource;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PtyUtil
/*     */ {
/*  20 */   public static final String OS_VERSION = System.getProperty("os.version").toLowerCase();
/*     */   
/*  22 */   private static final String PTY_LIB_FOLDER = System.getenv("PTY_LIB_FOLDER");
/*     */   public static final String PREFERRED_NATIVE_FOLDER_KEY = "pty4j.preferred.native.folder";
/*     */   
/*     */   public static String[] toStringArray(Map<String, String> environment) {
/*  26 */     if (environment == null) return new String[0]; 
/*  27 */     List<String> list = Lists.transform(Lists.newArrayList(environment.entrySet()), new Function<Map.Entry<String, String>, String>() {
/*     */           public String apply(Map.Entry<String, String> entry) {
/*  29 */             return (String)entry.getKey() + "=" + (String)entry.getValue();
/*     */           }
/*     */         });
/*  32 */     return list.<String>toArray(new String[list.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getJarContainingFolderPath(Class aclass) throws Exception {
/*     */     File jarFile;
/*  42 */     CodeSource codeSource = aclass.getProtectionDomain().getCodeSource();
/*     */ 
/*     */ 
/*     */     
/*  46 */     if (codeSource.getLocation() != null) {
/*  47 */       jarFile = new File(codeSource.getLocation().toURI());
/*     */     } else {
/*  49 */       String path = aclass.getResource(aclass.getSimpleName() + ".class").getPath();
/*     */       
/*  51 */       int startIndex = path.indexOf(":") + 1;
/*  52 */       int endIndex = path.indexOf("!");
/*  53 */       if (startIndex == -1 || endIndex == -1) {
/*  54 */         throw new IllegalStateException("Class " + aclass.getSimpleName() + " is located not within a jar: " + path);
/*     */       }
/*  56 */       String jarFilePath = path.substring(startIndex, endIndex);
/*  57 */       jarFilePath = (new URI(jarFilePath)).getPath();
/*  58 */       jarFile = new File(jarFilePath);
/*     */     } 
/*  60 */     return jarFile.getParentFile().getAbsolutePath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static String getPtyLibFolderPath() throws Exception {
/*  68 */     File file = getPreferredLibPtyFolder();
/*  69 */     return (file != null) ? file.getAbsolutePath() : null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static File getPreferredLibPtyFolder() {
/*  74 */     if (PTY_LIB_FOLDER != null) {
/*  75 */       System.err.println("WARN: PTY_LIB_FOLDER environment variable is deprecated and will not be used in future releases. Please set Java system property \"pty4j.preferred.native.folder\" instead.");
/*     */     }
/*     */ 
/*     */     
/*  79 */     String path = (PTY_LIB_FOLDER != null) ? PTY_LIB_FOLDER : System.getProperty("pty4j.preferred.native.folder");
/*  80 */     if (path != null) {
/*  81 */       File dir = new File(path);
/*  82 */       if (dir.isAbsolute() && dir.isDirectory()) {
/*  83 */         return dir;
/*     */       }
/*     */     } 
/*  86 */     return null;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public static File resolveNativeLibrary() throws Exception {
/*  91 */     return resolveNativeFile(getNativeLibraryName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static File resolveNativeLibrary(File parent) {
/*  99 */     return resolveNativeFileFromFS(parent, getNativeLibraryName());
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public static File resolveNativeFile(@NotNull String fileName) throws Exception {
/* 104 */     File preferredLibPtyFolder = getPreferredLibPtyFolder();
/* 105 */     if (preferredLibPtyFolder != null) {
/* 106 */       return resolveNativeFileFromFS(preferredLibPtyFolder, fileName);
/*     */     }
/*     */     
/*     */     try {
/* 110 */       File destDir = ExtractedNative.getInstance().getDestDir();
/* 111 */       return new File(destDir, fileName);
/*     */     }
/* 113 */     catch (Exception e) {
/* 114 */       Exception extractException = e;
/*     */       
/* 116 */       File jarParentFolder = new File(getJarContainingFolderPath(WinPty.class));
/* 117 */       File file = resolveNativeFileFromFS(jarParentFolder, fileName);
/* 118 */       if (!file.exists()) {
/* 119 */         file = resolveNativeFileFromFS(new File(jarParentFolder, "libpty"), fileName);
/*     */       }
/* 121 */       if (file.exists()) {
/* 122 */         return file;
/*     */       }
/* 124 */       throw extractException;
/*     */     } 
/*     */   }
/*     */   @NotNull
/*     */   private static File resolveNativeFileFromFS(@NotNull File libPtyFolder, @NotNull String fileName) {
/* 129 */     File platformFolder = new File(libPtyFolder, getPlatformFolderName());
/* 130 */     String prefix = getPlatformArchFolderName();
/* 131 */     if ((new File(libPtyFolder, prefix)).exists()) {
/* 132 */       return new File(new File(libPtyFolder, prefix), fileName);
/*     */     }
/* 134 */     return new File(new File(platformFolder, prefix), fileName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static File resolveNativeFile(File libPtyFolder, String fileName) {
/* 143 */     return resolveNativeFileFromFS(libPtyFolder, fileName);
/*     */   }
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   static String getPlatformArchFolderName() {
/* 149 */     if (isWinXp())
/* 150 */       return "xp"; 
/* 151 */     if (System.getProperty("os.arch").equals("ppc64le")) {
/* 152 */       return "ppc64le";
/*     */     }
/*     */     
/* 155 */     return Platform.is64Bit() ? "x86_64" : "x86";
/*     */   }
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   static String getPlatformFolderName() {
/*     */     String result;
/* 162 */     if (Platform.isMac()) {
/* 163 */       result = "macosx";
/* 164 */     } else if (Platform.isWindows()) {
/* 165 */       result = "win";
/* 166 */     } else if (Platform.isLinux() || Platform.isAndroid()) {
/* 167 */       result = "linux";
/* 168 */     } else if (Platform.isFreeBSD()) {
/* 169 */       result = "freebsd";
/* 170 */     } else if (Platform.isOpenBSD()) {
/* 171 */       result = "openbsd";
/*     */     } else {
/* 173 */       throw new IllegalStateException("Platform " + Platform.getOSType() + " is not supported");
/*     */     } 
/*     */     
/* 176 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getNativeLibraryName() {
/*     */     String result;
/* 182 */     if (Platform.isMac()) {
/* 183 */       result = "libpty.dylib";
/* 184 */     } else if (Platform.isWindows()) {
/* 185 */       result = "winpty.dll";
/* 186 */     } else if (Platform.isLinux() || Platform.isFreeBSD() || Platform.isOpenBSD() || Platform.isAndroid()) {
/* 187 */       result = "libpty.so";
/*     */     } else {
/* 189 */       throw new IllegalStateException("Platform " + Platform.getOSType() + " is not supported");
/*     */     } 
/*     */     
/* 192 */     return result;
/*     */   }
/*     */   
/*     */   private static boolean isWinXp() {
/* 196 */     return (Platform.isWindows() && (OS_VERSION.equals("5.1") || OS_VERSION.equals("5.2")));
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4\\util\PtyUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */