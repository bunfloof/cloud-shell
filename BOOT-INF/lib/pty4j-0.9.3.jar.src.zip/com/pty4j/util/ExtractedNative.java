/*     */ package com.pty4j.util;
/*     */ import com.google.common.base.MoreObjects;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.stream.Collector;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ class ExtractedNative {
/*  23 */   private static final Logger LOG = Logger.getLogger(ExtractedNative.class);
/*  24 */   static final String[] LOCATIONS = new String[] { "freebsd/x86/libpty.so", "freebsd/x86_64/libpty.so", "linux/x86/libpty.so", "linux/x86_64/libpty.so", "linux/ppc64le/libpty.so", "macosx/x86/libpty.dylib", "macosx/x86_64/libpty.dylib", "win/x86/winpty-agent.exe", "win/x86/winpty.dll", "win/x86_64/cyglaunch.exe", "win/x86_64/winpty-agent.exe", "win/x86_64/winpty.dll", "win/xp/winpty-agent.exe", "win/xp/winpty.dll" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String DEFAULT_RESOURCE_NAME_PREFIX = "resources/com/pty4j/native/";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   private static final ExtractedNative INSTANCE = new ExtractedNative();
/*     */   private String myPlatformFolderName;
/*     */   private String myArchFolderName;
/*     */   private String myResourceNamePrefix;
/*     */   private boolean myInitialized;
/*     */   private volatile File myDestDir;
/*     */   
/*     */   private ExtractedNative() {
/*  50 */     this(null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ExtractedNative(@Nullable String platformFolderName, @Nullable String archFolderName, @Nullable String resourceNamePrefix) {
/*  56 */     this.myPlatformFolderName = platformFolderName;
/*  57 */     this.myArchFolderName = archFolderName;
/*  58 */     this.myResourceNamePrefix = resourceNamePrefix;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public static ExtractedNative getInstance() {
/*  63 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   File getDestDir() {
/*  68 */     if (!this.myInitialized) {
/*  69 */       init();
/*     */     }
/*  71 */     return this.myDestDir;
/*     */   }
/*     */   
/*     */   private void init() {
/*     */     try {
/*  76 */       this.myPlatformFolderName = (String)MoreObjects.firstNonNull(this.myPlatformFolderName, PtyUtil.getPlatformFolderName());
/*  77 */       this.myArchFolderName = (String)MoreObjects.firstNonNull(this.myArchFolderName, PtyUtil.getPlatformArchFolderName());
/*  78 */       this.myResourceNamePrefix = (String)MoreObjects.firstNonNull(this.myResourceNamePrefix, "resources/com/pty4j/native/");
/*  79 */       synchronized (this) {
/*  80 */         if (!this.myInitialized) {
/*  81 */           doInit();
/*     */         }
/*  83 */         this.myInitialized = true;
/*     */       } 
/*  85 */     } catch (Exception e) {
/*  86 */       throw new IllegalStateException("Cannot extract pty4j native " + this.myPlatformFolderName + "/" + this.myArchFolderName, e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void doInit() throws IOException {
/*  91 */     long startTimeNano = System.nanoTime();
/*  92 */     Path destDir = getOrCreateDestDir();
/*  93 */     if (LOG.isDebugEnabled()) {
/*  94 */       LOG.debug("Found " + destDir.toString() + " in " + pastTime(startTimeNano));
/*     */     }
/*     */     
/*  97 */     List<Path> children = Files.list(destDir).collect((Collector)Collectors.toList());
/*  98 */     if (LOG.isDebugEnabled()) {
/*  99 */       LOG.debug("Listed files in " + pastTime(startTimeNano));
/*     */     }
/*     */     
/* 102 */     Map<String, Path> resourceToFileMap = new HashMap<String, Path>();
/* 103 */     for (Path child : children) {
/* 104 */       String resourceName = getResourceName(child.getFileName().toString());
/* 105 */       resourceToFileMap.put(resourceName, child);
/*     */     } 
/* 107 */     Set<String> bundledResourceNames = getBundledResourceNames();
/* 108 */     boolean upToDate = isUpToDate(bundledResourceNames, resourceToFileMap);
/* 109 */     if (LOG.isDebugEnabled()) {
/* 110 */       LOG.debug("Checked upToDate in " + pastTime(startTimeNano));
/*     */     }
/* 112 */     if (!upToDate) {
/* 113 */       for (Path child : children) {
/* 114 */         Files.delete(child);
/*     */       }
/* 116 */       if (LOG.isDebugEnabled()) {
/* 117 */         LOG.debug("Cleared directory in " + pastTime(startTimeNano));
/*     */       }
/* 119 */       for (String bundledResourceName : bundledResourceNames) {
/* 120 */         copy(bundledResourceName, destDir);
/*     */       }
/* 122 */       if (LOG.isDebugEnabled()) {
/* 123 */         LOG.debug("Copied " + bundledResourceNames + " in " + pastTime(startTimeNano));
/*     */       }
/*     */     } 
/* 126 */     this.myDestDir = destDir.toFile();
/* 127 */     LOG.info("Extracted pty4j native in " + pastTime(startTimeNano));
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   private Path getOrCreateDestDir() throws IOException {
/* 132 */     String staticParentDirPath = System.getProperty("pty4j.tmpdir");
/* 133 */     String prefix = "pty4j-" + this.myPlatformFolderName + "-" + this.myArchFolderName;
/* 134 */     if (staticParentDirPath != null && !staticParentDirPath.trim().isEmpty()) {
/*     */ 
/*     */       
/* 137 */       Path staticParentDir = Paths.get(staticParentDirPath, new String[0]);
/* 138 */       if (staticParentDir.isAbsolute()) {
/* 139 */         Path staticDir = staticParentDir.resolve(prefix);
/* 140 */         if (Files.isDirectory(staticDir, new java.nio.file.LinkOption[0])) {
/* 141 */           return staticDir;
/*     */         }
/* 143 */         if (Files.isDirectory(staticParentDir, new java.nio.file.LinkOption[0])) {
/* 144 */           if (Files.exists(staticDir, new java.nio.file.LinkOption[0])) {
/* 145 */             Files.delete(staticDir);
/*     */           }
/* 147 */           return Files.createDirectory(staticDir, (FileAttribute<?>[])new FileAttribute[0]);
/*     */         } 
/*     */       } 
/*     */     } 
/* 151 */     Path tempDirectory = Files.createTempDirectory(prefix + "-", (FileAttribute<?>[])new FileAttribute[0]);
/* 152 */     tempDirectory.toFile().deleteOnExit();
/* 153 */     return tempDirectory;
/*     */   }
/*     */   
/*     */   private boolean isUpToDate(@NotNull Set<String> bundledResourceNames, @NotNull Map<String, Path> resourceToFileMap) {
/* 157 */     if (!bundledResourceNames.equals(resourceToFileMap.keySet())) {
/* 158 */       return false;
/*     */     }
/* 160 */     for (Map.Entry<String, Path> entry : resourceToFileMap.entrySet()) {
/*     */       try {
/* 162 */         URL bundledUrl = getBundledResourceUrl(entry.getKey());
/* 163 */         byte[] bundledContentChecksum = md5(bundledUrl.openStream());
/* 164 */         byte[] fileContentChecksum = md5(Files.newInputStream(entry.getValue(), new java.nio.file.OpenOption[0]));
/* 165 */         if (!Arrays.equals(bundledContentChecksum, fileContentChecksum)) {
/* 166 */           return false;
/*     */         }
/* 168 */       } catch (Exception e) {
/* 169 */         LOG.error("Cannot compare md5 checksums", e);
/* 170 */         return false;
/*     */       } 
/*     */     } 
/* 173 */     return true;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   private static byte[] md5(@NotNull InputStream in) throws IOException, NoSuchAlgorithmException {
/*     */     try {
/* 179 */       MessageDigest md5 = MessageDigest.getInstance("MD5");
/* 180 */       byte[] buffer = new byte[8192];
/*     */       int bufferSize;
/* 182 */       while ((bufferSize = in.read(buffer)) >= 0) {
/* 183 */         md5.update(buffer, 0, bufferSize);
/*     */       }
/* 185 */       return md5.digest();
/*     */     } finally {
/*     */       try {
/* 188 */         in.close();
/* 189 */       } catch (IOException e) {
/* 190 */         LOG.error("Cannot close", e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   private Set<String> getBundledResourceNames() {
/* 198 */     Set<String> resourceNames = new HashSet<String>();
/* 199 */     String prefix = this.myPlatformFolderName + "/" + this.myArchFolderName + "/";
/* 200 */     for (String location : LOCATIONS) {
/* 201 */       if (location.startsWith(prefix)) {
/* 202 */         resourceNames.add(this.myResourceNamePrefix + location);
/*     */       }
/*     */     } 
/* 205 */     return resourceNames;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   private String getResourceName(@NotNull String fileName) {
/* 210 */     return this.myResourceNamePrefix + this.myPlatformFolderName + "/" + this.myArchFolderName + "/" + fileName;
/*     */   }
/*     */   
/*     */   private void copy(@NotNull String resourceName, @NotNull Path destDir) throws IOException {
/* 214 */     URL url = getBundledResourceUrl(resourceName);
/* 215 */     int lastNameInd = resourceName.lastIndexOf('/');
/* 216 */     String name = (lastNameInd != -1) ? resourceName.substring(lastNameInd + 1) : resourceName;
/* 217 */     InputStream inputStream = url.openStream();
/*     */     
/*     */     try {
/* 220 */       Files.copy(inputStream, destDir.resolve(name), new java.nio.file.CopyOption[0]);
/*     */     } finally {
/*     */       
/* 223 */       inputStream.close();
/*     */     } 
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   private URL getBundledResourceUrl(@NotNull String resourceName) throws IOException {
/* 229 */     ClassLoader classLoader = ExtractedNative.class.getClassLoader();
/* 230 */     URL url = classLoader.getResource(resourceName);
/* 231 */     if (url == null) {
/* 232 */       ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
/* 233 */       if (contextClassLoader != null) {
/* 234 */         url = contextClassLoader.getResource(resourceName);
/*     */       }
/* 236 */       if (url == null) {
/* 237 */         throw new IOException("Unable to load " + resourceName);
/*     */       }
/*     */     } 
/* 240 */     return url;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   private static String pastTime(long startTimeNano) {
/* 245 */     return TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startTimeNano) + " ms";
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4\\util\ExtractedNative.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */