/*    */ package com.pty4j.util;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public final class LazyValue<T>
/*    */ {
/*    */   private final Callable<T> myProvider;
/*  9 */   private final Object myLock = new Object();
/*    */   private volatile Pair<T, Throwable> myResult;
/*    */   
/*    */   public LazyValue(@NotNull Callable<T> provider) {
/* 13 */     this.myProvider = provider;
/*    */   }
/*    */   
/*    */   public T getValue() throws Exception {
/* 17 */     Pair<T, Throwable> result = this.myResult;
/* 18 */     if (result != null) {
/* 19 */       return unpack(result);
/*    */     }
/* 21 */     synchronized (this.myLock) {
/* 22 */       result = this.myResult;
/* 23 */       if (result == null) {
/*    */         try {
/* 25 */           T value = this.myProvider.call();
/* 26 */           result = Pair.create(value, null);
/*    */         }
/* 28 */         catch (Throwable t) {
/* 29 */           result = Pair.create(null, t);
/*    */         } 
/* 31 */         this.myResult = result;
/*    */       } 
/*    */     } 
/* 34 */     return unpack(result);
/*    */   }
/*    */   
/*    */   private T unpack(@NotNull Pair<T, Throwable> result) throws Exception {
/* 38 */     if (result.second != null) {
/* 39 */       if (result.second instanceof Exception) {
/* 40 */         throw (Exception)result.second;
/*    */       }
/* 42 */       if (result.second instanceof Error) {
/* 43 */         throw (Error)result.second;
/*    */       }
/* 45 */       throw new RuntimeException("Rethrowing unknown Throwable", (Throwable)result.second);
/*    */     } 
/* 47 */     return (T)result.first;
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4\\util\LazyValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */