/*    */ package com.pty4j.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Pair<A, B>
/*    */ {
/*    */   public final A first;
/*    */   public final B second;
/*    */   
/*    */   public static <A, B> Pair<A, B> create(A first, B second) {
/* 23 */     return new Pair<A, B>(first, second);
/*    */   }
/*    */   
/*    */   public static <T> T getFirst(Pair<T, ?> pair) {
/* 27 */     return (pair != null) ? (T)pair.first : null;
/*    */   }
/*    */   
/*    */   public static <T> T getSecond(Pair<?, T> pair) {
/* 31 */     return (pair != null) ? (T)pair.second : null;
/*    */   }
/*    */   
/*    */   public Pair(A first, B second) {
/* 35 */     this.first = first;
/* 36 */     this.second = second;
/*    */   }
/*    */   
/*    */   public A getFirst() {
/* 40 */     return this.first;
/*    */   }
/*    */   
/*    */   public B getSecond() {
/* 44 */     return this.second;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 49 */     if (this == o) return true; 
/* 50 */     if (o == null || getClass() != o.getClass()) return false;
/*    */     
/* 52 */     Pair pair = (Pair)o;
/*    */     
/* 54 */     if ((this.first != null) ? this.first.equals(pair.first) : (pair.first == null)) if ((this.second != null) ? this.second
/* 55 */         .equals(pair.second) : (pair.second == null)); 
/*    */     return false;
/*    */   }
/*    */   public int hashCode() {
/* 59 */     int result = (this.first != null) ? this.first.hashCode() : 0;
/* 60 */     result = 31 * result + ((this.second != null) ? this.second.hashCode() : 0);
/* 61 */     return result;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 65 */     return "<" + this.first + "," + this.second + ">";
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4\\util\Pair.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */