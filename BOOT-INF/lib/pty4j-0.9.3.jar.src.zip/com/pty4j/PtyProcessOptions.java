/*    */ package com.pty4j;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PtyProcessOptions
/*    */ {
/*    */   private final String[] myCommand;
/*    */   private final Map<String, String> myEnvironment;
/*    */   private final String myDirectory;
/*    */   private final boolean myRedirectErrorStream;
/*    */   private final Integer myInitialColumns;
/*    */   private final Integer myInitialRows;
/*    */   private final boolean myWindowsAnsiColorEnabled;
/*    */   
/*    */   PtyProcessOptions(@NotNull String[] command, @Nullable Map<String, String> environment, @Nullable String directory, boolean redirectErrorStream, @Nullable Integer initialColumns, @Nullable Integer initialRows, boolean windowsAnsiColorEnabled) {
/* 24 */     this.myCommand = command;
/* 25 */     this.myEnvironment = environment;
/* 26 */     this.myDirectory = directory;
/* 27 */     this.myRedirectErrorStream = redirectErrorStream;
/* 28 */     this.myInitialColumns = initialColumns;
/* 29 */     this.myInitialRows = initialRows;
/* 30 */     this.myWindowsAnsiColorEnabled = windowsAnsiColorEnabled;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public String[] getCommand() {
/* 35 */     return this.myCommand;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public Map<String, String> getEnvironment() {
/* 40 */     return this.myEnvironment;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public String getDirectory() {
/* 45 */     return this.myDirectory;
/*    */   }
/*    */   
/*    */   public boolean isRedirectErrorStream() {
/* 49 */     return this.myRedirectErrorStream;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public Integer getInitialColumns() {
/* 54 */     return this.myInitialColumns;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public Integer getInitialRows() {
/* 59 */     return this.myInitialRows;
/*    */   }
/*    */   
/*    */   public boolean isWindowsAnsiColorEnabled() {
/* 63 */     return this.myWindowsAnsiColorEnabled;
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4j\PtyProcessOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */