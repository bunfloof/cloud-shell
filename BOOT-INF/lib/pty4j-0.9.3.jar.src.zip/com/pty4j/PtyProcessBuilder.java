/*     */ package com.pty4j;
/*     */ 
/*     */ import com.pty4j.unix.UnixPtyProcess;
/*     */ import com.pty4j.windows.CygwinPtyProcess;
/*     */ import com.pty4j.windows.WinPtyProcess;
/*     */ import com.sun.jna.Platform;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ public class PtyProcessBuilder
/*     */ {
/*     */   private String[] myCommand;
/*     */   private Map<String, String> myEnvironment;
/*     */   private String myDirectory;
/*     */   private boolean myConsole;
/*     */   private boolean myCygwin;
/*     */   private File myLogFile;
/*     */   private boolean myRedirectErrorStream = false;
/*     */   private Integer myInitialColumns;
/*     */   private Integer myInitialRows;
/*     */   private boolean myWindowsAnsiColorEnabled = false;
/*     */   
/*     */   public PtyProcessBuilder() {}
/*     */   
/*     */   public PtyProcessBuilder(@NotNull String[] command) {
/*  30 */     this.myCommand = command;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public PtyProcessBuilder setCommand(@NotNull String[] command) {
/*  35 */     this.myCommand = command;
/*  36 */     return this;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public PtyProcessBuilder setEnvironment(@Nullable Map<String, String> environment) {
/*  41 */     this.myEnvironment = environment;
/*  42 */     return this;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public PtyProcessBuilder setDirectory(String directory) {
/*  47 */     this.myDirectory = directory;
/*  48 */     return this;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public PtyProcessBuilder setConsole(boolean console) {
/*  53 */     this.myConsole = console;
/*  54 */     return this;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public PtyProcessBuilder setCygwin(boolean cygwin) {
/*  59 */     this.myCygwin = cygwin;
/*  60 */     return this;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public PtyProcessBuilder setLogFile(@Nullable File logFile) {
/*  65 */     this.myLogFile = logFile;
/*  66 */     return this;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public PtyProcessBuilder setRedirectErrorStream(boolean redirectErrorStream) {
/*  71 */     this.myRedirectErrorStream = redirectErrorStream;
/*  72 */     return this;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public PtyProcessBuilder setInitialColumns(@Nullable Integer initialColumns) {
/*  77 */     this.myInitialColumns = initialColumns;
/*  78 */     return this;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public PtyProcessBuilder setInitialRows(@Nullable Integer initialRows) {
/*  83 */     this.myInitialRows = initialRows;
/*  84 */     return this;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public PtyProcessBuilder setWindowsAnsiColorEnabled(boolean windowsAnsiColorEnabled) {
/*  89 */     this.myWindowsAnsiColorEnabled = windowsAnsiColorEnabled;
/*  90 */     return this;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public PtyProcess start() throws IOException {
/*  95 */     if (this.myEnvironment == null) {
/*  96 */       this.myEnvironment = System.getenv();
/*     */     }
/*  98 */     PtyProcessOptions options = new PtyProcessOptions(this.myCommand, this.myEnvironment, this.myDirectory, this.myRedirectErrorStream, this.myInitialColumns, this.myInitialRows, this.myWindowsAnsiColorEnabled);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     if (Platform.isWindows()) {
/* 106 */       if (this.myCygwin) {
/* 107 */         return (PtyProcess)new CygwinPtyProcess(this.myCommand, this.myEnvironment, this.myDirectory, this.myLogFile, this.myConsole);
/*     */       }
/* 109 */       return (PtyProcess)new WinPtyProcess(options, this.myConsole);
/*     */     } 
/* 111 */     return (PtyProcess)new UnixPtyProcess(options, this.myConsole);
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\pty4j-0.9.3.jar!\com\pty4j\PtyProcessBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */