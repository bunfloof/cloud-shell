/*    */ package purejavacomm;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsupportedCommOperationException
/*    */   extends Exception
/*    */ {
/*    */   public UnsupportedCommOperationException(String paramString) {
/* 35 */     super(paramString);
/*    */   }
/*    */   
/*    */   public UnsupportedCommOperationException() {}
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\UnsupportedCommOperationException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */