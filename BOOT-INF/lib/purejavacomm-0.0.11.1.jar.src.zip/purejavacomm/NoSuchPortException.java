package purejavacomm;

public class NoSuchPortException extends Exception {}


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\NoSuchPortException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */