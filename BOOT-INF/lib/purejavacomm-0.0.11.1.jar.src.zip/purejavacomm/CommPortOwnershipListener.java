package purejavacomm;

public interface CommPortOwnershipListener {
  public static final int PORT_OWNED = 1;
  
  public static final int PORT_OWNERSHIP_REQUESTED = 3;
  
  public static final int PORT_UNOWNED = 2;
  
  void ownershipChange(int paramInt);
}


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\CommPortOwnershipListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */