/*     */ package purejavacomm;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CommPort
/*     */ {
/*     */   protected String name;
/*     */   
/*     */   public void close() {
/*  44 */     CommPortIdentifier.close(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void disableReceiveFraming();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void disableReceiveThreshold();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void disableReceiveTimeout();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void enableReceiveFraming(int paramInt) throws UnsupportedCommOperationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void enableReceiveThreshold(int paramInt) throws UnsupportedCommOperationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void enableReceiveTimeout(int paramInt) throws UnsupportedCommOperationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getInputBufferSize();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract InputStream getInputStream() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 109 */     return this.name;
/*     */   }
/*     */   
/*     */   public abstract int getOutputBufferSize();
/*     */   
/*     */   public abstract OutputStream getOutputStream() throws IOException;
/*     */   
/*     */   public abstract int getReceiveFramingByte();
/*     */   
/*     */   public abstract int getReceiveThreshold();
/*     */   
/*     */   public abstract int getReceiveTimeout();
/*     */   
/*     */   public abstract boolean isReceiveFramingEnabled();
/*     */   
/*     */   public abstract boolean isReceiveThresholdEnabled();
/*     */   
/*     */   public abstract boolean isReceiveTimeoutEnabled();
/*     */   
/*     */   public abstract void setInputBufferSize(int paramInt);
/*     */   
/*     */   public abstract void setOutputBufferSize(int paramInt);
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\CommPort.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */