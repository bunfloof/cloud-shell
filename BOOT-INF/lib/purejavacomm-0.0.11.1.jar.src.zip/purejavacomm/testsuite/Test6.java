/*     */ package purejavacomm.testsuite;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Test6
/*     */   extends TestBase
/*     */ {
/*  36 */   private static Exception m_Exception = null;
/*     */   private static Thread m_Receiver;
/*     */   private static Thread m_Transmitter;
/*     */   
/*     */   static void run() throws Exception {
/*     */     try {
/*  42 */       begin("Test6 - threshold + timeout");
/*  43 */       openPort();
/*  44 */       m_Port.setSerialPortParams(230400, 8, 1, 0);
/*     */ 
/*     */       
/*  47 */       m_Receiver = new Thread(new Runnable() {
/*     */             public void run() {
/*     */               
/*  50 */               try { TestBase.sync(2);
/*  51 */                 TestBase.m_Port.enableReceiveThreshold(4);
/*  52 */                 TestBase.m_Port.enableReceiveTimeout(10000);
/*     */                 
/*  54 */                 byte[] arrayOfByte = new byte[4];
/*  55 */                 for (byte b = 0; b < 'Ϩ'; b++) {
/*  56 */                   long l1 = System.currentTimeMillis();
/*  57 */                   int i = TestBase.m_In.read(arrayOfByte);
/*  58 */                   long l2 = System.currentTimeMillis() - l1;
/*  59 */                   if (i != 4)
/*  60 */                     TestBase.fail("read did not get 4 bytes as expected, got %d ", new Object[] { Integer.valueOf(i) }); 
/*  61 */                   if (l2 >= 1000L) {
/*  62 */                     TestBase.fail("read timed out though we got 4 bytes " + l2, new Object[0]);
/*     */                   }
/*     */                 }  }
/*  65 */               catch (InterruptedException interruptedException) {  }
/*  66 */               catch (Exception exception)
/*  67 */               { if (Test6.m_Exception == null)
/*  68 */                   Test6.m_Exception = exception; 
/*  69 */                 Test6.m_Receiver.interrupt();
/*  70 */                 Test6.m_Transmitter.interrupt(); }
/*     */             
/*     */             }
/*     */           });
/*     */ 
/*     */       
/*  76 */       m_Transmitter = new Thread(new Runnable() {
/*     */             public void run() {
/*     */               
/*  79 */               try { TestBase.sync(2);
/*  80 */                 for (byte b = 0; b < 'Ϩ'; b++)
/*  81 */                   TestBase.m_Out.write(new byte[4]);  }
/*  82 */               catch (InterruptedException interruptedException) {  }
/*  83 */               catch (Exception exception)
/*  84 */               { exception.printStackTrace();
/*  85 */                 if (Test6.m_Exception == null)
/*  86 */                   Test6.m_Exception = exception; 
/*  87 */                 Test6.m_Receiver.interrupt();
/*  88 */                 Test6.m_Transmitter.interrupt(); }
/*     */             
/*     */             }
/*     */           });
/*     */       
/*  93 */       m_Transmitter.start();
/*  94 */       sleep(100);
/*  95 */       m_Receiver.start();
/*     */       
/*  97 */       while (m_Receiver.isAlive() || m_Transmitter.isAlive()) {
/*  98 */         sleep(100);
/*     */       }
/*     */       
/* 101 */       if (m_Exception != null)
/* 102 */         throw m_Exception; 
/* 103 */       finishedOK();
/*     */     } finally {
/* 105 */       closePort();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\testsuite\Test6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */