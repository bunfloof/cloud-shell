/*    */ package purejavacomm.testsuite;
/*    */ 
/*    */ import purejavacomm.SerialPortEvent;
/*    */ import purejavacomm.SerialPortEventListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Test1
/*    */   extends TestBase
/*    */ {
/*    */   static void run() throws Exception {
/*    */     try {
/* 39 */       begin("Test1 - control lines ");
/* 40 */       openPort();
/* 41 */       m_Port.setRTS(false);
/* 42 */       m_Port.setDTR(false);
/* 43 */       sleep();
/*    */       
/* 45 */       m_Port.notifyOnCTS(true);
/* 46 */       m_Port.notifyOnRingIndicator(true);
/* 47 */       m_Port.notifyOnCarrierDetect(true);
/* 48 */       m_Port.notifyOnDSR(true);
/* 49 */       final int[] counts = new int[11];
/* 50 */       m_Port.addEventListener(new SerialPortEventListener() {
/*    */             public void serialEvent(SerialPortEvent param1SerialPortEvent) {
/*    */               try {
/* 53 */                 if (param1SerialPortEvent.getEventType() == 3)
/* 54 */                   counts[3] = counts[3] + 1; 
/* 55 */                 if (param1SerialPortEvent.getEventType() == 5)
/* 56 */                   counts[5] = counts[5] + 1; 
/* 57 */                 if (param1SerialPortEvent.getEventType() == 6)
/* 58 */                   counts[6] = counts[6] + 1; 
/* 59 */                 if (param1SerialPortEvent.getEventType() == 4)
/* 60 */                   counts[4] = counts[4] + 1; 
/* 61 */               } catch (Exception exception) {
/* 62 */                 exception.printStackTrace();
/*    */               } 
/*    */             }
/*    */           });
/* 66 */       char c = '';
/* 67 */       for (byte b = 0; b < c; b++) {
/* 68 */         m_Port.setRTS(((b & 0x1) != 0));
/* 69 */         m_Port.setDTR(((b & 0x2) != 0));
/* 70 */         sleep();
/*    */       } 
/* 72 */       if (arrayOfInt[3] != c - 1)
/* 73 */         fail("CTS loopback failed, expected %d toggles, got %d", new Object[] { Integer.valueOf(c - 1), Integer.valueOf(arrayOfInt[3]) }); 
/* 74 */       if (arrayOfInt[4] != c / 2 - 1)
/* 75 */         fail("DSR loopback failed, expected %d toggles, got %d", new Object[] { Integer.valueOf(c / 2 - 1), Integer.valueOf(arrayOfInt[4]) }); 
/* 76 */       if (arrayOfInt[5] != c - 1)
/* 77 */         fail("RI loopback failed, expected %d toggles, got %d", new Object[] { Integer.valueOf(c - 1), Integer.valueOf(arrayOfInt[5]) }); 
/* 78 */       if (arrayOfInt[6] != c / 2 - 1)
/* 79 */         fail("CTS loopback failed, expected %d toggles, got %d", new Object[] { Integer.valueOf(c / 2 - 1), Integer.valueOf(arrayOfInt[6]) }); 
/* 80 */       finishedOK();
/*    */     } finally {
/* 82 */       closePort();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\testsuite\Test1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */