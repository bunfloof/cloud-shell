/*     */ package purejavacomm.testsuite;
/*     */ 
/*     */ import purejavacomm.UnsupportedCommOperationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Test8
/*     */   extends TestBase
/*     */ {
/*     */   static void run() throws Exception {
/*     */     try {
/*  39 */       begin("Test8 - parity etc");
/*  40 */       openPort();
/*  41 */       int[] arrayOfInt1 = { 0, 1, 2, 3, 4 };
/*  42 */       int[] arrayOfInt2 = { 1, 3, 2 };
/*  43 */       int[] arrayOfInt3 = { 8, 7, 6, 5 };
/*  44 */       int[] arrayOfInt4 = { 255, 127, 63, 31 };
/*  45 */       System.out.println();
/*  46 */       byte b1 = 0;
/*  47 */       for (byte b2 = 0; b2 < arrayOfInt1.length; b2++) {
/*  48 */         for (byte b = 0; b < arrayOfInt2.length; b++) {
/*  49 */           for (byte b3 = 0; b3 < arrayOfInt3.length; b3++) {
/*     */             
/*  51 */             m_Port.enableReceiveTimeout(10000);
/*  52 */             m_Port.enableReceiveThreshold(256);
/*     */             try {
/*  54 */               String str1 = "?";
/*  55 */               switch (arrayOfInt3[b3]) {
/*     */                 case 5:
/*  57 */                   str1 = "5";
/*     */                   break;
/*     */                 case 6:
/*  60 */                   str1 = "6";
/*     */                   break;
/*     */                 case 7:
/*  63 */                   str1 = "7";
/*     */                   break;
/*     */                 case 8:
/*  66 */                   str1 = "8";
/*     */                   break;
/*     */               } 
/*     */               
/*  70 */               String str2 = "?";
/*  71 */               switch (arrayOfInt2[b]) {
/*     */                 case 1:
/*  73 */                   str2 = "1";
/*     */                   break;
/*     */                 case 3:
/*  76 */                   str2 = "1.5";
/*     */                   break;
/*     */                 case 2:
/*  79 */                   str2 = "2";
/*     */                   break;
/*     */               } 
/*     */               
/*  83 */               String str3 = "?";
/*  84 */               switch (arrayOfInt1[b2]) {
/*     */                 case 2:
/*  86 */                   str3 = "E";
/*     */                   break;
/*     */                 case 1:
/*  89 */                   str3 = "O";
/*     */                   break;
/*     */                 case 3:
/*  92 */                   str3 = "M";
/*     */                   break;
/*     */                 case 4:
/*  95 */                   str3 = "S";
/*     */                   break;
/*     */                 case 0:
/*  98 */                   str3 = "N";
/*     */                   break;
/*     */               } 
/* 101 */               b1++;
/* 102 */               begin("Test8." + b1 + " databits=" + str1 + " stopbits=" + str2 + " parity=" + str3);
/* 103 */               m_Port.setSerialPortParams(19200, arrayOfInt3[b3], arrayOfInt2[b], arrayOfInt1[b2]);
/* 104 */               sleep(100);
/* 105 */               byte[] arrayOfByte1 = new byte[256];
/* 106 */               byte[] arrayOfByte2 = new byte[256];
/*     */               
/* 108 */               for (byte b4 = 0; b4 < 'Ā'; b4++)
/* 109 */                 arrayOfByte1[b4] = (byte)b4; 
/* 110 */               m_Out = m_Port.getOutputStream();
/* 111 */               m_In = m_Port.getInputStream();
/* 112 */               long l = System.currentTimeMillis();
/* 113 */               m_Out.write(arrayOfByte1);
/*     */               
/* 115 */               int i = 0;
/* 116 */               while ((i += m_In.read(arrayOfByte2, i, 256 - i)) < 256);
/*     */ 
/*     */               
/* 119 */               if (i != arrayOfByte1.length)
/* 120 */                 fail("was expecting %d characters got %d", new Object[] { Integer.valueOf(arrayOfByte1.length), Integer.valueOf(i) }); 
/* 121 */               for (byte b5 = 0; b5 < 'Ā'; b5++) {
/* 122 */                 if (b5 <= arrayOfInt4[b3]) {
/*     */                   
/* 124 */                   if (arrayOfByte2[b5] != arrayOfByte1[b5]) {
/* 125 */                     fail("failed: transmit '0x%02X' != receive'0x%02X'", new Object[] { Byte.valueOf(arrayOfByte1[b5]), Byte.valueOf(arrayOfByte2[b5]) });
/*     */                   }
/*     */                 }
/*     */                 else {
/*     */                   
/* 130 */                   int j = arrayOfByte1[b5] & arrayOfInt4[b3];
/* 131 */                   if (arrayOfByte2[b5] != j) {
/* 132 */                     fail("failed: transmit (excessive) '0x%02X' != receive'0x%02X'%n", new Object[] { Integer.valueOf(j), Byte.valueOf(arrayOfByte2[b5]) });
/*     */                   }
/*     */                 } 
/*     */               } 
/* 136 */               if (i < 256)
/* 137 */                 fail("did not receive all 256 chars, got %d", new Object[] { Integer.valueOf(i) }); 
/* 138 */               finishedOK();
/* 139 */             } catch (UnsupportedCommOperationException unsupportedCommOperationException) {
/* 140 */               finishedOK(" NOT SUPPORTED", new Object[0]);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } finally {
/*     */       
/* 147 */       closePort();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\testsuite\Test8.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */