/*    */ package purejavacomm.testsuite;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import purejavacomm.CommPortIdentifier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Test16
/*    */   extends TestBase
/*    */ {
/*    */   static void run() throws Exception {
/* 43 */     String str1 = null;
/* 44 */     String str2 = null;
/*    */ 
/*    */     
/*    */     try {
/* 48 */       begin("Test16 - port ownership");
/*    */       
/* 50 */       openPort();
/*    */ 
/*    */       
/* 53 */       Enumeration<CommPortIdentifier> enumeration = CommPortIdentifier.getPortIdentifiers();
/*    */ 
/*    */       
/* 56 */       while (enumeration.hasMoreElements()) {
/* 57 */         CommPortIdentifier commPortIdentifier = enumeration.nextElement();
/* 58 */         if (commPortIdentifier.getName().equals(getPortName())) {
/* 59 */           str1 = commPortIdentifier.getCurrentOwner();
/*    */           
/*    */           break;
/*    */         } 
/*    */       } 
/*    */       
/* 65 */       enumeration = CommPortIdentifier.getPortIdentifiers();
/*    */ 
/*    */       
/* 68 */       while (enumeration.hasMoreElements()) {
/* 69 */         CommPortIdentifier commPortIdentifier = enumeration.nextElement();
/* 70 */         if (commPortIdentifier.getName().equals(getPortName())) {
/* 71 */           str2 = commPortIdentifier.getCurrentOwner();
/*    */           
/*    */           break;
/*    */         } 
/*    */       } 
/*    */       
/* 77 */       if (str2 == null || !str2.equals(str1)) {
/* 78 */         fail("Owner name incorrectly changed simply by reenumerating ports." + str1 + " vs. " + str2, new Object[0]);
/*    */       } else {
/*    */         
/* 81 */         finishedOK();
/*    */       } 
/*    */     } finally {
/*    */       
/* 85 */       closePort();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\testsuite\Test16.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */