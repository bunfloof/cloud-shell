/*    */ package purejavacomm.testsuite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Test4
/*    */   extends TestBase
/*    */ {
/* 36 */   private static Exception m_Exception = null;
/*    */   private static Thread m_Receiver;
/*    */   private static Thread m_Transmitter;
/*    */   
/*    */   static void run() throws Exception {
/*    */     try {
/* 42 */       begin("Test4 - indefinite blocking");
/* 43 */       openPort();
/*    */       
/* 45 */       m_Receiver = new Thread(new Runnable() {
/*    */             public void run() {
/*    */               
/* 48 */               try { TestBase.sync(2);
/* 49 */                 long l1 = System.currentTimeMillis();
/* 50 */                 byte[] arrayOfByte = { 0 };
/* 51 */                 int i = TestBase.m_In.read(arrayOfByte);
/* 52 */                 long l2 = System.currentTimeMillis() - l1;
/* 53 */                 if (i != 1)
/* 54 */                   TestBase.fail("read did not block, read returned %d", new Object[] { Integer.valueOf(i) }); 
/* 55 */                 if (arrayOfByte[0] != 73)
/* 56 */                   TestBase.fail("read did not get looped back '73' got '%d'", new Object[] { Byte.valueOf(arrayOfByte[0]) }); 
/* 57 */                 if (l2 < 10000L)
/* 58 */                   TestBase.fail("read did not block for 10000 msec, received loopback in %d msec", new Object[] { Long.valueOf(l2) });  }
/* 59 */               catch (InterruptedException interruptedException) {  }
/* 60 */               catch (Exception exception)
/* 61 */               { if (Test4.m_Exception == null)
/* 62 */                   Test4.m_Exception = exception; 
/* 63 */                 Test4.m_Receiver.interrupt();
/* 64 */                 Test4.m_Transmitter.interrupt(); }
/*    */             
/*    */             }
/*    */           });
/*    */ 
/*    */       
/* 70 */       m_Transmitter = new Thread(new Runnable() {
/*    */             public void run() {
/*    */               
/* 73 */               try { TestBase.sync(2);
/* 74 */                 TestBase.sleep(10000);
/* 75 */                 TestBase.m_Out.write(73); }
/*    */               
/* 77 */               catch (InterruptedException interruptedException) {  }
/* 78 */               catch (Exception exception)
/* 79 */               { exception.printStackTrace();
/* 80 */                 if (Test4.m_Exception == null)
/* 81 */                   Test4.m_Exception = exception; 
/* 82 */                 Test4.m_Receiver.interrupt();
/* 83 */                 Test4.m_Transmitter.interrupt(); }
/*    */             
/*    */             }
/*    */           });
/*    */       
/* 88 */       m_Receiver.start();
/* 89 */       m_Transmitter.start();
/*    */       
/* 91 */       while (m_Receiver.isAlive() || m_Transmitter.isAlive()) {
/* 92 */         sleep(100);
/*    */       }
/*    */       
/* 95 */       if (m_Exception != null)
/* 96 */         throw m_Exception; 
/* 97 */       finishedOK();
/*    */     } finally {
/* 99 */       closePort();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\testsuite\Test4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */