/*    */ package purejavacomm.testsuite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Test15
/*    */   extends TestBase
/*    */ {
/*    */   static void run() throws Exception {
/*    */     try {
/* 39 */       byte b = 100;
/* 40 */       begin("Test15 - treshold disabled, timeout == " + b);
/* 41 */       openPort();
/* 42 */       m_Out = m_Port.getOutputStream();
/* 43 */       m_In = m_Port.getInputStream();
/*    */       
/* 45 */       byte[] arrayOfByte1 = new byte[1000];
/* 46 */       byte[] arrayOfByte2 = new byte[arrayOfByte1.length];
/*    */       
/* 48 */       m_Port.enableReceiveTimeout(100);
/* 49 */       m_Port.disableReceiveThreshold();
/*    */ 
/*    */       
/* 52 */       long l1 = System.currentTimeMillis();
/* 53 */       int i = m_In.read(arrayOfByte2, 0, 10);
/* 54 */       long l2 = System.currentTimeMillis();
/* 55 */       if (i != 0)
/* 56 */         fail("was expecting 0 bytes, but got " + i + " bytes", new Object[0]); 
/* 57 */       int j = b;
/* 58 */       int k = b * 110 / 100;
/* 59 */       int m = (int)(l2 - l1);
/* 60 */       if (m < j)
/* 61 */         fail("timed out early, was expecting  " + j + " but got " + m + " msec", new Object[0]); 
/* 62 */       if (m > k) {
/* 63 */         fail("timed out late, was expecting  " + k + " but got " + m + " msec", new Object[0]);
/*    */       }
/*    */ 
/*    */       
/* 67 */       m_Out.write(arrayOfByte1, 0, 1000);
/* 68 */       sleep(50);
/* 69 */       l1 = System.currentTimeMillis();
/* 70 */       i = m_In.read(arrayOfByte2, 0, 1000);
/* 71 */       l2 = System.currentTimeMillis();
/* 72 */       j = (int)(l2 - l1);
/* 73 */       k = i * 150 / 100;
/* 74 */       if (j > k)
/* 75 */         fail("expected read to return in " + k + " but it took " + j + " msec and returned " + i + " bytes", new Object[0]); 
/* 76 */       if (i < 10) {
/* 77 */         fail("was expecting at least 900 bytes, but got " + i + " bytes", new Object[0]);
/*    */       }
/*    */ 
/*    */       
/* 81 */       finishedOK();
/*    */     } finally {
/* 83 */       closePort();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\testsuite\Test15.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */