/*     */ package purejavacomm.testsuite;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Test9
/*     */   extends TestBase
/*     */ {
/*     */   static volatile boolean m_ReadThreadRunning;
/*  39 */   static volatile int m_ReadBytes = 0;
/*     */   static volatile long m_T0;
/*     */   static volatile long m_T1;
/*  42 */   static byte[] m_TxBuffer = new byte[1000];
/*  43 */   static byte[] m_RxBuffer = new byte[m_TxBuffer.length];
/*     */ 
/*     */   
/*     */   static void startReadThread() throws Exception {
/*  47 */     Thread thread = new Thread(new Runnable() {
/*     */           public void run() {
/*  49 */             Test9.m_ReadThreadRunning = true;
/*     */             try {
/*  51 */               Test9.m_T0 = System.currentTimeMillis();
/*  52 */               Test9.m_ReadBytes = TestBase.m_In.read(Test9.m_RxBuffer, 0, Test9.m_RxBuffer.length);
/*  53 */               Test9.m_T1 = System.currentTimeMillis();
/*  54 */             } catch (IOException iOException) {
/*  55 */               iOException.printStackTrace();
/*     */             } 
/*  57 */             Test9.m_ReadThreadRunning = false;
/*     */           }
/*     */         });
/*     */     
/*  61 */     m_ReadThreadRunning = false;
/*  62 */     thread.setPriority(10);
/*  63 */     thread.start();
/*  64 */     while (!m_ReadThreadRunning) {
/*  65 */       Thread.sleep(10L);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void run() throws Exception {
/*     */     try {
/*  74 */       begin("Test9 - treshold 100, timeout 100 ");
/*  75 */       openPort();
/*  76 */       m_Out = m_Port.getOutputStream();
/*  77 */       m_In = m_Port.getInputStream();
/*     */ 
/*     */       
/*  80 */       m_Port.enableReceiveTimeout(100);
/*  81 */       m_Port.enableReceiveThreshold(100);
/*     */ 
/*     */       
/*  84 */       startReadThread();
/*     */       
/*  86 */       sleep(500);
/*  87 */       if (m_ReadThreadRunning) {
/*  88 */         fail("read did not timeout", new Object[0]);
/*     */       }
/*  90 */       startReadThread();
/*     */       
/*  92 */       byte b1 = 10;
/*  93 */       byte b2 = 50; int i;
/*  94 */       for (i = 0; i < 1000; i++) {
/*  95 */         m_Out.write(m_TxBuffer, 0, b1);
/*  96 */         sleep(50);
/*  97 */         if (!m_ReadThreadRunning)
/*     */           break; 
/*     */       } 
/* 100 */       if (m_ReadThreadRunning)
/* 101 */         fail("read did not complete in resonable time", new Object[0]); 
/* 102 */       if (m_ReadBytes < 100)
/* 103 */         fail("expected at minimum 100 bytes but got " + m_ReadBytes, new Object[0]); 
/* 104 */       if (m_ReadThreadRunning) {
/* 105 */         fail("read did not complete in time", new Object[0]);
/*     */       }
/* 107 */       i = (int)(m_T1 - m_T0);
/* 108 */       int j = (100 / b1 + 2) * b2;
/*     */       
/* 110 */       if (i > j) {
/* 111 */         fail("was expecting read to happen in " + j + " but it took " + i + " msec", new Object[0]);
/*     */       }
/*     */ 
/*     */       
/* 115 */       finishedOK();
/*     */     } finally {
/* 117 */       closePort();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\testsuite\Test9.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */