/*    */ package purejavacomm.testsuite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Test3
/*    */   extends TestBase
/*    */ {
/*    */   static void run() throws Exception {
/*    */     try {
/* 41 */       begin("Test3 - transmit all characters");
/* 42 */       openPort();
/* 43 */       int i = m_Port.getFlowControlMode();
/* 44 */       i &= 0xFFFFFFF3;
/* 45 */       m_Port.setFlowControlMode(i);
/* 46 */       byte[] arrayOfByte1 = new byte[256];
/* 47 */       byte[] arrayOfByte2 = new byte[256]; int j;
/* 48 */       for (j = 0; j < 256; j++)
/* 49 */         arrayOfByte1[j] = (byte)j; 
/* 50 */       m_Port.enableReceiveTimeout(1000);
/* 51 */       m_Out = m_Port.getOutputStream();
/* 52 */       m_In = m_Port.getInputStream();
/* 53 */       m_Out.write(arrayOfByte1);
/*    */       
/* 55 */       sleep(500);
/*    */       
/* 57 */       j = m_In.read(arrayOfByte2);
/*    */       
/* 59 */       for (byte b = 0; b < 'Ā'; b++) {
/* 60 */         if (arrayOfByte1[b] != arrayOfByte2[b])
/* 61 */           fail("failed to transmit/receive char '%d'", new Object[] { Integer.valueOf(b) }); 
/*    */       } 
/* 63 */       if (j < 256) {
/* 64 */         fail("did not receive all 256 chars, got %d", new Object[] { Integer.valueOf(j) });
/*    */       }
/* 66 */       finishedOK();
/*    */     } finally {
/* 68 */       closePort();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\testsuite\Test3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */