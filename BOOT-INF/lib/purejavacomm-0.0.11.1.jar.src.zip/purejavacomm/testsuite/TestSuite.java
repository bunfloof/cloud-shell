/*    */ package purejavacomm.testsuite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TestSuite
/*    */ {
/*    */   public static void main(String[] paramArrayOfString) {
/* 38 */     TestBase.init(paramArrayOfString);
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 43 */       System.out.println("PureJavaComm Test Suite");
/* 44 */       System.out.println("Using port: " + TestBase.getPortName());
/* 45 */       Test1.run();
/* 46 */       Test2.run(19200);
/* 47 */       Test3.run();
/* 48 */       Test4.run();
/* 49 */       Test5.run();
/* 50 */       Test6.run();
/* 51 */       Test7.run();
/* 52 */       Test8.run();
/* 53 */       Test9.run();
/* 54 */       Test10.run();
/* 55 */       Test11.run();
/* 56 */       Test12.run();
/* 57 */       Test13.run();
/* 58 */       Test15.run();
/* 59 */       Test16.run();
/* 60 */       System.out.println("All tests passed OK.");
/* 61 */     } catch (TestFailedException testFailedException) {
/* 62 */       System.out.println("Test failure");
/* 63 */     } catch (Exception exception) {
/* 64 */       exception.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\testsuite\TestSuite.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */