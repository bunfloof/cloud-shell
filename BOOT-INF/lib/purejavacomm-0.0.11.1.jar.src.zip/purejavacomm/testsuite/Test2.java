/*     */ package purejavacomm.testsuite;
/*     */ 
/*     */ import java.util.Random;
/*     */ import purejavacomm.SerialPortEvent;
/*     */ import purejavacomm.SerialPortEventListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Test2
/*     */   extends TestBase
/*     */ {
/*     */   private static boolean m_Done;
/*  41 */   private static volatile Random rnd = new Random();
/*  42 */   private static volatile byte[] m_ReceiveBuffer = new byte[10000];
/*  43 */   private static volatile int m_BytesReceived = 0;
/*     */   private static volatile int m_TotalReceived;
/*     */   private static volatile long m_T0;
/*     */   private static volatile long m_T1;
/*  47 */   private static volatile int m_TxCount = 0;
/*  48 */   private static volatile int m_RxCount = 0;
/*  49 */   private static volatile int m_ErrorCount = 0;
/*  50 */   private static int N = 1000;
/*     */   
/*     */   static void run(int paramInt) throws Exception {
/*     */     try {
/*  54 */       m_Done = false;
/*  55 */       rnd = new Random();
/*  56 */       m_BytesReceived = 0;
/*  57 */       m_TotalReceived = 0;
/*  58 */       m_TxCount = 0;
/*  59 */       m_RxCount = 0;
/*  60 */       m_ErrorCount = 0;
/*     */       
/*  62 */       begin("Test2 - tx/rx with event listener");
/*  63 */       openPort();
/*  64 */       m_Port.notifyOnDataAvailable(true);
/*  65 */       m_Port.notifyOnOutputEmpty(true);
/*  66 */       m_Port.setFlowControlMode(12);
/*  67 */       m_Port.setSerialPortParams(paramInt, 8, 1, 0);
/*  68 */       boolean[] arrayOfBoolean = { false };
/*  69 */       m_T0 = System.currentTimeMillis();
/*  70 */       m_Port.addEventListener(new SerialPortEventListener() {
/*     */             public void serialEvent(SerialPortEvent param1SerialPortEvent) {
/*     */               try {
/*  73 */                 if (param1SerialPortEvent.getEventType() == 1) {
/*  74 */                   byte[] arrayOfByte = new byte[TestBase.m_In.available()];
/*  75 */                   int i = TestBase.m_In.read(arrayOfByte);
/*  76 */                   if (!Test2.m_Done) {
/*  77 */                     Test2.m_TotalReceived += i;
/*  78 */                     Test2.processBuffer(arrayOfByte, i);
/*  79 */                     if (Test2.m_RxCount >= Test2.N) {
/*  80 */                       Test2.m_Done = true;
/*     */                     }
/*     */                   } 
/*     */                 } 
/*  84 */                 if (param1SerialPortEvent.getEventType() == 2 && Test2
/*  85 */                   .m_TxCount < Test2.N) {
/*  86 */                   byte[] arrayOfByte = Test2.generateRandomMessage();
/*  87 */                   TestBase.m_Out.write(arrayOfByte, 0, arrayOfByte.length);
/*     */ 
/*     */                   
/*     */                   Test2.m_TxCount++;
/*     */                 } 
/*  92 */               } catch (Exception exception) {
/*  93 */                 exception.printStackTrace();
/*     */               } 
/*     */             }
/*     */           });
/*  97 */       while (!m_Done) {
/*     */         try {
/*  99 */           sleep(100);
/* 100 */         } catch (Exception exception) {
/* 101 */           exception.printStackTrace();
/*     */         } 
/*     */       } 
/* 104 */       m_T1 = System.currentTimeMillis();
/* 105 */       if (m_ErrorCount > 0) {
/* 106 */         fail("checksum sum failure in %d out %d messages", new Object[] { Integer.valueOf(m_ErrorCount), Integer.valueOf(N) });
/*     */       }
/* 108 */       int i = m_Port.getDataBits() + 2;
/* 109 */       double d = (m_TotalReceived * i) * 1000.0D / (m_T1 - m_T0);
/* 110 */       int j = m_Port.getBaudRate();
/* 111 */       finishedOK("average speed %1.0f b/sec at baud rate %d", new Object[] { Double.valueOf(d), Integer.valueOf(j) });
/*     */     } finally {
/* 113 */       closePort();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] generateRandomMessage() {
/* 119 */     int i = 4 + (rnd.nextInt() & 0x3F);
/* 120 */     byte[] arrayOfByte = new byte[i + 2];
/*     */     
/* 122 */     int j = 0;
/*     */     byte b;
/* 124 */     for (b = 0; b < i; b++) {
/* 125 */       byte b1 = (byte)(32 + (rnd.nextInt() & 0x3F));
/* 126 */       arrayOfByte[b] = b1;
/* 127 */       j += b1;
/*     */     } 
/* 129 */     arrayOfByte[b++] = (byte)(32 + (j & 0x3F));
/* 130 */     arrayOfByte[b++] = 10;
/* 131 */     return arrayOfByte;
/*     */   }
/*     */   
/*     */   private static void processBuffer(byte[] paramArrayOfbyte, int paramInt) {
/* 135 */     for (byte b = 0; b < paramInt; b++) {
/* 136 */       byte b1 = paramArrayOfbyte[b];
/* 137 */       if (paramInt > paramArrayOfbyte.length) {
/* 138 */         m_ErrorCount++;
/*     */         
/*     */         return;
/*     */       } 
/* 142 */       m_ReceiveBuffer[m_BytesReceived++] = b1;
/* 143 */       if (b1 == 10) {
/*     */         
/* 145 */         int i = 0;
/*     */         byte b2;
/* 147 */         for (b2 = 0; b2 < m_BytesReceived - 2; b2++)
/* 148 */           i += m_ReceiveBuffer[b2]; 
/* 149 */         byte b3 = (byte)(32 + (i & 0x3F));
/* 150 */         if (b3 != m_ReceiveBuffer[b2] && m_RxCount > 0) {
/* 151 */           System.out.println("check sum failure");
/* 152 */           m_ErrorCount++;
/*     */         } 
/* 154 */         m_RxCount++;
/* 155 */         m_BytesReceived = 0;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\testsuite\Test2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */