/*    */ package purejavacomm.testsuite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Test13
/*    */   extends TestBase
/*    */ {
/*    */   static void run() throws Exception {
/*    */     try {
/* 39 */       begin("Test13 - enableReceiveThreshold(0)");
/* 40 */       openPort();
/*    */       
/* 42 */       m_Out = m_Port.getOutputStream();
/* 43 */       m_In = m_Port.getInputStream();
/*    */       
/* 45 */       byte[] arrayOfByte1 = new byte[10];
/* 46 */       byte[] arrayOfByte2 = new byte[arrayOfByte1.length];
/*    */       
/* 48 */       m_Port.enableReceiveTimeout(100);
/* 49 */       m_Port.enableReceiveThreshold(0);
/* 50 */       byte b1 = 10;
/* 51 */       byte b2 = 8;
/*    */       
/* 53 */       long l = 0L; byte b3;
/* 54 */       for (b3 = 0; b3 < b1; b3++) {
/* 55 */         m_Out.write(arrayOfByte1, 0, b2);
/* 56 */         sleep(100);
/*    */         
/* 58 */         long l1 = System.currentTimeMillis();
/* 59 */         int i = m_In.read(arrayOfByte2, 0, 10);
/* 60 */         long l2 = System.currentTimeMillis();
/* 61 */         l += l2 - l1;
/* 62 */         if (i != 8) {
/* 63 */           fail("did not get all data back, got only " + i + " bytes", new Object[0]);
/*    */         }
/*    */       } 
/* 66 */       if (l / b1 > 1L) {
/* 67 */         fail("read did not return immediately, it took " + (l / b1) + " msec on average to read " + b2 + " bytes", new Object[0]);
/*    */       }
/*    */ 
/*    */       
/* 71 */       l = 0L;
/* 72 */       for (b3 = 0; b3 < b1; b3++) {
/*    */         
/* 74 */         long l1 = System.currentTimeMillis();
/* 75 */         int i = m_In.read(arrayOfByte2, 0, 10);
/* 76 */         long l2 = System.currentTimeMillis();
/* 77 */         l += l2 - l1;
/* 78 */         if (i != 0) {
/* 79 */           fail("was expecting 0 bytes, but got " + i + " bytes", new Object[0]);
/*    */         }
/*    */       } 
/* 82 */       if (l / b1 > 1L) {
/* 83 */         fail("read did not return immediately, it took " + (l / b1) + " msec", new Object[0]);
/*    */       }
/*    */       
/* 86 */       finishedOK();
/*    */     } finally {
/* 88 */       closePort();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\testsuite\Test13.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */