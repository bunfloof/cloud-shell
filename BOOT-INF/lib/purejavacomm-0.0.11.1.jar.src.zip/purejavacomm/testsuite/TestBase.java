/*     */ package purejavacomm.testsuite;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Enumeration;
/*     */ import purejavacomm.CommPortIdentifier;
/*     */ import purejavacomm.NoSuchPortException;
/*     */ import purejavacomm.SerialPort;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TestBase
/*     */ {
/*     */   protected static volatile String m_TestPortName;
/*     */   protected static volatile SerialPort m_Port;
/*     */   private static volatile long m_T0;
/*     */   protected static volatile OutputStream m_Out;
/*     */   protected static volatile InputStream m_In;
/*     */   
/*     */   static class TestFailedException
/*     */     extends Exception {}
/*     */   
/*  52 */   protected static volatile int[] m_SyncSema4 = new int[] { 0 };
/*     */   protected static int m_Tab;
/*     */   protected static int m_Progress;
/*     */   
/*     */   protected static void sync(int paramInt) throws InterruptedException {
/*  57 */     synchronized (m_SyncSema4) {
/*  58 */       m_SyncSema4[0] = m_SyncSema4[0] + 1;
/*  59 */       if (m_SyncSema4[0] < paramInt) {
/*  60 */         m_SyncSema4.wait();
/*     */       } else {
/*  62 */         m_SyncSema4[0] = 0;
/*  63 */         m_SyncSema4.notifyAll();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected static void openPort() throws Exception {
/*     */     try {
/*  70 */       CommPortIdentifier commPortIdentifier = CommPortIdentifier.getPortIdentifier(m_TestPortName);
/*  71 */       m_Port = (SerialPort)commPortIdentifier.open("PureJavaCommTestSuite", 1000);
/*  72 */       m_Out = m_Port.getOutputStream();
/*  73 */       m_In = m_Port.getInputStream();
/*  74 */       drain(m_In);
/*  75 */     } catch (NoSuchPortException noSuchPortException) {
/*  76 */       fail("could no open port '%s'\n", new Object[] { m_TestPortName });
/*     */     } 
/*     */   }
/*     */   
/*     */   protected static void closePort() {
/*  81 */     if (m_Port != null) {
/*     */       try {
/*  83 */         m_Out.flush();
/*  84 */         m_Port.close();
/*  85 */       } catch (IOException iOException) {
/*  86 */         iOException.printStackTrace();
/*     */       } finally {
/*     */         
/*  89 */         m_Port = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected static void drain(InputStream paramInputStream) throws Exception {
/*  95 */     sleep(100);
/*     */     int i;
/*  97 */     while ((i = paramInputStream.available()) > 0) {
/*  98 */       for (byte b = 0; b < i; b++)
/*  99 */         paramInputStream.read(); 
/* 100 */       sleep(100);
/*     */     } 
/*     */   }
/*     */   
/*     */   static void begin(String paramString) {
/* 105 */     System.out.printf("%-46s", new Object[] { paramString });
/* 106 */     m_Tab = 46;
/* 107 */     m_T0 = System.currentTimeMillis();
/* 108 */     m_Progress = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void sleep() throws InterruptedException {
/* 116 */     sleep(40);
/*     */   }
/*     */   
/*     */   protected static void sleep(int paramInt) throws InterruptedException {
/* 120 */     char c = 'Ϩ';
/* 121 */     while (paramInt > 0) {
/* 122 */       Thread.sleep((paramInt > c) ? c : paramInt);
/* 123 */       paramInt -= c;
/* 124 */       while ((System.currentTimeMillis() - m_T0) / c > m_Progress) {
/* 125 */         System.out.print(".");
/* 126 */         m_Tab--;
/* 127 */         m_Progress++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   static void fail(String paramString, Object... paramVarArgs) throws TestFailedException {
/* 133 */     System.out.println(" FAILED");
/* 134 */     System.out.println("------------------------------------------------------------");
/* 135 */     System.out.printf(paramString, paramVarArgs);
/* 136 */     System.out.println();
/* 137 */     System.out.println("------------------------------------------------------------");
/* 138 */     throw new TestFailedException();
/*     */   }
/*     */ 
/*     */   
/*     */   static void finishedOK() {
/* 143 */     finishedOK("", new Object[0]);
/*     */   }
/*     */   
/*     */   static void finishedOK(String paramString, Object... paramVarArgs) {
/* 147 */     for (byte b = 0; b < m_Tab; b++)
/* 148 */       System.out.print("."); 
/* 149 */     System.out.printf(" OK " + paramString, paramVarArgs);
/* 150 */     System.out.println();
/*     */   }
/*     */   
/*     */   public static void init(String[] paramArrayOfString) {
/* 154 */     m_TestPortName = "cu.usbserial-FTOXM3NX";
/* 155 */     if (paramArrayOfString.length > 0)
/* 156 */       m_TestPortName = paramArrayOfString[0]; 
/* 157 */     Enumeration<CommPortIdentifier> enumeration = CommPortIdentifier.getPortIdentifiers();
/* 158 */     boolean bool = false;
/* 159 */     String str = null;
/* 160 */     while (enumeration.hasMoreElements()) {
/* 161 */       CommPortIdentifier commPortIdentifier = enumeration.nextElement();
/* 162 */       if (commPortIdentifier.getPortType() == 1) {
/* 163 */         if (commPortIdentifier.getName().equals(m_TestPortName))
/* 164 */           bool = true; 
/* 165 */         str = commPortIdentifier.getName();
/*     */       } 
/*     */     } 
/* 168 */     if (!bool) {
/* 169 */       m_TestPortName = str;
/*     */     }
/*     */   }
/*     */   
/*     */   public static String getPortName() {
/* 174 */     return m_TestPortName;
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\testsuite\TestBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */