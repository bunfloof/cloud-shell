/*     */ package purejavacomm.testsuite;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Test10
/*     */   extends TestBase
/*     */ {
/*     */   static volatile boolean m_ReadThreadRunning;
/*     */   static volatile boolean m_ThreadStarted;
/*  40 */   static volatile int m_ReadBytes = 0;
/*     */   
/*     */   static volatile long m_T0;
/*     */   
/*     */   static volatile long m_T1;
/*     */ 
/*     */   
/*     */   static void run() throws Exception {
/*     */     try {
/*  49 */       begin("Test10 - treshold 100, timeout disabled ");
/*  50 */       openPort();
/*  51 */       m_Out = m_Port.getOutputStream();
/*  52 */       m_In = m_Port.getInputStream();
/*     */       
/*  54 */       byte[] arrayOfByte1 = new byte[1000];
/*  55 */       final byte[] rxbuffer = new byte[arrayOfByte1.length];
/*     */       
/*  57 */       m_Port.disableReceiveTimeout();
/*  58 */       m_Port.enableReceiveThreshold(128);
/*     */       
/*  60 */       Thread thread = new Thread(new Runnable() {
/*     */             public void run() {
/*  62 */               Test10.m_ReadThreadRunning = true;
/*  63 */               Test10.m_ThreadStarted = true;
/*     */               try {
/*  65 */                 Test10.m_ReadBytes = TestBase.m_In.read(rxbuffer, 0, rxbuffer.length);
/*  66 */                 Test10.m_T1 = System.currentTimeMillis();
/*  67 */               } catch (IOException iOException) {
/*  68 */                 iOException.printStackTrace();
/*     */               } 
/*  70 */               Test10.m_ReadThreadRunning = false;
/*     */             }
/*     */           });
/*     */       
/*  74 */       m_ReadThreadRunning = false;
/*  75 */       m_ThreadStarted = false;
/*  76 */       m_ReadBytes = -666;
/*  77 */       thread.start();
/*  78 */       while (!m_ThreadStarted)
/*  79 */         Thread.sleep(10L); 
/*     */       char c;
/*  81 */       for (c = Character.MIN_VALUE; c < '\020'; c++) {
/*  82 */         byte b1 = 8;
/*  83 */         sleep(b1 * 10);
/*  84 */         if (!m_ReadThreadRunning)
/*  85 */           fail("read did not block but returned with " + m_ReadBytes + " bytes", new Object[0]); 
/*  86 */         m_Out.write(arrayOfByte1, 0, b1);
/*     */       } 
/*  88 */       m_T0 = System.currentTimeMillis();
/*  89 */       Thread.sleep(100L);
/*  90 */       c = 'ߐ';
/*  91 */       while (--c > '\000' && m_ReadThreadRunning)
/*  92 */         Thread.sleep(5L); 
/*  93 */       if (c <= '\000') {
/*  94 */         fail("read did not return in time", new Object[0]);
/*     */       }
/*  96 */       if (m_ReadBytes != 128)
/*  97 */         fail("was expecting read to return 128 but got " + m_ReadBytes, new Object[0]); 
/*  98 */       int i = (int)(m_T1 - m_T0);
/*  99 */       byte b = 30;
/* 100 */       if (i > b) {
/* 101 */         fail("was expecting read to happen in " + b + " but it took " + i + " msec", new Object[0]);
/*     */       }
/*     */ 
/*     */       
/* 105 */       thread = new Thread(new Runnable() {
/*     */             public void run() {
/* 107 */               Test10.m_ReadThreadRunning = true;
/* 108 */               Test10.m_ThreadStarted = true;
/*     */               try {
/* 110 */                 Test10.m_ReadBytes = TestBase.m_In.read(rxbuffer, 0, 64);
/* 111 */                 Test10.m_T1 = System.currentTimeMillis();
/* 112 */               } catch (IOException iOException) {
/* 113 */                 iOException.printStackTrace();
/*     */               } 
/* 115 */               Test10.m_ReadThreadRunning = false;
/*     */             }
/*     */           });
/*     */       
/* 119 */       m_ReadThreadRunning = false;
/* 120 */       m_ThreadStarted = false;
/* 121 */       m_ReadBytes = -666;
/* 122 */       thread.start();
/* 123 */       while (!m_ThreadStarted) {
/* 124 */         Thread.sleep(10L);
/*     */       }
/* 126 */       for (c = Character.MIN_VALUE; c < '\b'; c++) {
/* 127 */         i = 8;
/* 128 */         sleep(i * 10);
/* 129 */         if (!m_ReadThreadRunning)
/* 130 */           fail("read did not block but returned with " + m_ReadBytes + " bytes", new Object[0]); 
/* 131 */         m_Out.write(arrayOfByte1, 0, i);
/*     */       } 
/* 133 */       m_T0 = System.currentTimeMillis();
/* 134 */       Thread.sleep(100L);
/* 135 */       c = 'È';
/* 136 */       while (--c > '\000' && m_ReadThreadRunning)
/* 137 */         Thread.sleep(5L); 
/* 138 */       if (c <= '\000') {
/* 139 */         fail("read did not return in time", new Object[0]);
/*     */       }
/* 141 */       if (m_ReadBytes != 64)
/* 142 */         fail("was expecting read to return 128 but got " + m_ReadBytes, new Object[0]); 
/* 143 */       i = (int)(m_T1 - m_T0);
/* 144 */       b = 30;
/* 145 */       if (i > b) {
/* 146 */         fail("was expecting read to happen in " + b + " but it took " + i + " msec", new Object[0]);
/*     */       }
/*     */       
/* 149 */       finishedOK();
/*     */     } finally {
/* 151 */       closePort();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\testsuite\Test10.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */