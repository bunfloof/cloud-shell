/*    */ package purejavacomm.testsuite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Test5
/*    */   extends TestBase
/*    */ {
/* 36 */   private static Exception m_Exception = null;
/*    */   private static Thread m_Receiver;
/*    */   private static Thread m_Transmitter;
/*    */   
/*    */   static void run() throws Exception {
/*    */     try {
/* 42 */       begin("Test5 - timeout");
/* 43 */       openPort();
/*    */       
/* 45 */       m_Receiver = new Thread(new Runnable() {
/*    */             public void run() {
/*    */               
/* 48 */               try { TestBase.sync(2);
/* 49 */                 TestBase.m_Port.disableReceiveThreshold();
/* 50 */                 TestBase.m_Port.enableReceiveTimeout(1000);
/* 51 */                 long l1 = System.currentTimeMillis();
/* 52 */                 byte[] arrayOfByte = { 0 };
/* 53 */                 int i = TestBase.m_In.read(arrayOfByte);
/* 54 */                 long l2 = System.currentTimeMillis() - l1;
/* 55 */                 if (i != 0)
/* 56 */                   TestBase.fail("read did not time out as expected, read returned %d > 0", new Object[] { Integer.valueOf(i) }); 
/* 57 */                 if (l2 < 990L)
/* 58 */                   TestBase.fail("read timed out early, expected 1000 msec, got %d msec", new Object[] { Long.valueOf(l2) }); 
/* 59 */                 if (l2 > 1020L)
/* 60 */                   TestBase.fail("read timed out with suspicious delay, expected 1000 msec, got %d msec", new Object[] { Long.valueOf(l2) });  }
/* 61 */               catch (InterruptedException interruptedException) {  }
/* 62 */               catch (Exception exception)
/* 63 */               { if (Test5.m_Exception == null)
/* 64 */                   Test5.m_Exception = exception; 
/* 65 */                 Test5.m_Receiver.interrupt();
/* 66 */                 Test5.m_Transmitter.interrupt(); }
/*    */             
/*    */             }
/*    */           });
/*    */ 
/*    */       
/* 72 */       m_Transmitter = new Thread(new Runnable() {
/*    */             public void run() {
/*    */               
/* 75 */               try { TestBase.sync(2); }
/* 76 */               catch (InterruptedException interruptedException) {  }
/* 77 */               catch (Exception exception)
/* 78 */               { exception.printStackTrace();
/* 79 */                 if (Test5.m_Exception == null)
/* 80 */                   Test5.m_Exception = exception; 
/* 81 */                 Test5.m_Receiver.interrupt();
/* 82 */                 Test5.m_Transmitter.interrupt(); }
/*    */             
/*    */             }
/*    */           });
/*    */       
/* 87 */       m_Receiver.start();
/* 88 */       m_Transmitter.start();
/*    */       
/* 90 */       while (m_Receiver.isAlive() || m_Transmitter.isAlive()) {
/* 91 */         sleep(100);
/*    */       }
/*    */       
/* 94 */       if (m_Exception != null)
/* 95 */         throw m_Exception; 
/* 96 */       finishedOK();
/*    */     } finally {
/* 98 */       closePort();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\testsuite\Test5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */