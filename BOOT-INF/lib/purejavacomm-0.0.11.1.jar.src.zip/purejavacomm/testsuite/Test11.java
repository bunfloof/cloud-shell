/*    */ package purejavacomm.testsuite;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Test11
/*    */   extends TestBase
/*    */ {
/*    */   static volatile boolean m_ReadThreadRunning;
/*    */   
/*    */   static void run() throws Exception {
/*    */     try {
/* 43 */       begin("Test11 - exit from blocking read ");
/* 44 */       openPort();
/*    */       
/* 46 */       m_Out = m_Port.getOutputStream();
/* 47 */       m_In = m_Port.getInputStream();
/*    */       
/* 49 */       m_Port.disableReceiveTimeout();
/* 50 */       m_Port.disableReceiveThreshold();
/*    */       
/* 52 */       final byte[] rxbuffer = new byte[1];
/*    */       
/* 54 */       Thread thread = new Thread(new Runnable() {
/*    */             public void run() {
/* 56 */               Test11.m_ReadThreadRunning = true;
/*    */               try {
/* 58 */                 int i = TestBase.m_In.read(rxbuffer, 0, rxbuffer.length);
/* 59 */               } catch (IOException iOException) {}
/*    */               
/* 61 */               Test11.m_ReadThreadRunning = false;
/*    */             }
/*    */           });
/*    */ 
/*    */       
/* 66 */       m_ReadThreadRunning = false;
/* 67 */       thread.start();
/* 68 */       while (!m_ReadThreadRunning)
/* 69 */         Thread.sleep(10L); 
/* 70 */       closePort();
/* 71 */       Thread.sleep(1000L);
/* 72 */       if (m_ReadThreadRunning)
/* 73 */         fail("closing failed to interrupt a blocking read()", new Object[0]); 
/* 74 */       finishedOK();
/*    */     } finally {
/* 76 */       closePort();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\testsuite\Test11.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */