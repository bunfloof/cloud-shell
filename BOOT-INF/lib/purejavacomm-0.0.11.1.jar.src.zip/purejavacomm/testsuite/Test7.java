/*     */ package purejavacomm.testsuite;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Test7
/*     */   extends TestBase
/*     */ {
/*  36 */   private static Exception m_Exception = null;
/*     */   private static Thread m_Receiver;
/*     */   private static Thread m_Transmitter;
/*     */   private static volatile long m_T0;
/*     */   
/*     */   static void run() throws Exception {
/*     */     try {
/*  43 */       begin("Test7 - threshold");
/*  44 */       openPort();
/*     */       
/*  46 */       m_Receiver = new Thread(new Runnable() {
/*     */             public void run() {
/*     */               
/*  49 */               try { TestBase.sync(2);
/*  50 */                 TestBase.m_Port.enableReceiveThreshold(7);
/*  51 */                 TestBase.m_Port.disableReceiveTimeout();
/*  52 */                 byte[] arrayOfByte = new byte[8];
/*  53 */                 int i = TestBase.m_In.read(arrayOfByte);
/*  54 */                 long l = System.currentTimeMillis() - Test7.m_T0;
/*  55 */                 if (i != 7)
/*  56 */                   TestBase.fail("read did not get 7 bytes as expected, got %d", new Object[] { Integer.valueOf(i) }); 
/*  57 */                 if (l < 10000L) {
/*  58 */                   TestBase.fail("timed out in %d though we got 7 bytes", new Object[] { Long.valueOf(l) });
/*     */                 } }
/*  60 */               catch (InterruptedException interruptedException) {  }
/*  61 */               catch (Exception exception)
/*  62 */               { if (Test7.m_Exception == null)
/*  63 */                   Test7.m_Exception = exception; 
/*  64 */                 Test7.m_Receiver.interrupt();
/*  65 */                 Test7.m_Transmitter.interrupt(); }
/*     */             
/*     */             }
/*     */           });
/*     */ 
/*     */       
/*  71 */       m_Transmitter = new Thread(new Runnable() {
/*     */             public void run() {
/*     */               
/*  74 */               try { TestBase.sync(2);
/*  75 */                 Test7.m_T0 = System.currentTimeMillis();
/*  76 */                 TestBase.sleep(10000);
/*  77 */                 TestBase.m_Out.write(new byte[7]); }
/*     */               
/*  79 */               catch (InterruptedException interruptedException) {  }
/*  80 */               catch (Exception exception)
/*  81 */               { exception.printStackTrace();
/*  82 */                 if (Test7.m_Exception == null)
/*  83 */                   Test7.m_Exception = exception; 
/*  84 */                 Test7.m_Receiver.interrupt();
/*  85 */                 Test7.m_Transmitter.interrupt(); }
/*     */             
/*     */             }
/*     */           });
/*     */       
/*  90 */       m_Receiver.start();
/*  91 */       m_Transmitter.start();
/*     */       
/*  93 */       while (m_Receiver.isAlive() || m_Transmitter.isAlive()) {
/*  94 */         sleep(100);
/*     */       }
/*     */       
/*  97 */       if (m_Exception != null)
/*  98 */         throw m_Exception; 
/*  99 */       finishedOK();
/*     */     } finally {
/* 101 */       closePort();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\testsuite\Test7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */