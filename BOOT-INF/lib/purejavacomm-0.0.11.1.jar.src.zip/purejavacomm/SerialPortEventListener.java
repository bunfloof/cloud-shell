package purejavacomm;

import java.util.EventListener;

public interface SerialPortEventListener extends EventListener {
  void serialEvent(SerialPortEvent paramSerialPortEvent);
}


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\SerialPortEventListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */