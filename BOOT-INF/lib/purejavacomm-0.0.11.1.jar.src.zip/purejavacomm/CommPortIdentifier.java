/*     */ package purejavacomm;
/*     */ 
/*     */ import java.io.FileDescriptor;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import jtermios.JTermios;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommPortIdentifier
/*     */ {
/*     */   public static final int PORT_SERIAL = 1;
/*     */   public static final int PORT_PARALLEL = 2;
/*  45 */   private static volatile Object m_Mutex = new Object();
/*     */   
/*     */   private volatile String m_PortName;
/*     */   private volatile int m_PortType;
/*     */   private volatile CommDriver m_Driver;
/*  50 */   private static volatile Hashtable<String, CommPortIdentifier> m_PortIdentifiers = new Hashtable<String, CommPortIdentifier>();
/*  51 */   private static volatile Hashtable<CommPort, CommPortIdentifier> m_OpenPorts = new Hashtable<CommPort, CommPortIdentifier>();
/*  52 */   private static volatile Hashtable<CommPortIdentifier, String> m_Owners = new Hashtable<CommPortIdentifier, String>();
/*  53 */   private volatile Hashtable<CommPortIdentifier, List<CommPortOwnershipListener>> m_OwnerShipListeners = new Hashtable<CommPortIdentifier, List<CommPortOwnershipListener>>();
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  57 */     return (paramObject instanceof CommPortIdentifier && this.m_PortName.equals(((CommPortIdentifier)paramObject).m_PortName));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  62 */     return this.m_PortName.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addPortName(String paramString, int paramInt, CommDriver paramCommDriver) {
/*  69 */     synchronized (m_Mutex) {
/*  70 */       m_PortIdentifiers.put(paramString, new CommPortIdentifier(paramString, paramInt, paramCommDriver));
/*     */     } 
/*     */   }
/*     */   
/*     */   private CommPortIdentifier(String paramString, int paramInt, CommDriver paramCommDriver) {
/*  75 */     this.m_PortName = paramString;
/*  76 */     this.m_PortType = paramInt;
/*  77 */     this.m_Driver = paramCommDriver;
/*     */   }
/*     */   
/*     */   public static CommPortIdentifier getPortIdentifier(String paramString) throws NoSuchPortException {
/*  81 */     synchronized (m_Mutex) {
/*  82 */       boolean bool = false;
/*  83 */       for (CommPortIdentifier commPortIdentifier : m_OpenPorts.values()) {
/*  84 */         if (commPortIdentifier.getName().equals(paramString))
/*  85 */           return commPortIdentifier; 
/*  86 */       }  if (bool) {
/*  87 */         Enumeration<CommPortIdentifier> enumeration = getPortIdentifiers();
/*  88 */         while (enumeration.hasMoreElements()) {
/*  89 */           CommPortIdentifier commPortIdentifier = enumeration.nextElement();
/*  90 */           if (commPortIdentifier.getName().equals(paramString))
/*  91 */             return commPortIdentifier; 
/*     */         } 
/*     */       } else {
/*  94 */         CommPortIdentifier commPortIdentifier = m_PortIdentifiers.get(paramString);
/*  95 */         if (commPortIdentifier != null) {
/*  96 */           return commPortIdentifier;
/*     */         }
/*     */         
/*  99 */         int i = JTermios.open(paramString, JTermios.O_RDWR | JTermios.O_NOCTTY | JTermios.O_NONBLOCK);
/* 100 */         if (i != -1) {
/*     */ 
/*     */           
/* 103 */           JTermios.close(i);
/* 104 */           return new CommPortIdentifier(paramString, 1, null);
/*     */         } 
/* 106 */         if (JTermios.errno() == JTermios.EBUSY)
/* 107 */           return new CommPortIdentifier(paramString, 1, null); 
/*     */       } 
/* 109 */       throw new NoSuchPortException();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static CommPortIdentifier getPortIdentifier(CommPort paramCommPort) throws NoSuchPortException {
/* 114 */     synchronized (m_Mutex) {
/* 115 */       CommPortIdentifier commPortIdentifier = m_OpenPorts.get(paramCommPort);
/* 116 */       if (commPortIdentifier == null)
/* 117 */         throw new NoSuchPortException(); 
/* 118 */       return commPortIdentifier;
/*     */     } 
/*     */   }
/*     */   
/*     */   public CommPort open(String paramString, int paramInt) throws PortInUseException {
/* 123 */     synchronized (m_Mutex) {
/* 124 */       CommPort commPort; long l = System.currentTimeMillis();
/*     */       
/* 126 */       String str = m_Owners.get(this);
/* 127 */       if (str != null) {
/* 128 */         fireOwnershipEvent(3);
/*     */         try {
/* 130 */           while (System.currentTimeMillis() - l < paramInt) {
/* 131 */             m_Mutex.wait(5L);
/* 132 */             if (!isCurrentlyOwned())
/*     */               break; 
/*     */           } 
/* 135 */         } catch (InterruptedException interruptedException) {
/*     */           
/* 137 */           Thread.currentThread().interrupt();
/*     */         } 
/*     */       } 
/* 140 */       if (isCurrentlyOwned()) {
/* 141 */         throw new PortInUseException();
/*     */       }
/* 143 */       CommPortIdentifier commPortIdentifier = m_PortIdentifiers.get(this.m_PortName);
/*     */       
/* 145 */       if (commPortIdentifier != null) {
/* 146 */         commPort = commPortIdentifier.m_Driver.getCommPort(this.m_PortName, commPortIdentifier.m_PortType);
/*     */       } else {
/* 148 */         commPort = new PureJavaSerialPort(this.m_PortName, paramInt);
/* 149 */       }  m_OpenPorts.put(commPort, this);
/* 150 */       m_Owners.put(this, paramString);
/* 151 */       fireOwnershipEvent(1);
/* 152 */       return commPort;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void close(CommPort paramCommPort) {
/* 158 */     synchronized (m_Mutex) {
/* 159 */       CommPortIdentifier commPortIdentifier = m_OpenPorts.remove(paramCommPort);
/* 160 */       if (commPortIdentifier != null) {
/* 161 */         commPortIdentifier.fireOwnershipEvent(2);
/* 162 */         m_Owners.remove(commPortIdentifier);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public CommPort open(FileDescriptor paramFileDescriptor) throws UnsupportedCommOperationException {
/* 168 */     throw new UnsupportedCommOperationException();
/*     */   }
/*     */   
/*     */   public String getName() {
/* 172 */     return this.m_PortName;
/*     */   }
/*     */   
/*     */   public int getPortType() {
/* 176 */     return this.m_PortType;
/*     */   }
/*     */   
/*     */   public static Enumeration getPortIdentifiers() {
/* 180 */     synchronized (m_Mutex) {
/*     */       
/* 182 */       return new Enumeration()
/*     */         {
/*     */           
/* 185 */           List<CommPortIdentifier> m_PortIDs = new LinkedList<CommPortIdentifier>();
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Iterator<CommPortIdentifier> m_Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public boolean hasMoreElements() {
/* 197 */             return (this.m_Iterator != null) ? this.m_Iterator.hasNext() : false;
/*     */           }
/*     */           
/*     */           public Object nextElement() {
/* 201 */             return this.m_Iterator.next();
/*     */           }
/*     */         };
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getCurrentOwner() {
/* 208 */     synchronized (m_Mutex) {
/* 209 */       return m_Owners.get(this);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isCurrentlyOwned() {
/* 214 */     return (getCurrentOwner() != null);
/*     */   }
/*     */   
/*     */   public void addPortOwnershipListener(CommPortOwnershipListener paramCommPortOwnershipListener) {
/* 218 */     synchronized (m_Mutex) {
/* 219 */       List<CommPortOwnershipListener> list = this.m_OwnerShipListeners.get(this);
/* 220 */       if (list == null) {
/* 221 */         list = new LinkedList();
/* 222 */         this.m_OwnerShipListeners.put(this, list);
/*     */       } 
/* 224 */       list.add(paramCommPortOwnershipListener);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removePortOwnershipListener(CommPortOwnershipListener paramCommPortOwnershipListener) {
/* 229 */     synchronized (m_Mutex) {
/* 230 */       List list = this.m_OwnerShipListeners.get(this);
/* 231 */       if (list == null)
/*     */         return; 
/* 233 */       list.remove(paramCommPortOwnershipListener);
/* 234 */       if (list.isEmpty()) {
/* 235 */         this.m_OwnerShipListeners.remove(this);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void fireOwnershipEvent(int paramInt) {
/* 241 */     synchronized (m_Mutex) {
/* 242 */       List list = this.m_OwnerShipListeners.get(this);
/* 243 */       if (list == null)
/*     */         return; 
/* 245 */       for (CommPortOwnershipListener commPortOwnershipListener : list)
/* 246 */         commPortOwnershipListener.ownershipChange(paramInt); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\CommPortIdentifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */