package purejavacomm;

public class PortInUseException extends Exception {}


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\PortInUseException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */