/*    */ package purejavacomm;
/*    */ 
/*    */ public class PureJavaIllegalStateException
/*    */   extends IllegalStateException {
/*    */   public PureJavaIllegalStateException(String paramString) {
/*  6 */     super(paramString);
/*    */   }
/*    */   
/*    */   public PureJavaIllegalStateException(Exception paramException) {
/* 10 */     super(paramException);
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\PureJavaIllegalStateException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */