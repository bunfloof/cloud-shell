/*      */ package purejavacomm;
/*      */ 
/*      */ import com.sun.jna.Platform;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.util.TooManyListenersException;
/*      */ import jtermios.FDSet;
/*      */ import jtermios.JTermios;
/*      */ import jtermios.Termios;
/*      */ import jtermios.TimeVal;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PureJavaSerialPort
/*      */   extends SerialPort
/*      */ {
/*      */   final boolean USE_POLL;
/*      */   final boolean RAW_READ_MODE;
/*      */   private Thread m_Thread;
/*      */   private volatile SerialPortEventListener m_EventListener;
/*      */   private volatile OutputStream m_OutputStream;
/*      */   private volatile InputStream m_InputStream;
/*   54 */   private volatile int m_FD = -1;
/*      */   private volatile boolean m_HaveNudgePipe = false;
/*   56 */   private volatile int m_PipeWrFD = 0;
/*   57 */   private volatile int m_PipeRdFD = 0;
/*   58 */   private byte[] m_NudgeData = new byte[] { 0 };
/*      */   private volatile int m_BaudRate;
/*      */   private volatile int m_DataBits;
/*      */   private volatile int m_FlowControlMode;
/*      */   private volatile int m_Parity;
/*      */   private volatile int m_StopBits;
/*   64 */   private volatile Object m_ThresholdTimeoutLock = new Object();
/*      */   private volatile boolean m_TimeoutThresholdChanged = true;
/*      */   private volatile boolean m_ReceiveTimeoutEnabled;
/*      */   private volatile int m_ReceiveTimeoutValue;
/*      */   private volatile int m_ReceiveTimeoutVTIME;
/*      */   private volatile boolean m_ReceiveThresholdEnabled;
/*      */   private volatile int m_ReceiveThresholdValue;
/*      */   private volatile boolean m_PollingReadMode;
/*      */   private volatile boolean m_NotifyOnDataAvailable;
/*      */   private volatile boolean m_DataAvailableNotified;
/*      */   private volatile boolean m_NotifyOnOutputEmpty;
/*      */   private volatile boolean m_OutputEmptyNotified;
/*      */   private volatile boolean m_NotifyOnRI;
/*      */   private volatile boolean m_NotifyOnCTS;
/*      */   private volatile boolean m_NotifyOnDSR;
/*      */   private volatile boolean m_NotifyOnCD;
/*      */   private volatile boolean m_NotifyOnOverrunError;
/*      */   private volatile boolean m_NotifyOnParityError;
/*      */   private volatile boolean m_NotifyOnFramingError;
/*      */   private volatile boolean m_NotifyOnBreakInterrupt;
/*      */   private volatile boolean m_ThreadRunning;
/*      */   private volatile boolean m_ThreadStarted;
/*   86 */   private int[] m_ioctl = new int[] { 0 };
/*      */   
/*      */   private int m_ControlLineStates;
/*      */   
/*   90 */   private Termios m_Termios = new Termios();
/*      */   private int m_MinVTIME;
/*      */   
/*      */   private void sendDataEvents(boolean paramBoolean1, boolean paramBoolean2) {
/*   94 */     if (paramBoolean1 && this.m_NotifyOnDataAvailable && !this.m_DataAvailableNotified) {
/*   95 */       this.m_DataAvailableNotified = true;
/*   96 */       this.m_EventListener.serialEvent(new SerialPortEvent(this, 1, false, true));
/*      */     } 
/*   98 */     if (paramBoolean2 && this.m_NotifyOnOutputEmpty && !this.m_OutputEmptyNotified) {
/*   99 */       this.m_OutputEmptyNotified = true;
/*  100 */       this.m_EventListener.serialEvent(new SerialPortEvent(this, 2, false, true));
/*      */     } 
/*      */   }
/*      */   
/*      */   private synchronized void sendNonDataEvents() {
/*  105 */     if (JTermios.ioctl(this.m_FD, JTermios.TIOCMGET, this.m_ioctl) < 0)
/*      */       return; 
/*  107 */     int i = this.m_ControlLineStates;
/*  108 */     this.m_ControlLineStates = this.m_ioctl[0];
/*  109 */     int j = this.m_ControlLineStates;
/*  110 */     int k = i ^ j;
/*  111 */     if (k == 0) {
/*      */       return;
/*      */     }
/*      */     
/*      */     int m;
/*  116 */     if (this.m_NotifyOnCTS && ((m = JTermios.TIOCM_CTS) & k) != 0) {
/*  117 */       this.m_EventListener.serialEvent(new SerialPortEvent(this, 3, ((i & m) != 0), ((j & m) != 0)));
/*      */     }
/*  119 */     if (this.m_NotifyOnDSR && ((m = JTermios.TIOCM_DSR) & k) != 0) {
/*  120 */       this.m_EventListener.serialEvent(new SerialPortEvent(this, 4, ((i & m) != 0), ((j & m) != 0)));
/*      */     }
/*  122 */     if (this.m_NotifyOnRI && ((m = JTermios.TIOCM_RI) & k) != 0) {
/*  123 */       this.m_EventListener.serialEvent(new SerialPortEvent(this, 5, ((i & m) != 0), ((j & m) != 0)));
/*      */     }
/*  125 */     if (this.m_NotifyOnCD && ((m = JTermios.TIOCM_CD) & k) != 0) {
/*  126 */       this.m_EventListener.serialEvent(new SerialPortEvent(this, 6, ((i & m) != 0), ((j & m) != 0)));
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized void addEventListener(SerialPortEventListener paramSerialPortEventListener) throws TooManyListenersException {
/*  131 */     checkState();
/*  132 */     if (paramSerialPortEventListener == null)
/*  133 */       throw new IllegalArgumentException("eventListener cannot be null"); 
/*  134 */     if (this.m_EventListener != null)
/*  135 */       throw new TooManyListenersException(); 
/*  136 */     this.m_EventListener = paramSerialPortEventListener;
/*  137 */     if (!this.m_ThreadStarted) {
/*  138 */       this.m_ThreadStarted = true;
/*  139 */       this.m_Thread.start();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized int getBaudRate() {
/*  145 */     checkState();
/*  146 */     return this.m_BaudRate;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized int getDataBits() {
/*  151 */     checkState();
/*  152 */     return this.m_DataBits;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized int getFlowControlMode() {
/*  157 */     checkState();
/*  158 */     return this.m_FlowControlMode;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized int getParity() {
/*  163 */     checkState();
/*  164 */     return this.m_Parity;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized int getStopBits() {
/*  169 */     checkState();
/*  170 */     return this.m_StopBits;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized boolean isCD() {
/*  175 */     checkState();
/*  176 */     return getControlLineState(JTermios.TIOCM_CD);
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized boolean isCTS() {
/*  181 */     checkState();
/*  182 */     return getControlLineState(JTermios.TIOCM_CTS);
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized boolean isDSR() {
/*  187 */     checkState();
/*  188 */     return getControlLineState(JTermios.TIOCM_DSR);
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized boolean isDTR() {
/*  193 */     checkState();
/*  194 */     return getControlLineState(JTermios.TIOCM_DTR);
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized boolean isRI() {
/*  199 */     checkState();
/*  200 */     return getControlLineState(JTermios.TIOCM_RI);
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized boolean isRTS() {
/*  205 */     checkState();
/*  206 */     return getControlLineState(JTermios.TIOCM_RTS);
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void notifyOnBreakInterrupt(boolean paramBoolean) {
/*  211 */     checkState();
/*  212 */     this.m_NotifyOnBreakInterrupt = paramBoolean;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void notifyOnCTS(boolean paramBoolean) {
/*  217 */     checkState();
/*  218 */     if (paramBoolean)
/*  219 */       updateControlLineState(JTermios.TIOCM_CTS); 
/*  220 */     this.m_NotifyOnCTS = paramBoolean;
/*  221 */     nudgePipe();
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void notifyOnCarrierDetect(boolean paramBoolean) {
/*  226 */     checkState();
/*  227 */     if (paramBoolean)
/*  228 */       updateControlLineState(JTermios.TIOCM_CD); 
/*  229 */     this.m_NotifyOnCD = paramBoolean;
/*  230 */     nudgePipe();
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void notifyOnDSR(boolean paramBoolean) {
/*  235 */     checkState();
/*  236 */     if (paramBoolean)
/*  237 */       updateControlLineState(JTermios.TIOCM_DSR); 
/*  238 */     this.m_NotifyOnDSR = paramBoolean;
/*  239 */     nudgePipe();
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void notifyOnDataAvailable(boolean paramBoolean) {
/*  244 */     checkState();
/*  245 */     this.m_NotifyOnDataAvailable = paramBoolean;
/*  246 */     nudgePipe();
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void notifyOnFramingError(boolean paramBoolean) {
/*  251 */     checkState();
/*  252 */     this.m_NotifyOnFramingError = paramBoolean;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void notifyOnOutputEmpty(boolean paramBoolean) {
/*  257 */     checkState();
/*  258 */     this.m_NotifyOnOutputEmpty = paramBoolean;
/*  259 */     nudgePipe();
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void notifyOnOverrunError(boolean paramBoolean) {
/*  264 */     checkState();
/*  265 */     this.m_NotifyOnOverrunError = paramBoolean;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void notifyOnParityError(boolean paramBoolean) {
/*  270 */     checkState();
/*  271 */     this.m_NotifyOnParityError = paramBoolean;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void notifyOnRingIndicator(boolean paramBoolean) {
/*  276 */     checkState();
/*  277 */     if (paramBoolean)
/*  278 */       updateControlLineState(JTermios.TIOCM_RI); 
/*  279 */     this.m_NotifyOnRI = paramBoolean;
/*  280 */     nudgePipe();
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void removeEventListener() {
/*  285 */     checkState();
/*  286 */     this.m_EventListener = null;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void sendBreak(int paramInt) {
/*  291 */     checkState();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  305 */     JTermios.tcsendbreak(this.m_FD, paramInt);
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void setDTR(boolean paramBoolean) {
/*  310 */     checkState();
/*  311 */     setControlLineState(JTermios.TIOCM_DTR, paramBoolean);
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void setRTS(boolean paramBoolean) {
/*  316 */     checkState();
/*  317 */     setControlLineState(JTermios.TIOCM_RTS, paramBoolean);
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void disableReceiveFraming() {
/*  322 */     checkState();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void disableReceiveThreshold() {
/*  328 */     checkState();
/*  329 */     synchronized (this.m_ThresholdTimeoutLock) {
/*  330 */       this.m_ReceiveThresholdEnabled = false;
/*  331 */       thresholdOrTimeoutChanged();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void disableReceiveTimeout() {
/*  337 */     checkState();
/*  338 */     synchronized (this.m_ThresholdTimeoutLock) {
/*  339 */       this.m_ReceiveTimeoutEnabled = false;
/*  340 */       thresholdOrTimeoutChanged();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void enableReceiveThreshold(int paramInt) throws UnsupportedCommOperationException {
/*  346 */     checkState();
/*  347 */     if (paramInt < 0)
/*  348 */       throw new IllegalArgumentException("threshold" + paramInt + " < 0 "); 
/*  349 */     if (this.RAW_READ_MODE && paramInt > 255)
/*  350 */       throw new IllegalArgumentException("threshold" + paramInt + " > 255 in raw read mode"); 
/*  351 */     synchronized (this.m_ThresholdTimeoutLock) {
/*  352 */       this.m_ReceiveThresholdEnabled = true;
/*  353 */       this.m_ReceiveThresholdValue = paramInt;
/*  354 */       thresholdOrTimeoutChanged();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void enableReceiveTimeout(int paramInt) throws UnsupportedCommOperationException {
/*  360 */     if (paramInt < 0)
/*  361 */       throw new IllegalArgumentException("threshold" + paramInt + " < 0 "); 
/*  362 */     if ((paramInt + 99) / 100 > 255) {
/*  363 */       throw new UnsupportedCommOperationException("threshold" + paramInt + " too large ");
/*      */     }
/*  365 */     checkState();
/*  366 */     synchronized (this.m_ThresholdTimeoutLock) {
/*  367 */       this.m_ReceiveTimeoutEnabled = true;
/*  368 */       this.m_ReceiveTimeoutValue = paramInt;
/*  369 */       thresholdOrTimeoutChanged();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void enableReceiveFraming(int paramInt) throws UnsupportedCommOperationException {
/*  375 */     checkState();
/*  376 */     throw new UnsupportedCommOperationException();
/*      */   }
/*      */   
/*      */   private void thresholdOrTimeoutChanged() {
/*  380 */     this.m_PollingReadMode = ((this.m_ReceiveTimeoutEnabled && this.m_ReceiveTimeoutValue == 0) || (this.m_ReceiveThresholdEnabled && this.m_ReceiveThresholdValue == 0));
/*  381 */     this.m_ReceiveTimeoutVTIME = (this.m_ReceiveTimeoutValue + 99) / 100;
/*  382 */     this.m_TimeoutThresholdChanged = true;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized int getInputBufferSize() {
/*  387 */     checkState();
/*      */     
/*  389 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized int getOutputBufferSize() {
/*  394 */     checkState();
/*      */     
/*  396 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void setFlowControlMode(int paramInt) throws UnsupportedCommOperationException {
/*  401 */     checkState();
/*  402 */     synchronized (this.m_Termios) {
/*  403 */       this.m_Termios.c_iflag &= JTermios.IXANY ^ 0xFFFFFFFF;
/*      */       
/*  405 */       if ((paramInt & 0x3) != 0) {
/*  406 */         this.m_Termios.c_cflag |= JTermios.CRTSCTS;
/*      */       } else {
/*  408 */         this.m_Termios.c_cflag &= JTermios.CRTSCTS ^ 0xFFFFFFFF;
/*      */       } 
/*  410 */       if ((paramInt & 0x4) != 0) {
/*  411 */         this.m_Termios.c_iflag |= JTermios.IXOFF;
/*      */       } else {
/*  413 */         this.m_Termios.c_iflag &= JTermios.IXOFF ^ 0xFFFFFFFF;
/*      */       } 
/*  415 */       if ((paramInt & 0x8) != 0) {
/*  416 */         this.m_Termios.c_iflag |= JTermios.IXON;
/*      */       } else {
/*  418 */         this.m_Termios.c_iflag &= JTermios.IXON ^ 0xFFFFFFFF;
/*      */       } 
/*  420 */       checkReturnCode(JTermios.tcsetattr(this.m_FD, JTermios.TCSANOW, this.m_Termios));
/*      */       
/*  422 */       this.m_FlowControlMode = paramInt;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void setSerialPortParams(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws UnsupportedCommOperationException {
/*  428 */     checkState();
/*  429 */     synchronized (this.m_Termios) {
/*  430 */       Termios termios = new Termios();
/*      */ 
/*      */       
/*  433 */       termios.set(this.m_Termios); try {
/*      */         int i;
/*      */         byte b;
/*  436 */         checkReturnCode(JTermios.setspeed(this.m_FD, this.m_Termios, paramInt1));
/*      */ 
/*      */         
/*  439 */         switch (paramInt2) {
/*      */           case 5:
/*  441 */             i = JTermios.CS5;
/*      */             break;
/*      */           case 6:
/*  444 */             i = JTermios.CS6;
/*      */             break;
/*      */           case 7:
/*  447 */             i = JTermios.CS7;
/*      */             break;
/*      */           case 8:
/*  450 */             i = JTermios.CS8;
/*      */             break;
/*      */           default:
/*  453 */             throw new UnsupportedCommOperationException("dataBits = " + paramInt2);
/*      */         } 
/*      */ 
/*      */         
/*  457 */         switch (paramInt3) {
/*      */           case 1:
/*  459 */             b = 1;
/*      */             break;
/*      */           case 2:
/*  462 */             b = 2;
/*      */             break;
/*      */           default:
/*  465 */             throw new UnsupportedCommOperationException("stopBits = " + paramInt3);
/*      */         } 
/*      */         
/*  468 */         int j = this.m_Termios.c_iflag;
/*  469 */         int k = this.m_Termios.c_cflag;
/*  470 */         switch (paramInt4) {
/*      */           case 0:
/*  472 */             k &= JTermios.PARENB ^ 0xFFFFFFFF;
/*  473 */             j &= (JTermios.INPCK | JTermios.ISTRIP) ^ 0xFFFFFFFF;
/*      */             break;
/*      */           case 2:
/*  476 */             k |= JTermios.PARENB;
/*  477 */             k &= JTermios.PARODD ^ 0xFFFFFFFF;
/*  478 */             j &= (JTermios.INPCK | JTermios.ISTRIP) ^ 0xFFFFFFFF;
/*      */             break;
/*      */           case 1:
/*  481 */             k |= JTermios.PARENB;
/*  482 */             k |= JTermios.PARODD;
/*  483 */             j &= (JTermios.INPCK | JTermios.ISTRIP) ^ 0xFFFFFFFF;
/*      */             break;
/*      */           case 3:
/*  486 */             k |= JTermios.PARENB;
/*  487 */             k |= JTermios.CMSPAR;
/*  488 */             k |= JTermios.PARODD;
/*  489 */             j &= (JTermios.INPCK | JTermios.ISTRIP) ^ 0xFFFFFFFF;
/*      */             break;
/*      */           case 4:
/*  492 */             k |= JTermios.PARENB;
/*  493 */             k |= JTermios.CMSPAR;
/*  494 */             j &= (JTermios.INPCK | JTermios.ISTRIP) ^ 0xFFFFFFFF;
/*      */             break;
/*      */           default:
/*  497 */             throw new UnsupportedCommOperationException("parity = " + paramInt4);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  502 */         k &= JTermios.CSIZE ^ 0xFFFFFFFF;
/*  503 */         k |= i;
/*      */         
/*  505 */         if (b == 2) {
/*  506 */           k |= JTermios.CSTOPB;
/*      */         } else {
/*  508 */           k &= JTermios.CSTOPB ^ 0xFFFFFFFF;
/*      */         } 
/*  510 */         this.m_Termios.c_cflag = k;
/*  511 */         this.m_Termios.c_iflag = j;
/*      */         
/*  513 */         if (JTermios.tcsetattr(this.m_FD, JTermios.TCSANOW, this.m_Termios) != 0) {
/*  514 */           throw new UnsupportedCommOperationException();
/*      */         }
/*      */         
/*  517 */         this.m_BaudRate = paramInt1;
/*  518 */         this.m_Parity = paramInt4;
/*  519 */         this.m_DataBits = paramInt2;
/*  520 */         this.m_StopBits = paramInt3;
/*  521 */       } catch (UnsupportedCommOperationException unsupportedCommOperationException) {
/*  522 */         this.m_Termios.set(termios);
/*  523 */         checkReturnCode(JTermios.tcsetattr(this.m_FD, JTermios.TCSANOW, this.m_Termios));
/*  524 */         throw unsupportedCommOperationException;
/*  525 */       } catch (IllegalStateException illegalStateException) {
/*  526 */         this.m_Termios.set(termios);
/*  527 */         checkReturnCode(JTermios.tcsetattr(this.m_FD, JTermios.TCSANOW, this.m_Termios));
/*  528 */         if (illegalStateException instanceof PureJavaIllegalStateException) {
/*  529 */           throw illegalStateException;
/*      */         }
/*  531 */         throw new PureJavaIllegalStateException(illegalStateException);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNativeFileDescriptor() {
/*  598 */     return this.m_FD;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized OutputStream getOutputStream() throws IOException {
/*  603 */     checkState();
/*  604 */     if (this.m_OutputStream == null) {
/*  605 */       this.m_OutputStream = new OutputStream()
/*      */         {
/*  607 */           private byte[] im_Buffer = new byte[2048];
/*      */ 
/*      */           
/*      */           public final void write(int param1Int) throws IOException {
/*  611 */             PureJavaSerialPort.this.checkState();
/*  612 */             byte[] arrayOfByte = { (byte)param1Int };
/*  613 */             write(arrayOfByte, 0, 1);
/*      */           }
/*      */ 
/*      */           
/*      */           public final void write(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
/*  618 */             if (param1ArrayOfbyte == null)
/*  619 */               throw new IllegalArgumentException(); 
/*  620 */             if (param1Int1 < 0 || param1Int2 < 0 || param1Int1 + param1Int2 > param1ArrayOfbyte.length)
/*  621 */               throw new IndexOutOfBoundsException("buffer.lengt " + param1ArrayOfbyte.length + " offset " + param1Int1 + " length " + param1Int2); 
/*  622 */             PureJavaSerialPort.this.checkState();
/*  623 */             while (param1Int2 > 0) {
/*  624 */               int i = param1ArrayOfbyte.length - param1Int1;
/*  625 */               if (i > this.im_Buffer.length)
/*  626 */                 i = this.im_Buffer.length; 
/*  627 */               if (i > param1Int2)
/*  628 */                 i = param1Int2; 
/*  629 */               if (param1Int1 > 0) {
/*  630 */                 System.arraycopy(param1ArrayOfbyte, param1Int1, this.im_Buffer, 0, i);
/*  631 */                 i = JTermios.write(PureJavaSerialPort.this.m_FD, this.im_Buffer, i);
/*      */               } else {
/*  633 */                 i = JTermios.write(PureJavaSerialPort.this.m_FD, param1ArrayOfbyte, i);
/*      */               } 
/*  635 */               if (i < 0) {
/*  636 */                 PureJavaSerialPort.this.close();
/*  637 */                 throw new IOException();
/*      */               } 
/*      */               
/*  640 */               param1Int2 -= i;
/*  641 */               param1Int1 += i;
/*      */             } 
/*  643 */             PureJavaSerialPort.this.m_OutputEmptyNotified = false;
/*      */           }
/*      */ 
/*      */           
/*      */           public final void write(byte[] param1ArrayOfbyte) throws IOException {
/*  648 */             write(param1ArrayOfbyte, 0, param1ArrayOfbyte.length);
/*      */           }
/*      */ 
/*      */           
/*      */           public void close() throws IOException {
/*  653 */             super.close();
/*      */           }
/*      */ 
/*      */           
/*      */           public final void flush() throws IOException {
/*  658 */             PureJavaSerialPort.this.checkState();
/*  659 */             if (JTermios.tcdrain(PureJavaSerialPort.this.m_FD) < 0) {
/*  660 */               close();
/*  661 */               throw new IOException();
/*      */             } 
/*      */           }
/*      */         };
/*      */     }
/*  666 */     return this.m_OutputStream;
/*      */   }
/*      */   
/*      */   public synchronized InputStream getInputStream() throws IOException {
/*  670 */     checkState();
/*  671 */     if (this.m_InputStream == null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  680 */       this.m_InputStream = new InputStream()
/*      */         {
/*      */           private int[] im_Available;
/*      */           
/*      */           private byte[] im_Buffer;
/*      */           
/*      */           private int im_VTIME;
/*      */           
/*      */           private int im_VMIN;
/*      */           
/*      */           private int[] im_ReadPollFD;
/*      */           
/*      */           private byte[] im_Nudge;
/*      */           
/*      */           private FDSet im_ReadFDSet;
/*      */           
/*      */           private TimeVal im_ReadTimeVal;
/*      */           
/*      */           private int im_PollFDn;
/*      */           
/*      */           private boolean im_ReceiveTimeoutEnabled;
/*      */           
/*      */           private int im_ReceiveTimeoutValue;
/*      */           
/*      */           private boolean im_ReceiveThresholdEnabled;
/*      */           
/*      */           private int im_ReceiveThresholdValue;
/*      */           
/*      */           private boolean im_PollingReadMode;
/*      */           
/*      */           private int im_ReceiveTimeoutVTIME;
/*      */           
/*      */           public final int available() throws IOException {
/*  713 */             PureJavaSerialPort.this.checkState();
/*  714 */             if (JTermios.ioctl(PureJavaSerialPort.this.m_FD, JTermios.FIONREAD, this.im_Available) < 0) {
/*  715 */               PureJavaSerialPort.this.close();
/*  716 */               throw new IOException();
/*      */             } 
/*  718 */             return this.im_Available[0];
/*      */           }
/*      */ 
/*      */           
/*      */           public final int read() throws IOException {
/*  723 */             PureJavaSerialPort.this.checkState();
/*  724 */             byte[] arrayOfByte = { 0 };
/*  725 */             int i = read(arrayOfByte, 0, 1);
/*      */             
/*  727 */             return (i > 0) ? (arrayOfByte[0] & 0xFF) : -1;
/*      */           }
/*      */ 
/*      */           
/*      */           public void close() throws IOException {
/*  732 */             super.close();
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public final int read(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
/*  738 */             if (param1ArrayOfbyte == null)
/*  739 */               throw new IllegalArgumentException("buffer null"); 
/*  740 */             if (param1Int2 == 0)
/*  741 */               return 0; 
/*  742 */             if (param1Int1 < 0 || param1Int2 < 0 || param1Int1 + param1Int2 > param1ArrayOfbyte.length) {
/*  743 */               throw new IndexOutOfBoundsException("buffer.length " + param1ArrayOfbyte.length + " offset " + param1Int1 + " length " + param1Int2);
/*      */             }
/*  745 */             if (PureJavaSerialPort.this.RAW_READ_MODE) {
/*  746 */               int k; if (PureJavaSerialPort.this.m_TimeoutThresholdChanged) {
/*  747 */                 synchronized (PureJavaSerialPort.this.m_ThresholdTimeoutLock) {
/*  748 */                   boolean bool1 = PureJavaSerialPort.this.m_ReceiveTimeoutEnabled ? PureJavaSerialPort.this.m_ReceiveTimeoutVTIME : false;
/*  749 */                   boolean bool2 = PureJavaSerialPort.this.m_ReceiveThresholdEnabled ? PureJavaSerialPort.this.m_ReceiveThresholdValue : true;
/*  750 */                   synchronized (PureJavaSerialPort.this.m_Termios) {
/*  751 */                     PureJavaSerialPort.this.m_Termios.c_cc[JTermios.VTIME] = (byte)bool1;
/*  752 */                     PureJavaSerialPort.this.m_Termios.c_cc[JTermios.VMIN] = (byte)bool2;
/*  753 */                     PureJavaSerialPort.this.checkReturnCode(JTermios.tcsetattr(PureJavaSerialPort.this.m_FD, JTermios.TCSANOW, PureJavaSerialPort.this.m_Termios));
/*      */                   } 
/*  755 */                   PureJavaSerialPort.this.m_TimeoutThresholdChanged = false;
/*      */                 } 
/*      */               }
/*      */               
/*  759 */               if (param1Int1 > 0) {
/*  760 */                 if (param1Int2 < this.im_Buffer.length) {
/*  761 */                   k = JTermios.read(PureJavaSerialPort.this.m_FD, this.im_Buffer, param1Int2);
/*      */                 } else {
/*  763 */                   k = JTermios.read(PureJavaSerialPort.this.m_FD, this.im_Buffer, this.im_Buffer.length);
/*  764 */                 }  if (k > 0)
/*  765 */                   System.arraycopy(this.im_Buffer, 0, param1ArrayOfbyte, param1Int1, k); 
/*      */               } else {
/*  767 */                 k = JTermios.read(PureJavaSerialPort.this.m_FD, param1ArrayOfbyte, param1Int2);
/*  768 */               }  PureJavaSerialPort.this.m_DataAvailableNotified = false;
/*  769 */               return k;
/*      */             } 
/*      */ 
/*      */             
/*  773 */             if (PureJavaSerialPort.this.m_FD < 0) {
/*  774 */               PureJavaSerialPort.this.failWithIllegalStateException();
/*      */             }
/*  776 */             if (PureJavaSerialPort.this.m_TimeoutThresholdChanged) {
/*  777 */               synchronized (PureJavaSerialPort.this.m_ThresholdTimeoutLock) {
/*      */                 
/*  779 */                 this.im_ReceiveTimeoutEnabled = PureJavaSerialPort.this.m_ReceiveTimeoutEnabled;
/*  780 */                 this.im_ReceiveTimeoutValue = PureJavaSerialPort.this.m_ReceiveTimeoutValue;
/*  781 */                 this.im_ReceiveThresholdEnabled = PureJavaSerialPort.this.m_ReceiveThresholdEnabled;
/*  782 */                 this.im_ReceiveThresholdValue = PureJavaSerialPort.this.m_ReceiveThresholdValue;
/*  783 */                 this.im_PollingReadMode = PureJavaSerialPort.this.m_PollingReadMode;
/*  784 */                 this.im_ReceiveTimeoutVTIME = PureJavaSerialPort.this.m_ReceiveTimeoutVTIME;
/*  785 */                 PureJavaSerialPort.this.m_TimeoutThresholdChanged = false;
/*      */               } 
/*      */             }
/*      */             
/*  789 */             int i = param1Int2;
/*  790 */             int j = 0;
/*      */ 
/*      */             
/*      */             while (true) {
/*      */               int k;
/*      */               
/*      */               char c;
/*      */               
/*      */               boolean bool1;
/*      */               
/*  800 */               if (this.im_PollingReadMode) {
/*  801 */                 k = 0;
/*  802 */                 c = Character.MIN_VALUE;
/*  803 */                 bool1 = false;
/*      */               } else {
/*  805 */                 if (this.im_ReceiveThresholdEnabled) {
/*  806 */                   k = this.im_ReceiveThresholdValue;
/*      */                 } else {
/*  808 */                   k = 1;
/*  809 */                 }  if (k > i)
/*  810 */                   k = i; 
/*  811 */                 if (k <= 255) {
/*  812 */                   c = k;
/*      */                 } else {
/*  814 */                   c = 'ÿ';
/*      */                 } 
/*      */                 
/*  817 */                 if (this.im_ReceiveTimeoutEnabled) {
/*  818 */                   bool1 = this.im_ReceiveTimeoutVTIME;
/*      */                 } else {
/*  820 */                   bool1 = false;
/*      */                 } 
/*  822 */               }  if (c != this.im_VMIN || bool1 != this.im_VTIME) {
/*      */                 
/*  824 */                 this.im_VMIN = c;
/*  825 */                 this.im_VTIME = bool1;
/*      */                 
/*  827 */                 synchronized (PureJavaSerialPort.this.m_Termios) {
/*  828 */                   PureJavaSerialPort.this.m_Termios.c_cc[JTermios.VTIME] = (byte)this.im_VTIME;
/*  829 */                   PureJavaSerialPort.this.m_Termios.c_cc[JTermios.VMIN] = (byte)this.im_VMIN;
/*  830 */                   PureJavaSerialPort.this.checkReturnCode(JTermios.tcsetattr(PureJavaSerialPort.this.m_FD, JTermios.TCSANOW, PureJavaSerialPort.this.m_Termios));
/*      */                 } 
/*      */               } 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  837 */               boolean bool = false;
/*  838 */               boolean bool2 = false;
/*  839 */               if (!this.im_PollingReadMode) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  845 */                 int n, i1 = this.im_ReceiveTimeoutEnabled ? this.im_ReceiveTimeoutValue : Integer.MAX_VALUE;
/*  846 */                 if (PureJavaSerialPort.this.USE_POLL) {
/*      */                   
/*  848 */                   n = JTermios.poll(this.im_ReadPollFD, this.im_PollFDn, i1);
/*  849 */                   if (n < 0 || PureJavaSerialPort.this.m_FD < 0) {
/*  850 */                     throw new IOException();
/*      */                   }
/*  852 */                   if ((this.im_ReadPollFD[3] & JTermios.POLLIN_OUT) != 0)
/*  853 */                     JTermios.read(PureJavaSerialPort.this.m_PipeRdFD, this.im_Nudge, 1); 
/*  854 */                   int i2 = this.im_ReadPollFD[1];
/*  855 */                   if ((i2 & JTermios.POLLNVAL_OUT) != 0)
/*  856 */                     throw new IOException(); 
/*  857 */                   bool = ((i2 & JTermios.POLLIN_OUT) != 0);
/*      */                 }
/*      */                 else {
/*      */                   
/*  861 */                   JTermios.FD_ZERO(this.im_ReadFDSet);
/*  862 */                   JTermios.FD_SET(PureJavaSerialPort.this.m_FD, this.im_ReadFDSet);
/*  863 */                   int i2 = PureJavaSerialPort.this.m_FD;
/*  864 */                   if (PureJavaSerialPort.this.m_HaveNudgePipe) {
/*  865 */                     JTermios.FD_SET(PureJavaSerialPort.this.m_PipeRdFD, this.im_ReadFDSet);
/*  866 */                     if (PureJavaSerialPort.this.m_PipeRdFD > i2)
/*  867 */                       i2 = PureJavaSerialPort.this.m_PipeRdFD; 
/*      */                   } 
/*  869 */                   if (i1 >= 1000) {
/*  870 */                     int i3 = i1 / 1000;
/*  871 */                     this.im_ReadTimeVal.tv_sec = i3;
/*  872 */                     this.im_ReadTimeVal.tv_usec = ((i1 - i3 * 1000) * 1000);
/*      */                   } else {
/*  874 */                     this.im_ReadTimeVal.tv_sec = 0L;
/*  875 */                     this.im_ReadTimeVal.tv_usec = (i1 * 1000);
/*      */                   } 
/*  877 */                   n = JTermios.select(i2 + 1, this.im_ReadFDSet, null, null, this.im_ReadTimeVal);
/*  878 */                   if (n < 0)
/*  879 */                     throw new IOException(); 
/*  880 */                   if (PureJavaSerialPort.this.m_FD < 0)
/*      */                   {
/*  882 */                     throw new IOException(); } 
/*  883 */                   bool = JTermios.FD_ISSET(PureJavaSerialPort.this.m_FD, this.im_ReadFDSet);
/*      */                 } 
/*  885 */                 if (n == 0 && PureJavaSerialPort.this.m_ReceiveTimeoutEnabled) {
/*  886 */                   bool2 = true;
/*      */                 }
/*      */               } 
/*  889 */               if (bool2) {
/*      */                 break;
/*      */               }
/*      */ 
/*      */               
/*  894 */               int m = 0;
/*  895 */               if (bool || this.im_PollingReadMode) {
/*  896 */                 if (param1Int1 > 0) {
/*  897 */                   if (i < this.im_Buffer.length) {
/*  898 */                     m = JTermios.read(PureJavaSerialPort.this.m_FD, this.im_Buffer, i);
/*      */                   } else {
/*  900 */                     m = JTermios.read(PureJavaSerialPort.this.m_FD, this.im_Buffer, this.im_Buffer.length);
/*  901 */                   }  if (m > 0) {
/*  902 */                     System.arraycopy(this.im_Buffer, 0, param1ArrayOfbyte, param1Int1, m);
/*      */                   }
/*      */                 } else {
/*  905 */                   m = JTermios.read(PureJavaSerialPort.this.m_FD, param1ArrayOfbyte, i);
/*      */                 } 
/*  907 */                 if (m == 0) {
/*  908 */                   bool2 = true;
/*      */                 }
/*      */               } 
/*      */ 
/*      */ 
/*      */               
/*  914 */               if (m < 0) {
/*  915 */                 throw new IOException();
/*      */               }
/*  917 */               j += m;
/*      */               
/*  919 */               if (j >= k) {
/*      */                 break;
/*      */               }
/*  922 */               if (bool2) {
/*      */                 break;
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*  928 */               param1Int1 += m;
/*  929 */               i -= m;
/*      */             } 
/*      */             
/*  932 */             PureJavaSerialPort.this.m_DataAvailableNotified = false;
/*  933 */             return j;
/*      */           }
/*      */         };
/*      */     }
/*      */     
/*  938 */     return this.m_InputStream;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized int getReceiveFramingByte() {
/*  943 */     checkState();
/*      */     
/*  945 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized int getReceiveThreshold() {
/*  950 */     checkState();
/*  951 */     return this.m_ReceiveThresholdValue;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized int getReceiveTimeout() {
/*  956 */     checkState();
/*  957 */     return this.m_ReceiveTimeoutValue;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized boolean isReceiveFramingEnabled() {
/*  962 */     checkState();
/*      */     
/*  964 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized boolean isReceiveThresholdEnabled() {
/*  969 */     checkState();
/*  970 */     return this.m_ReceiveThresholdEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized boolean isReceiveTimeoutEnabled() {
/*  975 */     checkState();
/*  976 */     return this.m_ReceiveTimeoutEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void setInputBufferSize(int paramInt) {
/*  981 */     checkState();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setOutputBufferSize(int paramInt) {
/*  987 */     checkState();
/*      */   }
/*      */ 
/*      */   
/*      */   private void nudgePipe() {
/*  992 */     if (this.m_HaveNudgePipe) {
/*  993 */       JTermios.write(this.m_PipeWrFD, this.m_NudgeData, 1);
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized void close() {
/*  998 */     int i = this.m_FD;
/*  999 */     if (i != -1) {
/* 1000 */       this.m_FD = -1;
/*      */       try {
/* 1002 */         if (this.m_InputStream != null)
/* 1003 */           this.m_InputStream.close(); 
/* 1004 */       } catch (IOException iOException) {
/* 1005 */         JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "m_InputStream.close threw an IOException %s\n", new Object[] { iOException.getMessage() }));
/*      */       } finally {
/* 1007 */         this.m_InputStream = null;
/*      */       } 
/*      */       try {
/* 1010 */         if (this.m_OutputStream != null)
/* 1011 */           this.m_OutputStream.close(); 
/* 1012 */       } catch (IOException iOException) {
/* 1013 */         JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "m_OutputStream.close threw an IOException %s\n", new Object[] { iOException.getMessage() }));
/*      */       } finally {
/* 1015 */         this.m_OutputStream = null;
/*      */       } 
/* 1017 */       nudgePipe();
/* 1018 */       int j = JTermios.fcntl(i, JTermios.F_GETFL, 0);
/* 1019 */       j |= JTermios.O_NONBLOCK;
/* 1020 */       int k = JTermios.fcntl(i, JTermios.F_SETFL, j);
/* 1021 */       if (k != 0) {
/* 1022 */         JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "fcntl(%d,%d,%d) returned %d\n", new Object[] { Integer.valueOf(i), Integer.valueOf(JTermios.F_SETFL), Integer.valueOf(j), Integer.valueOf(k) }));
/*      */       }
/* 1024 */       if (this.m_Thread != null)
/* 1025 */         this.m_Thread.interrupt(); 
/* 1026 */       int m = JTermios.close(i);
/* 1027 */       if (m < 0) {
/* 1028 */         JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "JTermios.close returned %d, errno %d\n", new Object[] { Integer.valueOf(m), Integer.valueOf(JTermios.errno()) }));
/*      */       }
/* 1030 */       if (this.m_HaveNudgePipe) {
/* 1031 */         m = JTermios.close(this.m_PipeRdFD);
/* 1032 */         if (m < 0)
/* 1033 */           JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "JTermios.close returned %d, errno %d\n", new Object[] { Integer.valueOf(m), Integer.valueOf(JTermios.errno()) })); 
/* 1034 */         m = JTermios.close(this.m_PipeWrFD);
/* 1035 */         if (m < 0)
/* 1036 */           JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "JTermios.close returned %d, errno %d\n", new Object[] { Integer.valueOf(m), Integer.valueOf(JTermios.errno()) })); 
/*      */       } 
/* 1038 */       long l = System.currentTimeMillis();
/* 1039 */       while (this.m_ThreadRunning) {
/*      */         try {
/* 1041 */           Thread.sleep(5L);
/* 1042 */           if (System.currentTimeMillis() - l > 2000L)
/*      */             break; 
/* 1044 */         } catch (InterruptedException interruptedException) {
/*      */           break;
/*      */         } 
/*      */       } 
/* 1048 */       super.close();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   PureJavaSerialPort(String paramString, int paramInt) throws PortInUseException {
/* 1055 */     boolean bool = false;
/* 1056 */     if (Platform.isLinux()) {
/* 1057 */       String str1 = "purejavacomm.use_poll";
/* 1058 */       String str2 = "purejavacomm.usepoll";
/* 1059 */       if (System.getProperty(str1) != null) {
/* 1060 */         bool = Boolean.getBoolean(str1);
/* 1061 */         JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "use of '%s' is deprecated, use '%s' instead\n", new Object[] { str1, str2 }));
/* 1062 */       } else if (System.getProperty(str2) != null) {
/* 1063 */         bool = Boolean.getBoolean(str2);
/*      */       } else {
/* 1065 */         bool = true;
/*      */       } 
/* 1067 */     }  this.USE_POLL = bool;
/*      */     
/* 1069 */     this.RAW_READ_MODE = Boolean.getBoolean("purejavacomm.rawreadmode");
/*      */     
/* 1071 */     this.name = paramString;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1076 */     byte b = 100;
/* 1077 */     long l = System.currentTimeMillis();
/* 1078 */     while ((this.m_FD = JTermios.open(paramString, JTermios.O_RDWR | JTermios.O_NOCTTY | JTermios.O_NONBLOCK)) < 0) {
/*      */       try {
/* 1080 */         Thread.sleep(10L);
/* 1081 */       } catch (InterruptedException interruptedException) {}
/*      */       
/* 1083 */       if (b-- < 0 || System.currentTimeMillis() - l >= paramInt) {
/* 1084 */         throw new PortInUseException();
/*      */       }
/*      */     } 
/* 1087 */     this.m_MinVTIME = Integer.getInteger("purejavacomm.minvtime", 100).intValue();
/* 1088 */     int i = JTermios.fcntl(this.m_FD, JTermios.F_GETFL, 0);
/* 1089 */     i &= JTermios.O_NONBLOCK ^ 0xFFFFFFFF;
/* 1090 */     checkReturnCode(JTermios.fcntl(this.m_FD, JTermios.F_SETFL, i));
/*      */     
/* 1092 */     this.m_BaudRate = 9600;
/* 1093 */     this.m_DataBits = 8;
/* 1094 */     this.m_FlowControlMode = 0;
/* 1095 */     this.m_Parity = 0;
/* 1096 */     this.m_StopBits = 1;
/*      */     
/* 1098 */     checkReturnCode(JTermios.tcgetattr(this.m_FD, this.m_Termios));
/*      */     
/* 1100 */     JTermios.cfmakeraw(this.m_FD, this.m_Termios);
/*      */     
/* 1102 */     this.m_Termios.c_cflag |= JTermios.CLOCAL | JTermios.CREAD;
/* 1103 */     this.m_Termios.c_lflag &= (JTermios.ICANON | JTermios.ECHO | JTermios.ECHOE | JTermios.ISIG) ^ 0xFFFFFFFF;
/* 1104 */     this.m_Termios.c_oflag &= JTermios.OPOST ^ 0xFFFFFFFF;
/*      */     
/* 1106 */     this.m_Termios.c_cc[JTermios.VSTART] = (byte)JTermios.DC1;
/* 1107 */     this.m_Termios.c_cc[JTermios.VSTOP] = (byte)JTermios.DC3;
/* 1108 */     this.m_Termios.c_cc[JTermios.VMIN] = 0;
/* 1109 */     this.m_Termios.c_cc[JTermios.VTIME] = 0;
/* 1110 */     checkReturnCode(JTermios.tcsetattr(this.m_FD, JTermios.TCSANOW, this.m_Termios));
/*      */     
/*      */     try {
/* 1113 */       setSerialPortParams(this.m_BaudRate, this.m_DataBits, this.m_StopBits, this.m_Parity);
/* 1114 */     } catch (UnsupportedCommOperationException unsupportedCommOperationException) {
/*      */       
/* 1116 */       unsupportedCommOperationException.printStackTrace();
/*      */     } 
/*      */     
/*      */     try {
/* 1120 */       setFlowControlMode(0);
/* 1121 */     } catch (UnsupportedCommOperationException unsupportedCommOperationException) {
/*      */       
/* 1123 */       unsupportedCommOperationException.printStackTrace();
/*      */     } 
/*      */     
/* 1126 */     checkReturnCode(JTermios.ioctl(this.m_FD, JTermios.TIOCMGET, this.m_ioctl));
/* 1127 */     this.m_ControlLineStates = this.m_ioctl[0];
/*      */     
/* 1129 */     String str = "purejavacomm.usenudgepipe";
/* 1130 */     if (System.getProperty(str) == null || Boolean.getBoolean(str)) {
/* 1131 */       int[] arrayOfInt = new int[2];
/* 1132 */       if (JTermios.pipe(arrayOfInt) == 0) {
/* 1133 */         this.m_HaveNudgePipe = true;
/* 1134 */         this.m_PipeRdFD = arrayOfInt[0];
/* 1135 */         this.m_PipeWrFD = arrayOfInt[1];
/* 1136 */         checkReturnCode(JTermios.fcntl(this.m_PipeRdFD, JTermios.F_SETFL, JTermios.fcntl(this.m_PipeRdFD, JTermios.F_GETFL, 0) | JTermios.O_NONBLOCK));
/*      */       } 
/*      */     } 
/*      */     
/* 1140 */     Runnable runnable = new Runnable() {
/*      */         public void run() {
/*      */           
/* 1143 */           try { PureJavaSerialPort.this.m_ThreadRunning = true;
/*      */             
/* 1145 */             int i = Integer.getInteger("purejavacomm.pollperiod", 10).intValue();
/*      */             
/* 1147 */             TimeVal timeVal = null;
/* 1148 */             FDSet fDSet1 = null;
/* 1149 */             FDSet fDSet2 = null;
/* 1150 */             int[] arrayOfInt = null;
/* 1151 */             byte[] arrayOfByte = null;
/*      */             
/* 1153 */             if (PureJavaSerialPort.this.USE_POLL) {
/* 1154 */               arrayOfInt = new int[4];
/* 1155 */               arrayOfByte = new byte[1];
/* 1156 */               arrayOfInt[0] = PureJavaSerialPort.this.m_FD;
/* 1157 */               arrayOfInt[2] = PureJavaSerialPort.this.m_PipeRdFD;
/*      */             } else {
/* 1159 */               fDSet1 = JTermios.newFDSet();
/* 1160 */               fDSet2 = JTermios.newFDSet();
/* 1161 */               timeVal = new TimeVal();
/* 1162 */               int j = i * 1000;
/* 1163 */               timeVal.tv_sec = (j / 1000000);
/* 1164 */               timeVal.tv_usec = j - timeVal.tv_sec * 1000000L;
/*      */             } 
/*      */             
/* 1167 */             while (PureJavaSerialPort.this.m_FD >= 0) {
/* 1168 */               boolean bool1 = (PureJavaSerialPort.this.m_NotifyOnDataAvailable && !PureJavaSerialPort.this.m_DataAvailableNotified) ? true : false;
/* 1169 */               boolean bool2 = (PureJavaSerialPort.this.m_NotifyOnOutputEmpty && !PureJavaSerialPort.this.m_OutputEmptyNotified) ? true : false;
/* 1170 */               int j = 0;
/*      */               
/* 1172 */               boolean bool3 = (PureJavaSerialPort.this.m_NotifyOnCTS || PureJavaSerialPort.this.m_NotifyOnDSR || PureJavaSerialPort.this.m_NotifyOnRI || PureJavaSerialPort.this.m_NotifyOnCD) ? true : false;
/*      */               
/* 1174 */               if (bool1 || bool2 || (!bool3 && PureJavaSerialPort.this.m_HaveNudgePipe)) {
/* 1175 */                 if (PureJavaSerialPort.this.USE_POLL) {
/* 1176 */                   int k = 0;
/* 1177 */                   if (bool1)
/* 1178 */                     k |= JTermios.POLLIN_IN; 
/* 1179 */                   if (bool2)
/* 1180 */                     k |= JTermios.POLLOUT_IN; 
/* 1181 */                   arrayOfInt[1] = k;
/* 1182 */                   arrayOfInt[3] = JTermios.POLLIN_IN;
/* 1183 */                   if (PureJavaSerialPort.this.m_HaveNudgePipe) {
/* 1184 */                     j = JTermios.poll(arrayOfInt, 2, -1);
/*      */                   } else {
/* 1186 */                     j = JTermios.poll(arrayOfInt, 1, i);
/*      */                   } 
/* 1188 */                   int m = arrayOfInt[3];
/*      */                   
/* 1190 */                   if ((m & JTermios.POLLNVAL_OUT) != 0) {
/* 1191 */                     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "poll() returned POLLNVAL, errno %d\n", new Object[] { Integer.valueOf(JTermios.errno()) }));
/*      */                     
/*      */                     break;
/*      */                   } 
/* 1195 */                   if ((m & JTermios.POLLIN_OUT) != 0) {
/* 1196 */                     JTermios.read(PureJavaSerialPort.this.m_PipeRdFD, arrayOfByte, 1);
/*      */                   }
/* 1198 */                   m = arrayOfInt[1];
/* 1199 */                   if ((m & JTermios.POLLNVAL_OUT) != 0) {
/* 1200 */                     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "poll() returned POLLNVAL, errno %d\n", new Object[] { Integer.valueOf(JTermios.errno()) }));
/*      */                     break;
/*      */                   } 
/* 1203 */                   bool1 = (bool1 && (m & JTermios.POLLIN_OUT) != 0) ? true : false;
/* 1204 */                   bool2 = (bool2 && (m & JTermios.POLLOUT_OUT) != 0) ? true : false;
/*      */                 } else {
/* 1206 */                   JTermios.FD_ZERO(fDSet1);
/* 1207 */                   JTermios.FD_ZERO(fDSet2);
/* 1208 */                   if (bool1)
/* 1209 */                     JTermios.FD_SET(PureJavaSerialPort.this.m_FD, fDSet1); 
/* 1210 */                   if (bool2)
/* 1211 */                     JTermios.FD_SET(PureJavaSerialPort.this.m_FD, fDSet2); 
/* 1212 */                   if (PureJavaSerialPort.this.m_HaveNudgePipe)
/* 1213 */                     JTermios.FD_SET(PureJavaSerialPort.this.m_PipeRdFD, fDSet1); 
/* 1214 */                   j = JTermios.select(PureJavaSerialPort.this.m_FD + 1, fDSet1, fDSet2, null, PureJavaSerialPort.this.m_HaveNudgePipe ? null : timeVal);
/* 1215 */                   bool1 = (bool1 && JTermios.FD_ISSET(PureJavaSerialPort.this.m_FD, fDSet1)) ? true : false;
/* 1216 */                   bool2 = (bool2 && JTermios.FD_ISSET(PureJavaSerialPort.this.m_FD, fDSet2)) ? true : false;
/*      */                 } 
/*      */                 
/* 1219 */                 if (PureJavaSerialPort.this.m_FD < 0)
/*      */                   break; 
/* 1221 */                 if (j < 0) {
/* 1222 */                   JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "select() or poll() returned %d, errno %d\n", new Object[] { Integer.valueOf(j), Integer.valueOf(JTermios.errno()) }));
/* 1223 */                   PureJavaSerialPort.this.close();
/*      */                   break;
/*      */                 } 
/*      */               } else {
/* 1227 */                 Thread.sleep(i);
/*      */               } 
/*      */               
/* 1230 */               if (PureJavaSerialPort.this.m_EventListener != null) {
/* 1231 */                 if (bool1 || bool2)
/* 1232 */                   PureJavaSerialPort.this.sendDataEvents(bool1, bool2); 
/* 1233 */                 if (bool3)
/* 1234 */                   PureJavaSerialPort.this.sendNonDataEvents(); 
/*      */               } 
/*      */             }  }
/* 1237 */           catch (InterruptedException interruptedException) {  }
/*      */           finally
/* 1239 */           { PureJavaSerialPort.this.m_ThreadRunning = false; }
/*      */         
/*      */         }
/*      */       };
/* 1243 */     this.m_Thread = new Thread(runnable, getName());
/* 1244 */     this.m_Thread.setDaemon(true);
/*      */   }
/*      */   
/*      */   private synchronized void updateControlLineState(int paramInt) {
/* 1248 */     checkState();
/*      */     
/* 1250 */     if (JTermios.ioctl(this.m_FD, JTermios.TIOCMGET, this.m_ioctl) == -1) {
/* 1251 */       throw new PureJavaIllegalStateException("ioctl(m_FD, TIOCMGET, m_ioctl) == -1");
/*      */     }
/* 1253 */     this.m_ControlLineStates = (this.m_ioctl[0] & paramInt) + (this.m_ControlLineStates & (paramInt ^ 0xFFFFFFFF));
/*      */   }
/*      */   
/*      */   private synchronized boolean getControlLineState(int paramInt) {
/* 1257 */     checkState();
/* 1258 */     if (JTermios.ioctl(this.m_FD, JTermios.TIOCMGET, this.m_ioctl) == -1)
/* 1259 */       throw new PureJavaIllegalStateException("ioctl(m_FD, TIOCMGET, m_ioctl) == -1"); 
/* 1260 */     return ((this.m_ioctl[0] & paramInt) != 0);
/*      */   }
/*      */   
/*      */   private synchronized void setControlLineState(int paramInt, boolean paramBoolean) {
/* 1264 */     checkState();
/* 1265 */     if (JTermios.ioctl(this.m_FD, JTermios.TIOCMGET, this.m_ioctl) == -1) {
/* 1266 */       throw new PureJavaIllegalStateException("ioctl(m_FD, TIOCMGET, m_ioctl) == -1");
/*      */     }
/* 1268 */     if (paramBoolean) {
/* 1269 */       this.m_ioctl[0] = this.m_ioctl[0] | paramInt;
/*      */     } else {
/* 1271 */       this.m_ioctl[0] = this.m_ioctl[0] & (paramInt ^ 0xFFFFFFFF);
/* 1272 */     }  if (JTermios.ioctl(this.m_FD, JTermios.TIOCMSET, this.m_ioctl) == -1)
/* 1273 */       throw new PureJavaIllegalStateException("ioctl(m_FD, TIOCMSET, m_ioctl) == -1"); 
/*      */   }
/*      */   
/*      */   private void failWithIllegalStateException() {
/* 1277 */     throw new PureJavaIllegalStateException("File descriptor is " + this.m_FD + " < 0, maybe closed by previous error condition");
/*      */   }
/*      */   
/*      */   private void checkState() {
/* 1281 */     if (this.m_FD < 0)
/* 1282 */       failWithIllegalStateException(); 
/*      */   }
/*      */   
/*      */   private void checkReturnCode(int paramInt) {
/* 1286 */     if (paramInt != 0) {
/* 1287 */       String str = String.format("JTermios call returned %d at %s", new Object[] { Integer.valueOf(paramInt), JTermios.JTermiosLogging.lineno(1) });
/* 1288 */       JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "%s\n", new Object[] { str }));
/*      */       try {
/* 1290 */         close();
/* 1291 */       } catch (Exception exception) {
/* 1292 */         StackTraceElement stackTraceElement = exception.getStackTrace()[0];
/* 1293 */         String str1 = String.format("close threw %s at class %s line% d", new Object[] { exception.getClass().getName(), stackTraceElement.getClassName(), Integer.valueOf(stackTraceElement.getLineNumber()) });
/* 1294 */         JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "%s\n", new Object[] { str1 }));
/*      */       } 
/* 1296 */       throw new PureJavaIllegalStateException(str);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\purejavacomm\PureJavaSerialPort.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */