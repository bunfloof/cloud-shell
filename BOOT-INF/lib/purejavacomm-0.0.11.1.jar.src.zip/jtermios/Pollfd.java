package jtermios;

public class Pollfd {
  public int fd;
  
  public short events;
  
  public short revents;
}


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\jtermios\Pollfd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */