/*     */ package jtermios.linux;
/*     */ 
/*     */ import com.sun.jna.Library;
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.NativeLibrary;
/*     */ import com.sun.jna.NativeLong;
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.Structure;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import jtermios.FDSet;
/*     */ import jtermios.JTermios;
/*     */ import jtermios.Pollfd;
/*     */ import jtermios.Termios;
/*     */ import jtermios.TimeVal;
/*     */ import jtermios.YJPFunctionMapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JTermiosImpl
/*     */   implements JTermios.JTermiosInterface
/*     */ {
/*  60 */   private static String DEVICE_DIR_PATH = "/dev/";
/*  61 */   private static final boolean IS64B = (NativeLong.SIZE == 8);
/*  62 */   static Linux_C_lib_DirectMapping m_ClibDM = new Linux_C_lib_DirectMapping();
/*  63 */   static Linux_C_lib m_Clib = m_ClibDM;
/*     */   
/*     */   private static final int TIOCGSERIAL = 21534;
/*     */   
/*     */   private static final int TIOCSSERIAL = 21535;
/*     */   
/*     */   private static final int ASYNC_SPD_MASK = 4144;
/*     */   private static final int ASYNC_SPD_CUST = 48;
/*  71 */   private static final int[] m_BaudRates = new int[] { 50, 1, 75, 2, 110, 3, 134, 4, 150, 5, 200, 6, 300, 7, 600, 8, 1200, 9, 1800, 10, 2400, 11, 4800, 12, 9600, 13, 19200, 14, 38400, 15, 57600, 4097, 115200, 4098, 230400, 4099, 460800, 4100, 500000, 4101, 576000, 4102, 921600, 4103, 1000000, 4104, 1152000, 4105, 1500000, 4106, 2000000, 4107, 2500000, 4108, 3000000, 4109, 3500000, 4110, 4000000, 4111 };
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Linux_C_lib_DirectMapping
/*     */     implements Linux_C_lib
/*     */   {
/*     */     public native long memcpy(int[] param1ArrayOfint, short[] param1ArrayOfshort, long param1Long);
/*     */ 
/*     */ 
/*     */     
/*     */     public native int memcpy(int[] param1ArrayOfint, short[] param1ArrayOfshort, int param1Int);
/*     */ 
/*     */ 
/*     */     
/*     */     public native int pipe(int[] param1ArrayOfint);
/*     */ 
/*     */ 
/*     */     
/*     */     public native int tcdrain(int param1Int);
/*     */ 
/*     */ 
/*     */     
/*     */     public native void cfmakeraw(JTermiosImpl.Linux_C_lib.termios param1termios);
/*     */ 
/*     */ 
/*     */     
/*     */     public native int fcntl(int param1Int1, int param1Int2, int param1Int3);
/*     */ 
/*     */     
/*     */     public native int ioctl(int param1Int1, int param1Int2, int[] param1ArrayOfint);
/*     */ 
/*     */     
/*     */     public native int ioctl(int param1Int1, int param1Int2, JTermiosImpl.Linux_C_lib.serial_struct param1serial_struct);
/*     */ 
/*     */     
/*     */     public native int open(String param1String, int param1Int);
/*     */ 
/*     */     
/*     */     public native int close(int param1Int);
/*     */ 
/*     */     
/*     */     public native int tcgetattr(int param1Int, JTermiosImpl.Linux_C_lib.termios param1termios);
/*     */ 
/*     */     
/*     */     public native int tcsetattr(int param1Int1, int param1Int2, JTermiosImpl.Linux_C_lib.termios param1termios);
/*     */ 
/*     */     
/*     */     public native int cfsetispeed(JTermiosImpl.Linux_C_lib.termios param1termios, NativeLong param1NativeLong);
/*     */ 
/*     */     
/*     */     public native int cfsetospeed(JTermiosImpl.Linux_C_lib.termios param1termios, NativeLong param1NativeLong);
/*     */ 
/*     */     
/*     */     public native NativeLong cfgetispeed(JTermiosImpl.Linux_C_lib.termios param1termios);
/*     */ 
/*     */     
/*     */     public native NativeLong cfgetospeed(JTermiosImpl.Linux_C_lib.termios param1termios);
/*     */ 
/*     */     
/*     */     public native int write(int param1Int1, byte[] param1ArrayOfbyte, int param1Int2);
/*     */ 
/*     */     
/*     */     public native int read(int param1Int1, byte[] param1ArrayOfbyte, int param1Int2);
/*     */ 
/*     */     
/*     */     public native long write(int param1Int, byte[] param1ArrayOfbyte, long param1Long);
/*     */ 
/*     */     
/*     */     public native long read(int param1Int, byte[] param1ArrayOfbyte, long param1Long);
/*     */ 
/*     */     
/*     */     public native int select(int param1Int, int[] param1ArrayOfint1, int[] param1ArrayOfint2, int[] param1ArrayOfint3, JTermiosImpl.Linux_C_lib.timeval param1timeval);
/*     */ 
/*     */     
/*     */     public native int poll(int[] param1ArrayOfint, int param1Int1, int param1Int2);
/*     */ 
/*     */     
/*     */     public int poll(JTermiosImpl.Linux_C_lib.pollfd[] param1ArrayOfpollfd, int param1Int1, int param1Int2) {
/* 150 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/*     */     public native int tcflush(int param1Int1, int param1Int2);
/*     */     
/*     */     public native void perror(String param1String);
/*     */     
/*     */     public native int tcsendbreak(int param1Int1, int param1Int2);
/*     */     
/*     */     static {
/*     */       try {
/* 161 */         Native.register(NativeLibrary.getInstance("c", YJPFunctionMapper.OPTIONS));
/* 162 */       } catch (Exception exception) {
/* 163 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class timeval
/*     */     extends Structure
/*     */   {
/*     */     public NativeLong tv_sec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public NativeLong tv_usec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected List getFieldOrder() {
/* 227 */       return Arrays.asList(new String[] { "tv_sec", "tv_usec" });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public timeval(TimeVal param1TimeVal) {
/* 234 */       this.tv_sec = new NativeLong(param1TimeVal.tv_sec);
/* 235 */       this.tv_usec = new NativeLong(param1TimeVal.tv_usec);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class pollfd
/*     */     extends Structure {
/*     */     public int fd;
/*     */     public short events;
/*     */     public short revents;
/*     */     
/*     */     protected List getFieldOrder() {
/* 246 */       return Arrays.asList(new String[] { "fd", "events", "revents" });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public pollfd(Pollfd param1Pollfd) {
/* 254 */       this.fd = param1Pollfd.fd;
/* 255 */       this.events = param1Pollfd.events;
/* 256 */       this.revents = param1Pollfd.revents;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class serial_struct
/*     */     extends Structure
/*     */   {
/*     */     public int type;
/*     */     public int line;
/*     */     public int port;
/*     */     public int irq;
/*     */     public int flags;
/*     */     public int xmit_fifo_size;
/*     */     public int custom_divisor;
/*     */     public int baud_base;
/*     */     public short close_delay;
/*     */     public short io_type;
/*     */     public int hub6;
/*     */     public short closing_wait;
/*     */     public short closing_wait2;
/*     */     public Pointer iomem_base;
/*     */     public short iomem_reg_shift;
/*     */     public int port_high;
/*     */     public NativeLong iomap_base;
/*     */     
/*     */     protected List getFieldOrder()
/*     */     {
/* 283 */       return Arrays.asList(new String[] { "type", "line", "port", "irq", "flags", "xmit_fifo_size", "custom_divisor", "baud_base", "close_delay", "io_type", "hub6", "closing_wait", "closing_wait2", "iomem_base", "iomem_reg_shift", "port_high", "iomap_base" }); } } public static interface Linux_C_lib extends Library { long memcpy(int[] param1ArrayOfint, short[] param1ArrayOfshort, long param1Long); int memcpy(int[] param1ArrayOfint, short[] param1ArrayOfshort, int param1Int); int pipe(int[] param1ArrayOfint); int tcdrain(int param1Int); void cfmakeraw(termios param1termios); int fcntl(int param1Int1, int param1Int2, int param1Int3); int ioctl(int param1Int1, int param1Int2, int[] param1ArrayOfint); int ioctl(int param1Int1, int param1Int2, serial_struct param1serial_struct); int open(String param1String, int param1Int); int close(int param1Int); int tcgetattr(int param1Int, termios param1termios); int tcsetattr(int param1Int1, int param1Int2, termios param1termios); int cfsetispeed(termios param1termios, NativeLong param1NativeLong); int cfsetospeed(termios param1termios, NativeLong param1NativeLong); NativeLong cfgetispeed(termios param1termios); NativeLong cfgetospeed(termios param1termios); int write(int param1Int1, byte[] param1ArrayOfbyte, int param1Int2); int read(int param1Int1, byte[] param1ArrayOfbyte, int param1Int2); long write(int param1Int, byte[] param1ArrayOfbyte, long param1Long); long read(int param1Int, byte[] param1ArrayOfbyte, long param1Long); int select(int param1Int, int[] param1ArrayOfint1, int[] param1ArrayOfint2, int[] param1ArrayOfint3, timeval param1timeval); int poll(pollfd[] param1ArrayOfpollfd, int param1Int1, int param1Int2); int poll(int[] param1ArrayOfint, int param1Int1, int param1Int2); int tcflush(int param1Int1, int param1Int2); void perror(String param1String); int tcsendbreak(int param1Int1, int param1Int2); public static class timeval extends Structure { public NativeLong tv_sec; public NativeLong tv_usec; protected List getFieldOrder() { return Arrays.asList(new String[] { "tv_sec", "tv_usec" }); } public timeval(TimeVal param2TimeVal) { this.tv_sec = new NativeLong(param2TimeVal.tv_sec); this.tv_usec = new NativeLong(param2TimeVal.tv_usec); } } public static class pollfd extends Structure { public int fd; public short events; public short revents; protected List getFieldOrder() { return Arrays.asList(new String[] { "fd", "events", "revents" }); } public pollfd(Pollfd param2Pollfd) { this.fd = param2Pollfd.fd; this.events = param2Pollfd.events; this.revents = param2Pollfd.revents; } } public static class serial_struct extends Structure { protected List getFieldOrder() { return Arrays.asList(new String[] { "type", "line", "port", "irq", "flags", "xmit_fifo_size", "custom_divisor", "baud_base", "close_delay", "io_type", "hub6", "closing_wait", "closing_wait2", "iomem_base", "iomem_reg_shift", "port_high", "iomap_base" }); }
/*     */ 
/*     */       
/*     */       public int type;
/*     */       public int line;
/*     */       public int port;
/*     */       public int irq;
/*     */       public int flags;
/*     */       public int xmit_fifo_size;
/*     */       public int custom_divisor;
/*     */       public int baud_base;
/*     */       public short close_delay;
/*     */       public short io_type;
/*     */       public int hub6;
/*     */       public short closing_wait;
/*     */       public short closing_wait2;
/*     */       public Pointer iomem_base;
/*     */       public short iomem_reg_shift;
/*     */       public int port_high;
/*     */       public NativeLong iomap_base; }
/*     */ 
/*     */     
/*     */     public static class termios
/*     */       extends Structure
/*     */     {
/*     */       public int c_iflag;
/*     */       public int c_oflag;
/*     */       public int c_cflag;
/*     */       public int c_lflag;
/*     */       public byte c_line;
/* 313 */       public byte[] c_cc = new byte[32];
/*     */       
/*     */       public int c_ispeed;
/*     */       public int c_ospeed;
/*     */       
/*     */       protected List getFieldOrder() {
/* 319 */         return Arrays.asList(new String[] { "c_iflag", "c_oflag", "c_cflag", "c_lflag", "c_line", "c_cc", "c_ispeed", "c_ospeed" });
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public termios() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public termios(Termios param2Termios) {
/* 335 */         this.c_iflag = param2Termios.c_iflag;
/* 336 */         this.c_oflag = param2Termios.c_oflag;
/* 337 */         this.c_cflag = param2Termios.c_cflag;
/* 338 */         this.c_lflag = param2Termios.c_lflag;
/* 339 */         System.arraycopy(param2Termios.c_cc, 0, this.c_cc, 0, param2Termios.c_cc.length);
/* 340 */         this.c_ispeed = param2Termios.c_ispeed;
/* 341 */         this.c_ospeed = param2Termios.c_ospeed;
/*     */       }
/*     */       
/*     */       public void update(Termios param2Termios) {
/* 345 */         param2Termios.c_iflag = this.c_iflag;
/* 346 */         param2Termios.c_oflag = this.c_oflag;
/* 347 */         param2Termios.c_cflag = this.c_cflag;
/* 348 */         param2Termios.c_lflag = this.c_lflag;
/* 349 */         System.arraycopy(this.c_cc, 0, param2Termios.c_cc, 0, param2Termios.c_cc.length);
/* 350 */         param2Termios.c_ispeed = this.c_ispeed;
/* 351 */         param2Termios.c_ospeed = this.c_ospeed; } } } public static class termios extends Structure { public int c_iflag; public int c_oflag; public int c_cflag; public int c_lflag; public byte c_line; public byte[] c_cc = new byte[32]; public int c_ispeed; public int c_ospeed; protected List getFieldOrder() { return Arrays.asList(new String[] { "c_iflag", "c_oflag", "c_cflag", "c_lflag", "c_line", "c_cc", "c_ispeed", "c_ospeed" }); } public termios() {} public termios(Termios param1Termios) { this.c_iflag = param1Termios.c_iflag; this.c_oflag = param1Termios.c_oflag; this.c_cflag = param1Termios.c_cflag; this.c_lflag = param1Termios.c_lflag; System.arraycopy(param1Termios.c_cc, 0, this.c_cc, 0, param1Termios.c_cc.length); this.c_ispeed = param1Termios.c_ispeed; this.c_ospeed = param1Termios.c_ospeed; } public void update(Termios param1Termios) { param1Termios.c_iflag = this.c_iflag; param1Termios.c_oflag = this.c_oflag; param1Termios.c_cflag = this.c_cflag; param1Termios.c_lflag = this.c_lflag; System.arraycopy(this.c_cc, 0, param1Termios.c_cc, 0, param1Termios.c_cc.length); param1Termios.c_ispeed = this.c_ispeed; param1Termios.c_ospeed = this.c_ospeed; }
/*     */      }
/*     */ 
/*     */   
/*     */   private static class FDSetImpl
/*     */     extends FDSet
/*     */   {
/*     */     static final int FD_SET_SIZE = 1024;
/*     */     static final int NFBBITS = 32;
/* 360 */     int[] bits = new int[32];
/*     */     
/*     */     public String toString() {
/* 363 */       return String.format("%08X%08X", new Object[] { Integer.valueOf(this.bits[0]), Integer.valueOf(this.bits[1]) });
/*     */     }
/*     */     private FDSetImpl() {} }
/*     */   
/*     */   public JTermiosImpl() {
/* 368 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "instantiating %s\n", new Object[] { getClass().getCanonicalName() }));
/*     */ 
/*     */     
/* 371 */     JTermios.FIONREAD = 21531;
/*     */     
/* 373 */     JTermios.O_RDWR = 2;
/* 374 */     JTermios.O_NONBLOCK = 2048;
/* 375 */     JTermios.O_NOCTTY = 256;
/* 376 */     JTermios.O_NDELAY = 2048;
/* 377 */     JTermios.F_GETFL = 3;
/* 378 */     JTermios.F_SETFL = 4;
/*     */     
/* 380 */     JTermios.EAGAIN = 11;
/* 381 */     JTermios.EACCES = 13;
/* 382 */     JTermios.EEXIST = 17;
/* 383 */     JTermios.EINTR = 4;
/* 384 */     JTermios.EINVAL = 22;
/* 385 */     JTermios.EIO = 5;
/* 386 */     JTermios.EISDIR = 21;
/* 387 */     JTermios.ELOOP = 40;
/* 388 */     JTermios.EMFILE = 24;
/* 389 */     JTermios.ENAMETOOLONG = 36;
/* 390 */     JTermios.ENFILE = 23;
/* 391 */     JTermios.ENOENT = 2;
/* 392 */     JTermios.ENOSR = 63;
/* 393 */     JTermios.ENOSPC = 28;
/* 394 */     JTermios.ENOTDIR = 20;
/* 395 */     JTermios.ENXIO = 6;
/* 396 */     JTermios.EOVERFLOW = 75;
/* 397 */     JTermios.EROFS = 30;
/* 398 */     JTermios.ENOTSUP = 95;
/*     */     
/* 400 */     JTermios.TIOCM_RNG = 128;
/* 401 */     JTermios.TIOCM_CAR = 64;
/* 402 */     JTermios.IGNBRK = 1;
/* 403 */     JTermios.BRKINT = 2;
/* 404 */     JTermios.IGNPAR = 4;
/* 405 */     JTermios.PARMRK = 8;
/* 406 */     JTermios.INLCR = 64;
/* 407 */     JTermios.IGNCR = 128;
/* 408 */     JTermios.ICRNL = 256;
/* 409 */     JTermios.ECHONL = 64;
/* 410 */     JTermios.IEXTEN = 32768;
/* 411 */     JTermios.CLOCAL = 2048;
/* 412 */     JTermios.OPOST = 1;
/* 413 */     JTermios.VSTART = 8;
/* 414 */     JTermios.TCSANOW = 0;
/* 415 */     JTermios.VSTOP = 9;
/* 416 */     JTermios.VMIN = 6;
/* 417 */     JTermios.VTIME = 5;
/* 418 */     JTermios.VEOF = 4;
/* 419 */     JTermios.TIOCMGET = 21525;
/* 420 */     JTermios.TIOCM_CTS = 32;
/* 421 */     JTermios.TIOCM_DSR = 256;
/* 422 */     JTermios.TIOCM_RI = 128;
/* 423 */     JTermios.TIOCM_CD = 64;
/* 424 */     JTermios.TIOCM_DTR = 2;
/* 425 */     JTermios.TIOCM_RTS = 4;
/* 426 */     JTermios.ICANON = 2;
/* 427 */     JTermios.ECHO = 8;
/* 428 */     JTermios.ECHOE = 16;
/* 429 */     JTermios.ISIG = 1;
/* 430 */     JTermios.TIOCMSET = 21528;
/* 431 */     JTermios.IXON = 1024;
/* 432 */     JTermios.IXOFF = 4096;
/* 433 */     JTermios.IXANY = 2048;
/* 434 */     JTermios.CRTSCTS = Integer.MIN_VALUE;
/* 435 */     JTermios.TCSADRAIN = 1;
/* 436 */     JTermios.INPCK = 16;
/* 437 */     JTermios.ISTRIP = 32;
/* 438 */     JTermios.CSIZE = 48;
/* 439 */     JTermios.TCIFLUSH = 0;
/* 440 */     JTermios.TCOFLUSH = 1;
/* 441 */     JTermios.TCIOFLUSH = 2;
/* 442 */     JTermios.CS5 = 0;
/* 443 */     JTermios.CS6 = 16;
/* 444 */     JTermios.CS7 = 32;
/* 445 */     JTermios.CS8 = 48;
/* 446 */     JTermios.CSTOPB = 64;
/* 447 */     JTermios.CREAD = 128;
/* 448 */     JTermios.PARENB = 256;
/* 449 */     JTermios.PARODD = 512;
/* 450 */     JTermios.B0 = 0;
/* 451 */     JTermios.B50 = 1;
/* 452 */     JTermios.B75 = 2;
/* 453 */     JTermios.B110 = 3;
/* 454 */     JTermios.B134 = 4;
/* 455 */     JTermios.B150 = 5;
/* 456 */     JTermios.B200 = 6;
/* 457 */     JTermios.B300 = 7;
/* 458 */     JTermios.B600 = 8;
/* 459 */     JTermios.B1200 = 9;
/* 460 */     JTermios.B1800 = 10;
/* 461 */     JTermios.B2400 = 11;
/* 462 */     JTermios.B4800 = 12;
/* 463 */     JTermios.B9600 = 13;
/* 464 */     JTermios.B19200 = 14;
/* 465 */     JTermios.B38400 = 15;
/* 466 */     JTermios.B57600 = 4097;
/* 467 */     JTermios.B115200 = 4098;
/* 468 */     JTermios.B230400 = 4099;
/*     */     
/* 470 */     JTermios.POLLIN = 1;
/* 471 */     JTermios.POLLPRI = 2;
/* 472 */     JTermios.POLLOUT = 4;
/* 473 */     JTermios.POLLERR = 8;
/* 474 */     JTermios.POLLNVAL = 32;
/*     */ 
/*     */     
/* 477 */     JTermios.POLLIN_IN = pollMask(0, JTermios.POLLIN);
/* 478 */     JTermios.POLLOUT_IN = pollMask(0, JTermios.POLLOUT);
/*     */     
/* 480 */     JTermios.POLLIN_OUT = pollMask(1, JTermios.POLLIN);
/* 481 */     JTermios.POLLOUT_OUT = pollMask(1, JTermios.POLLOUT);
/* 482 */     JTermios.POLLNVAL_OUT = pollMask(1, JTermios.POLLNVAL);
/*     */   }
/*     */   
/*     */   public static int pollMask(int paramInt, short paramShort) {
/* 486 */     short[] arrayOfShort = new short[2];
/* 487 */     int[] arrayOfInt = new int[1];
/* 488 */     arrayOfShort[paramInt] = paramShort;
/*     */     
/* 490 */     if (IS64B) {
/* 491 */       m_ClibDM.memcpy(arrayOfInt, arrayOfShort, 4L);
/*     */     } else {
/* 493 */       m_ClibDM.memcpy(arrayOfInt, arrayOfShort, 4);
/* 494 */     }  return arrayOfInt[0];
/*     */   }
/*     */   
/*     */   public int errno() {
/* 498 */     return Native.getLastError();
/*     */   }
/*     */   
/*     */   public void cfmakeraw(Termios paramTermios) {
/* 502 */     Linux_C_lib.termios termios = new Linux_C_lib.termios(paramTermios);
/* 503 */     m_Clib.cfmakeraw(termios);
/* 504 */     termios.update(paramTermios);
/*     */   }
/*     */   
/*     */   public int fcntl(int paramInt1, int paramInt2, int paramInt3) {
/* 508 */     return m_Clib.fcntl(paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   public int tcdrain(int paramInt) {
/* 512 */     return m_Clib.tcdrain(paramInt);
/*     */   }
/*     */   
/*     */   public int cfgetispeed(Termios paramTermios) {
/* 516 */     return m_Clib.cfgetispeed(new Linux_C_lib.termios(paramTermios)).intValue();
/*     */   }
/*     */   
/*     */   public int cfgetospeed(Termios paramTermios) {
/* 520 */     return m_Clib.cfgetospeed(new Linux_C_lib.termios(paramTermios)).intValue();
/*     */   }
/*     */   
/*     */   public int cfsetispeed(Termios paramTermios, int paramInt) {
/* 524 */     Linux_C_lib.termios termios = new Linux_C_lib.termios(paramTermios);
/* 525 */     int i = m_Clib.cfsetispeed(termios, new NativeLong(paramInt));
/* 526 */     termios.update(paramTermios);
/* 527 */     return i;
/*     */   }
/*     */   
/*     */   public int cfsetospeed(Termios paramTermios, int paramInt) {
/* 531 */     Linux_C_lib.termios termios = new Linux_C_lib.termios(paramTermios);
/* 532 */     int i = m_Clib.cfsetospeed(termios, new NativeLong(paramInt));
/* 533 */     termios.update(paramTermios);
/* 534 */     return i;
/*     */   }
/*     */   
/*     */   public int open(String paramString, int paramInt) {
/* 538 */     if (paramString != null && !paramString.startsWith("/"))
/* 539 */       paramString = DEVICE_DIR_PATH + paramString; 
/* 540 */     return m_Clib.open(paramString, paramInt);
/*     */   }
/*     */   
/*     */   public int read(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
/* 544 */     if (IS64B) {
/* 545 */       return (int)m_Clib.read(paramInt1, paramArrayOfbyte, paramInt2);
/*     */     }
/* 547 */     return m_Clib.read(paramInt1, paramArrayOfbyte, paramInt2);
/*     */   }
/*     */   
/*     */   public int write(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
/* 551 */     if (IS64B) {
/* 552 */       return (int)m_Clib.write(paramInt1, paramArrayOfbyte, paramInt2);
/*     */     }
/* 554 */     return m_Clib.write(paramInt1, paramArrayOfbyte, paramInt2);
/*     */   }
/*     */   
/*     */   public int close(int paramInt) {
/* 558 */     return m_Clib.close(paramInt);
/*     */   }
/*     */   
/*     */   public int tcflush(int paramInt1, int paramInt2) {
/* 562 */     return m_Clib.tcflush(paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public int tcgetattr(int paramInt, Termios paramTermios) {
/* 566 */     Linux_C_lib.termios termios = new Linux_C_lib.termios();
/* 567 */     int i = m_Clib.tcgetattr(paramInt, termios);
/* 568 */     termios.update(paramTermios);
/* 569 */     return i;
/*     */   }
/*     */   
/*     */   public void perror(String paramString) {
/* 573 */     m_Clib.perror(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int tcsendbreak(int paramInt1, int paramInt2) {
/* 579 */     return m_Clib.tcsendbreak(paramInt1, paramInt2 / 250);
/*     */   }
/*     */   
/*     */   public int tcsetattr(int paramInt1, int paramInt2, Termios paramTermios) {
/* 583 */     return m_Clib.tcsetattr(paramInt1, paramInt2, new Linux_C_lib.termios(paramTermios));
/*     */   }
/*     */   
/*     */   public void FD_CLR(int paramInt, FDSet paramFDSet) {
/* 587 */     if (paramFDSet == null)
/*     */       return; 
/* 589 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/* 590 */     fDSetImpl.bits[paramInt / 32] = fDSetImpl.bits[paramInt / 32] & (1 << paramInt % 32 ^ 0xFFFFFFFF);
/*     */   }
/*     */   
/*     */   public boolean FD_ISSET(int paramInt, FDSet paramFDSet) {
/* 594 */     if (paramFDSet == null)
/* 595 */       return false; 
/* 596 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/* 597 */     return ((fDSetImpl.bits[paramInt / 32] & 1 << paramInt % 32) != 0);
/*     */   }
/*     */   
/*     */   public void FD_SET(int paramInt, FDSet paramFDSet) {
/* 601 */     if (paramFDSet == null)
/*     */       return; 
/* 603 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/* 604 */     fDSetImpl.bits[paramInt / 32] = fDSetImpl.bits[paramInt / 32] | 1 << paramInt % 32;
/*     */   }
/*     */   
/*     */   public void FD_ZERO(FDSet paramFDSet) {
/* 608 */     if (paramFDSet == null)
/*     */       return; 
/* 610 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/* 611 */     Arrays.fill(fDSetImpl.bits, 0);
/*     */   }
/*     */   
/*     */   public int select(int paramInt, FDSet paramFDSet1, FDSet paramFDSet2, FDSet paramFDSet3, TimeVal paramTimeVal) {
/* 615 */     Linux_C_lib.timeval timeval = null;
/* 616 */     if (paramTimeVal != null) {
/* 617 */       timeval = new Linux_C_lib.timeval(paramTimeVal);
/*     */     }
/* 619 */     int[] arrayOfInt1 = (paramFDSet1 != null) ? ((FDSetImpl)paramFDSet1).bits : null;
/* 620 */     int[] arrayOfInt2 = (paramFDSet2 != null) ? ((FDSetImpl)paramFDSet2).bits : null;
/* 621 */     int[] arrayOfInt3 = (paramFDSet3 != null) ? ((FDSetImpl)paramFDSet3).bits : null;
/* 622 */     return m_Clib.select(paramInt, arrayOfInt1, arrayOfInt2, arrayOfInt3, timeval);
/*     */   }
/*     */   
/*     */   public int poll(Pollfd[] paramArrayOfPollfd, int paramInt1, int paramInt2) {
/* 626 */     Linux_C_lib.pollfd[] arrayOfPollfd = new Linux_C_lib.pollfd[paramArrayOfPollfd.length]; int i;
/* 627 */     for (i = 0; i < paramInt1; i++)
/* 628 */       arrayOfPollfd[i] = new Linux_C_lib.pollfd(paramArrayOfPollfd[i]); 
/* 629 */     i = m_Clib.poll(arrayOfPollfd, paramInt1, paramInt2);
/* 630 */     for (byte b = 0; b < paramInt1; b++)
/* 631 */       (paramArrayOfPollfd[b]).revents = (arrayOfPollfd[b]).revents; 
/* 632 */     return i;
/*     */   }
/*     */   
/*     */   public int poll(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/* 636 */     return m_Clib.poll(paramArrayOfint, paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public FDSet newFDSet() {
/* 640 */     return new FDSetImpl();
/*     */   }
/*     */   
/*     */   public int ioctl(int paramInt1, int paramInt2, int[] paramArrayOfint) {
/* 644 */     return m_Clib.ioctl(paramInt1, paramInt2, paramArrayOfint);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int ioctl(int paramInt1, int paramInt2, Linux_C_lib.serial_struct paramserial_struct) {
/* 650 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> ioctl(%d,%d,%s)\n", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), paramserial_struct }));
/* 651 */     int i = m_Clib.ioctl(paramInt1, paramInt2, paramserial_struct);
/* 652 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(3, "< tcsetattr(%d,%d,%s) => %d\n", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), paramserial_struct, Integer.valueOf(i) }));
/* 653 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPortNamePattern() {
/* 659 */     ArrayList<String> arrayList = new ArrayList();
/*     */     
/*     */     try {
/* 662 */       BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("/proc/tty/drivers"), "US-ASCII"));
/*     */       String str;
/* 664 */       while ((str = bufferedReader.readLine()) != null) {
/*     */ 
/*     */ 
/*     */         
/* 668 */         String[] arrayOfString = str.split(" +");
/* 669 */         if (arrayOfString.length != 5) {
/*     */           continue;
/*     */         }
/*     */         
/* 673 */         if (!"serial".equals(arrayOfString[4])) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */         
/* 678 */         if (!arrayOfString[1].startsWith("/dev/")) {
/*     */           continue;
/*     */         }
/*     */         
/* 682 */         arrayList.add(arrayOfString[1].substring(5));
/*     */       } 
/* 684 */       bufferedReader.close();
/* 685 */     } catch (IOException iOException) {
/* 686 */       JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "failed to read /proc/tty/drivers\n", new Object[0]));
/*     */       
/* 688 */       arrayList.add("ttyS");
/* 689 */       arrayList.add("ttyUSB");
/* 690 */       arrayList.add("ttyACM");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 695 */     StringBuilder stringBuilder = new StringBuilder();
/*     */     
/* 697 */     stringBuilder.append('^');
/*     */     
/* 699 */     boolean bool = true;
/* 700 */     for (String str : arrayList) {
/* 701 */       if (bool) {
/* 702 */         bool = false;
/*     */       } else {
/* 704 */         stringBuilder.append('|');
/*     */       } 
/*     */       
/* 707 */       stringBuilder.append("(");
/* 708 */       stringBuilder.append(str);
/* 709 */       stringBuilder.append(".+)");
/*     */     } 
/*     */     
/* 712 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */   public List<String> getPortList() {
/* 716 */     File file = new File(DEVICE_DIR_PATH);
/* 717 */     if (!file.isDirectory()) {
/* 718 */       JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "device directory %s does not exist\n", new Object[] { DEVICE_DIR_PATH }));
/* 719 */       return null;
/*     */     } 
/* 721 */     String[] arrayOfString = file.list();
/* 722 */     LinkedList<String> linkedList = new LinkedList();
/*     */     
/* 724 */     Pattern pattern = JTermios.getPortNamePattern(this);
/* 725 */     if (arrayOfString != null)
/* 726 */       for (byte b = 0; b < arrayOfString.length; b++) {
/* 727 */         String str = arrayOfString[b];
/* 728 */         if (pattern.matcher(str).matches()) {
/* 729 */           linkedList.add(str);
/*     */         }
/*     */       }  
/* 732 */     return linkedList;
/*     */   }
/*     */ 
/*     */   
/*     */   public void shutDown() {}
/*     */ 
/*     */   
/*     */   public int setspeed(int paramInt1, Termios paramTermios, int paramInt2) {
/* 740 */     int i = paramInt2;
/*     */     
/* 742 */     for (byte b = 0; b < m_BaudRates.length; b += 2) {
/* 743 */       if (m_BaudRates[b] == paramInt2) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 748 */         Linux_C_lib.serial_struct serial_struct1 = new Linux_C_lib.serial_struct();
/*     */         
/* 750 */         int m = ioctl(paramInt1, 21534, serial_struct1);
/* 751 */         if (m == 0) {
/* 752 */           serial_struct1.flags &= 0xFFFFEFCF;
/* 753 */           m = ioctl(paramInt1, 21535, serial_struct1);
/*     */         } 
/*     */ 
/*     */         
/* 757 */         i = m_BaudRates[b + 1];
/* 758 */         if ((m = JTermios.cfsetispeed(paramTermios, i)) != 0)
/* 759 */           return m; 
/* 760 */         if ((m = JTermios.cfsetospeed(paramTermios, i)) != 0)
/* 761 */           return m; 
/* 762 */         if ((m = JTermios.tcsetattr(paramInt1, JTermios.TCSANOW, paramTermios)) != 0) {
/* 763 */           return m;
/*     */         }
/* 765 */         return 0;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 772 */     Linux_C_lib.serial_struct serial_struct = new Linux_C_lib.serial_struct(); int j;
/* 773 */     if ((j = ioctl(paramInt1, 21534, serial_struct)) != 0)
/* 774 */       return j; 
/* 775 */     serial_struct.flags = serial_struct.flags & 0xFFFFEFCF | 0x30;
/*     */     
/* 777 */     if (paramInt2 == 0) {
/* 778 */       JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "unable to set custom baudrate %d \n", new Object[] { Integer.valueOf(paramInt2) }));
/* 779 */       return -1;
/*     */     } 
/*     */     
/* 782 */     serial_struct.custom_divisor = (serial_struct.baud_base + paramInt2 / 2) / paramInt2;
/*     */     
/* 784 */     if (serial_struct.custom_divisor == 0) {
/* 785 */       JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "unable to set custom baudrate %d (possible division by zero)\n", new Object[] { Integer.valueOf(paramInt2) }));
/* 786 */       return -1;
/*     */     } 
/*     */     
/* 789 */     int k = serial_struct.baud_base / serial_struct.custom_divisor;
/*     */     
/* 791 */     if (k < paramInt2 * 98 / 100 || k > paramInt2 * 102 / 100) {
/* 792 */       JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "best available baudrate %d not close enough to requested %d \n", new Object[] { Integer.valueOf(k), Integer.valueOf(paramInt2) }));
/* 793 */       return -1;
/*     */     } 
/*     */     
/* 796 */     if ((j = ioctl(paramInt1, 21535, serial_struct)) != 0) {
/* 797 */       return j;
/*     */     }
/* 799 */     if ((j = JTermios.cfsetispeed(paramTermios, JTermios.B38400)) != 0)
/* 800 */       return j; 
/* 801 */     if ((j = JTermios.cfsetospeed(paramTermios, JTermios.B38400)) != 0)
/* 802 */       return j; 
/* 803 */     if ((j = JTermios.tcsetattr(paramInt1, JTermios.TCSANOW, paramTermios)) != 0)
/* 804 */       return j; 
/* 805 */     return 0;
/*     */   }
/*     */   
/*     */   public int pipe(int[] paramArrayOfint) {
/* 809 */     return m_Clib.pipe(paramArrayOfint);
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\jtermios\linux\JTermiosImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */