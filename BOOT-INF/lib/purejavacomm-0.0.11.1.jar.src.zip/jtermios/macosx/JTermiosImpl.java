/*     */ package jtermios.macosx;
/*     */ 
/*     */ import com.sun.jna.Library;
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.NativeLong;
/*     */ import com.sun.jna.Structure;
/*     */ import java.io.File;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import jtermios.FDSet;
/*     */ import jtermios.JTermios;
/*     */ import jtermios.Pollfd;
/*     */ import jtermios.Termios;
/*     */ import jtermios.TimeVal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JTermiosImpl
/*     */   implements JTermios.JTermiosInterface
/*     */ {
/*  62 */   private static int IOSSIOSPEED = -2147199998;
/*  63 */   private static String DEVICE_DIR_PATH = "/dev/";
/*  64 */   static MacOSX_C_lib m_Clib = (MacOSX_C_lib)Native.loadLibrary("c", MacOSX_C_lib.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class timeval
/*     */     extends Structure
/*     */   {
/*     */     public NativeLong tv_sec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public NativeLong tv_usec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected List getFieldOrder() {
/* 115 */       return Arrays.asList(new String[] { "tv_sec", "tv_usec" });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public timeval(TimeVal param1TimeVal) {
/* 122 */       this.tv_sec = new NativeLong(param1TimeVal.tv_sec);
/* 123 */       this.tv_usec = new NativeLong(param1TimeVal.tv_usec);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class pollfd
/*     */     extends Structure {
/*     */     public int fd;
/*     */     public short events;
/*     */     public short revents;
/*     */     
/*     */     protected List getFieldOrder() {
/* 134 */       return Arrays.asList(new String[] { "fd", "events", "revents" });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public pollfd(Pollfd param1Pollfd)
/*     */     {
/* 142 */       this.fd = param1Pollfd.fd;
/* 143 */       this.events = param1Pollfd.events;
/* 144 */       this.revents = param1Pollfd.revents; } } public static interface MacOSX_C_lib extends Library { int pipe(int[] param1ArrayOfint); int tcdrain(int param1Int); void cfmakeraw(termios param1termios); int fcntl(int param1Int1, int param1Int2, int param1Int3); int ioctl(int param1Int1, int param1Int2, int[] param1ArrayOfint); int ioctl(int param1Int1, int param1Int2, NativeLong[] param1ArrayOfNativeLong); int open(String param1String, int param1Int); int close(int param1Int); int tcgetattr(int param1Int, termios param1termios); int tcsetattr(int param1Int1, int param1Int2, termios param1termios); int cfsetispeed(termios param1termios, NativeLong param1NativeLong); int cfsetospeed(termios param1termios, NativeLong param1NativeLong); NativeLong cfgetispeed(termios param1termios); NativeLong cfgetospeed(termios param1termios); NativeLong write(int param1Int, ByteBuffer param1ByteBuffer, NativeLong param1NativeLong); NativeLong read(int param1Int, ByteBuffer param1ByteBuffer, NativeLong param1NativeLong); int select(int param1Int, int[] param1ArrayOfint1, int[] param1ArrayOfint2, int[] param1ArrayOfint3, timeval param1timeval); int poll(pollfd[] param1ArrayOfpollfd, int param1Int1, int param1Int2); int poll(int[] param1ArrayOfint, int param1Int1, int param1Int2); int tcflush(int param1Int1, int param1Int2); void perror(String param1String); public static class timeval extends Structure { public NativeLong tv_sec; public NativeLong tv_usec; protected List getFieldOrder() { return Arrays.asList(new String[] { "tv_sec", "tv_usec" }); } public timeval(TimeVal param2TimeVal) { this.tv_sec = new NativeLong(param2TimeVal.tv_sec); this.tv_usec = new NativeLong(param2TimeVal.tv_usec); } } public static class pollfd extends Structure { public int fd; public short events; public pollfd(Pollfd param2Pollfd) { this.fd = param2Pollfd.fd; this.events = param2Pollfd.events; this.revents = param2Pollfd.revents; }
/*     */        public short revents;
/*     */       protected List getFieldOrder() {
/*     */         return Arrays.asList(new String[] { "fd", "events", "revents" });
/*     */       } }
/* 149 */     public static class termios extends Structure { public NativeLong c_iflag = new NativeLong();
/* 150 */       public NativeLong c_oflag = new NativeLong();
/* 151 */       public NativeLong c_cflag = new NativeLong();
/* 152 */       public NativeLong c_lflag = new NativeLong();
/* 153 */       public byte[] c_cc = new byte[20];
/* 154 */       public NativeLong c_ispeed = new NativeLong();
/* 155 */       public NativeLong c_ospeed = new NativeLong();
/*     */ 
/*     */       
/*     */       protected List getFieldOrder() {
/* 159 */         return Arrays.asList(new String[] { "c_iflag", "c_oflag", "c_cflag", "c_lflag", "c_cc", "c_ispeed", "c_ospeed" });
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public termios() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public termios(Termios param2Termios) {
/* 174 */         this.c_iflag.setValue(param2Termios.c_iflag);
/* 175 */         this.c_oflag.setValue(param2Termios.c_oflag);
/* 176 */         this.c_cflag.setValue(param2Termios.c_cflag);
/* 177 */         this.c_lflag.setValue(param2Termios.c_lflag);
/* 178 */         System.arraycopy(param2Termios.c_cc, 0, this.c_cc, 0, param2Termios.c_cc.length);
/* 179 */         this.c_ispeed.setValue(param2Termios.c_ispeed);
/* 180 */         this.c_ospeed.setValue(param2Termios.c_ospeed);
/*     */       }
/*     */       
/*     */       public void update(Termios param2Termios) {
/* 184 */         param2Termios.c_iflag = this.c_iflag.intValue();
/* 185 */         param2Termios.c_oflag = this.c_oflag.intValue();
/* 186 */         param2Termios.c_cflag = this.c_cflag.intValue();
/* 187 */         param2Termios.c_lflag = this.c_lflag.intValue();
/* 188 */         System.arraycopy(this.c_cc, 0, param2Termios.c_cc, 0, param2Termios.c_cc.length);
/* 189 */         param2Termios.c_ispeed = this.c_ispeed.intValue();
/* 190 */         param2Termios.c_ospeed = this.c_ospeed.intValue(); } } } public static class termios extends Structure { public NativeLong c_iflag = new NativeLong(); public NativeLong c_oflag = new NativeLong(); public NativeLong c_cflag = new NativeLong(); public NativeLong c_lflag = new NativeLong(); public byte[] c_cc = new byte[20]; public NativeLong c_ispeed = new NativeLong(); public NativeLong c_ospeed = new NativeLong(); protected List getFieldOrder() { return Arrays.asList(new String[] { "c_iflag", "c_oflag", "c_cflag", "c_lflag", "c_cc", "c_ispeed", "c_ospeed" }); } public termios() {} public termios(Termios param1Termios) { this.c_iflag.setValue(param1Termios.c_iflag); this.c_oflag.setValue(param1Termios.c_oflag); this.c_cflag.setValue(param1Termios.c_cflag); this.c_lflag.setValue(param1Termios.c_lflag); System.arraycopy(param1Termios.c_cc, 0, this.c_cc, 0, param1Termios.c_cc.length); this.c_ispeed.setValue(param1Termios.c_ispeed); this.c_ospeed.setValue(param1Termios.c_ospeed); } public void update(Termios param1Termios) { param1Termios.c_iflag = this.c_iflag.intValue(); param1Termios.c_oflag = this.c_oflag.intValue(); param1Termios.c_cflag = this.c_cflag.intValue(); param1Termios.c_lflag = this.c_lflag.intValue(); System.arraycopy(this.c_cc, 0, param1Termios.c_cc, 0, param1Termios.c_cc.length); param1Termios.c_ispeed = this.c_ispeed.intValue(); param1Termios.c_ospeed = this.c_ospeed.intValue(); }
/*     */      }
/*     */ 
/*     */   
/*     */   private static class FDSetImpl
/*     */     extends FDSet {
/*     */     static final int FD_SET_SIZE = 1024;
/*     */     static final int NFBBITS = 32;
/* 198 */     int[] bits = new int[32];
/*     */     
/*     */     public String toString() {
/* 201 */       return String.format("%08X%08X", new Object[] { Integer.valueOf(this.bits[0]), Integer.valueOf(this.bits[1]) });
/*     */     }
/*     */     private FDSetImpl() {} }
/*     */   
/*     */   public JTermiosImpl() {
/* 206 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "instantiating %s\n", new Object[] { getClass().getCanonicalName() }));
/*     */   }
/*     */   
/*     */   public int errno() {
/* 210 */     return Native.getLastError();
/*     */   }
/*     */   
/*     */   public void cfmakeraw(Termios paramTermios) {
/* 214 */     MacOSX_C_lib.termios termios = new MacOSX_C_lib.termios(paramTermios);
/* 215 */     m_Clib.cfmakeraw(termios);
/* 216 */     termios.update(paramTermios);
/*     */   }
/*     */   
/*     */   public int fcntl(int paramInt1, int paramInt2, int paramInt3) {
/* 220 */     return m_Clib.fcntl(paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   public int tcdrain(int paramInt) {
/* 224 */     return m_Clib.tcdrain(paramInt);
/*     */   }
/*     */   
/*     */   public int cfgetispeed(Termios paramTermios) {
/* 228 */     return m_Clib.cfgetispeed(new MacOSX_C_lib.termios(paramTermios)).intValue();
/*     */   }
/*     */   
/*     */   public int cfgetospeed(Termios paramTermios) {
/* 232 */     return m_Clib.cfgetospeed(new MacOSX_C_lib.termios(paramTermios)).intValue();
/*     */   }
/*     */   
/*     */   public int cfsetispeed(Termios paramTermios, int paramInt) {
/* 236 */     MacOSX_C_lib.termios termios = new MacOSX_C_lib.termios(paramTermios);
/* 237 */     int i = m_Clib.cfsetispeed(termios, new NativeLong(paramInt));
/* 238 */     termios.update(paramTermios);
/* 239 */     return i;
/*     */   }
/*     */   
/*     */   public int cfsetospeed(Termios paramTermios, int paramInt) {
/* 243 */     MacOSX_C_lib.termios termios = new MacOSX_C_lib.termios(paramTermios);
/* 244 */     int i = m_Clib.cfsetospeed(termios, new NativeLong(paramInt));
/* 245 */     termios.update(paramTermios);
/* 246 */     return i;
/*     */   }
/*     */   
/*     */   public int open(String paramString, int paramInt) {
/* 250 */     if (paramString != null && !paramString.startsWith("/"))
/* 251 */       paramString = DEVICE_DIR_PATH + paramString; 
/* 252 */     return m_Clib.open(paramString, paramInt);
/*     */   }
/*     */   
/*     */   public int read(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
/* 256 */     return m_Clib.read(paramInt1, ByteBuffer.wrap(paramArrayOfbyte), new NativeLong(paramInt2)).intValue();
/*     */   }
/*     */   
/*     */   public int write(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
/* 260 */     return m_Clib.write(paramInt1, ByteBuffer.wrap(paramArrayOfbyte), new NativeLong(paramInt2)).intValue();
/*     */   }
/*     */   
/*     */   public int close(int paramInt) {
/* 264 */     return m_Clib.close(paramInt);
/*     */   }
/*     */   
/*     */   public int tcflush(int paramInt1, int paramInt2) {
/* 268 */     return m_Clib.tcflush(paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public int tcgetattr(int paramInt, Termios paramTermios) {
/* 272 */     MacOSX_C_lib.termios termios = new MacOSX_C_lib.termios();
/* 273 */     int i = m_Clib.tcgetattr(paramInt, termios);
/* 274 */     termios.update(paramTermios);
/* 275 */     return i;
/*     */   }
/*     */   
/*     */   public void perror(String paramString) {
/* 279 */     m_Clib.perror(paramString);
/*     */   }
/*     */   
/*     */   public int tcsendbreak(int paramInt1, int paramInt2) {
/* 283 */     throw new IllegalArgumentException("Unimplemented function");
/*     */   }
/*     */   
/*     */   public int tcsetattr(int paramInt1, int paramInt2, Termios paramTermios) {
/* 287 */     return m_Clib.tcsetattr(paramInt1, paramInt2, new MacOSX_C_lib.termios(paramTermios));
/*     */   }
/*     */   
/*     */   public void FD_CLR(int paramInt, FDSet paramFDSet) {
/* 291 */     if (paramFDSet == null)
/*     */       return; 
/* 293 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/* 294 */     fDSetImpl.bits[paramInt / 32] = fDSetImpl.bits[paramInt / 32] & (1 << paramInt % 32 ^ 0xFFFFFFFF);
/*     */   }
/*     */   
/*     */   public boolean FD_ISSET(int paramInt, FDSet paramFDSet) {
/* 298 */     if (paramFDSet == null)
/* 299 */       return false; 
/* 300 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/* 301 */     return ((fDSetImpl.bits[paramInt / 32] & 1 << paramInt % 32) != 0);
/*     */   }
/*     */   
/*     */   public void FD_SET(int paramInt, FDSet paramFDSet) {
/* 305 */     if (paramFDSet == null)
/*     */       return; 
/* 307 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/* 308 */     fDSetImpl.bits[paramInt / 32] = fDSetImpl.bits[paramInt / 32] | 1 << paramInt % 32;
/*     */   }
/*     */   
/*     */   public void FD_ZERO(FDSet paramFDSet) {
/* 312 */     if (paramFDSet == null)
/*     */       return; 
/* 314 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/* 315 */     Arrays.fill(fDSetImpl.bits, 0);
/*     */   }
/*     */   
/*     */   public int select(int paramInt, FDSet paramFDSet1, FDSet paramFDSet2, FDSet paramFDSet3, TimeVal paramTimeVal) {
/* 319 */     MacOSX_C_lib.timeval timeval = null;
/* 320 */     if (paramTimeVal != null) {
/* 321 */       timeval = new MacOSX_C_lib.timeval(paramTimeVal);
/*     */     }
/* 323 */     int[] arrayOfInt1 = (paramFDSet1 != null) ? ((FDSetImpl)paramFDSet1).bits : null;
/* 324 */     int[] arrayOfInt2 = (paramFDSet2 != null) ? ((FDSetImpl)paramFDSet2).bits : null;
/* 325 */     int[] arrayOfInt3 = (paramFDSet3 != null) ? ((FDSetImpl)paramFDSet3).bits : null;
/* 326 */     return m_Clib.select(paramInt, arrayOfInt1, arrayOfInt2, arrayOfInt3, timeval);
/*     */   }
/*     */   
/*     */   public int poll(Pollfd[] paramArrayOfPollfd, int paramInt1, int paramInt2) {
/* 330 */     MacOSX_C_lib.pollfd[] arrayOfPollfd = new MacOSX_C_lib.pollfd[paramArrayOfPollfd.length]; int i;
/* 331 */     for (i = 0; i < paramInt1; i++)
/* 332 */       arrayOfPollfd[i] = new MacOSX_C_lib.pollfd(paramArrayOfPollfd[i]); 
/* 333 */     i = m_Clib.poll(arrayOfPollfd, paramInt1, paramInt2);
/* 334 */     for (byte b = 0; b < paramInt1; b++)
/* 335 */       (paramArrayOfPollfd[b]).revents = (arrayOfPollfd[b]).revents; 
/* 336 */     return i;
/*     */   }
/*     */   
/*     */   public int poll(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/* 340 */     return m_Clib.poll(paramArrayOfint, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   public FDSet newFDSet() {
/* 345 */     return new FDSetImpl();
/*     */   }
/*     */   
/*     */   public int ioctl(int paramInt1, int paramInt2, int[] paramArrayOfint) {
/* 349 */     return m_Clib.ioctl(paramInt1, paramInt2, paramArrayOfint);
/*     */   }
/*     */   
/*     */   public int ioctl(int paramInt1, int paramInt2, NativeLong[] paramArrayOfNativeLong) {
/* 353 */     return m_Clib.ioctl(paramInt1, paramInt2, paramArrayOfNativeLong);
/*     */   }
/*     */   
/*     */   public List<String> getPortList() {
/* 357 */     File file = new File(DEVICE_DIR_PATH);
/* 358 */     if (!file.isDirectory()) {
/* 359 */       JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "device directory %s does not exist\n", new Object[] { DEVICE_DIR_PATH }));
/* 360 */       return null;
/*     */     } 
/* 362 */     String[] arrayOfString = file.list();
/* 363 */     LinkedList<String> linkedList = new LinkedList();
/*     */     
/* 365 */     Pattern pattern = JTermios.getPortNamePattern(this);
/* 366 */     if (arrayOfString != null)
/* 367 */       for (byte b = 0; b < arrayOfString.length; b++) {
/* 368 */         String str = arrayOfString[b];
/* 369 */         if (pattern.matcher(str).matches()) {
/* 370 */           linkedList.add(str);
/*     */         }
/*     */       }  
/* 373 */     return linkedList;
/*     */   }
/*     */   
/*     */   public String getPortNamePattern() {
/* 377 */     return "^(tty\\.|cu\\.).*";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutDown() {}
/*     */ 
/*     */   
/*     */   public int setspeed(int paramInt1, Termios paramTermios, int paramInt2) {
/* 386 */     int i = cfsetispeed(paramTermios, paramInt2);
/* 387 */     if (i == 0)
/* 388 */       i = cfsetospeed(paramTermios, paramInt2); 
/* 389 */     if (i == 0)
/* 390 */       i = tcsetattr(paramInt1, JTermios.TCSANOW, paramTermios); 
/* 391 */     if (i != 0)
/*     */     {
/* 393 */       if (cfsetispeed(paramTermios, JTermios.B9600) == 0 && cfsetospeed(paramTermios, JTermios.B9600) == 0 && tcsetattr(paramInt1, JTermios.TCSANOW, paramTermios) == 0) {
/* 394 */         NativeLong[] arrayOfNativeLong = { new NativeLong(paramInt2) };
/* 395 */         i = ioctl(paramInt1, IOSSIOSPEED, arrayOfNativeLong);
/*     */       } 
/*     */     }
/* 398 */     return i;
/*     */   }
/*     */   
/*     */   public int pipe(int[] paramArrayOfint) {
/* 402 */     return m_Clib.pipe(paramArrayOfint);
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\jtermios\macosx\JTermiosImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */