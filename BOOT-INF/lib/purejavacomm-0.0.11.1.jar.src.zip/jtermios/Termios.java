/*    */ package jtermios;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Termios
/*    */ {
/*    */   public int c_iflag;
/*    */   public int c_oflag;
/*    */   public int c_cflag;
/*    */   public int c_lflag;
/* 38 */   public byte[] c_cc = new byte[20];
/*    */   public int c_ispeed;
/*    */   
/*    */   public void set(Termios paramTermios) {
/* 42 */     this.c_iflag = paramTermios.c_iflag;
/* 43 */     this.c_oflag = paramTermios.c_oflag;
/* 44 */     this.c_cflag = paramTermios.c_cflag;
/* 45 */     this.c_lflag = paramTermios.c_lflag;
/* 46 */     System.arraycopy(paramTermios.c_cc, 0, this.c_cc, 0, this.c_cc.length);
/* 47 */     this.c_ispeed = paramTermios.c_ispeed;
/* 48 */     this.c_ospeed = paramTermios.c_ospeed;
/*    */   }
/*    */   
/*    */   public int c_ospeed;
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\jtermios\Termios.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */