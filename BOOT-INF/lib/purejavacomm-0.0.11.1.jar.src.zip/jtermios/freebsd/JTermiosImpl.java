/*     */ package jtermios.freebsd;
/*     */ 
/*     */ import com.sun.jna.Library;
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.NativeLong;
/*     */ import com.sun.jna.Structure;
/*     */ import java.io.File;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import jtermios.FDSet;
/*     */ import jtermios.JTermios;
/*     */ import jtermios.Pollfd;
/*     */ import jtermios.Termios;
/*     */ import jtermios.TimeVal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JTermiosImpl
/*     */   implements JTermios.JTermiosInterface
/*     */ {
/*  65 */   private static String DEVICE_DIR_PATH = "/dev/";
/*  66 */   static FreeBSD_C_lib m_Clib = (FreeBSD_C_lib)Native.loadLibrary("c", FreeBSD_C_lib.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class timeval
/*     */     extends Structure
/*     */   {
/*     */     public NativeLong tv_sec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public NativeLong tv_usec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected List getFieldOrder() {
/* 120 */       return Arrays.asList(new String[] { "tv_sec", "tv_usec" });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public timeval(TimeVal param1TimeVal) {
/* 127 */       this.tv_sec = new NativeLong(param1TimeVal.tv_sec);
/* 128 */       this.tv_usec = new NativeLong(param1TimeVal.tv_usec);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class pollfd
/*     */     extends Structure {
/*     */     public int fd;
/*     */     public short events;
/*     */     public short revents;
/*     */     
/*     */     protected List getFieldOrder() {
/* 139 */       return Arrays.asList(new String[] { "fd", "events", "revents" });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public pollfd(Pollfd param1Pollfd)
/*     */     {
/* 147 */       this.fd = param1Pollfd.fd;
/* 148 */       this.events = param1Pollfd.events;
/* 149 */       this.revents = param1Pollfd.revents; } } public static interface FreeBSD_C_lib extends Library { int pipe(int[] param1ArrayOfint); int tcdrain(int param1Int); void cfmakeraw(termios param1termios); int fcntl(int param1Int1, int param1Int2, int[] param1ArrayOfint); int fcntl(int param1Int1, int param1Int2, int param1Int3); int ioctl(int param1Int1, int param1Int2, int[] param1ArrayOfint); int open(String param1String, int param1Int); int close(int param1Int); int tcgetattr(int param1Int, termios param1termios); int tcsetattr(int param1Int1, int param1Int2, termios param1termios); int cfsetispeed(termios param1termios, NativeLong param1NativeLong); int cfsetospeed(termios param1termios, NativeLong param1NativeLong); NativeLong cfgetispeed(termios param1termios); NativeLong cfgetospeed(termios param1termios); NativeLong write(int param1Int, ByteBuffer param1ByteBuffer, NativeLong param1NativeLong); NativeLong read(int param1Int, ByteBuffer param1ByteBuffer, NativeLong param1NativeLong); int select(int param1Int, NativeLong[] param1ArrayOfNativeLong1, NativeLong[] param1ArrayOfNativeLong2, NativeLong[] param1ArrayOfNativeLong3, timeval param1timeval); int poll(pollfd[] param1ArrayOfpollfd, int param1Int1, int param1Int2); int poll(int[] param1ArrayOfint, int param1Int1, int param1Int2); int tcflush(int param1Int1, int param1Int2); void perror(String param1String); int tcsendbreak(int param1Int1, int param1Int2); public static class timeval extends Structure { public NativeLong tv_sec; public NativeLong tv_usec; protected List getFieldOrder() { return Arrays.asList(new String[] { "tv_sec", "tv_usec" }); } public timeval(TimeVal param2TimeVal) { this.tv_sec = new NativeLong(param2TimeVal.tv_sec); this.tv_usec = new NativeLong(param2TimeVal.tv_usec); } } public static class pollfd extends Structure { public int fd; public short events; public pollfd(Pollfd param2Pollfd) { this.fd = param2Pollfd.fd; this.events = param2Pollfd.events; this.revents = param2Pollfd.revents; }
/*     */       
/*     */       public short revents;
/*     */       protected List getFieldOrder() {
/*     */         return Arrays.asList(new String[] { "fd", "events", "revents" });
/*     */       } }
/*     */     public static class termios extends Structure { public int c_iflag; public int c_oflag;
/*     */       public int c_cflag;
/*     */       public int c_lflag;
/* 158 */       public byte[] c_cc = new byte[20];
/*     */       
/*     */       public int c_ispeed;
/*     */       public int c_ospeed;
/*     */       
/*     */       protected List getFieldOrder() {
/* 164 */         return Arrays.asList(new String[] { "c_iflag", "c_oflag", "c_cflag", "c_lflag", "c_cc", "c_ispeed", "c_ospeed" });
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public termios() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public termios(Termios param2Termios) {
/* 178 */         this.c_iflag = param2Termios.c_iflag;
/* 179 */         this.c_oflag = param2Termios.c_oflag;
/* 180 */         this.c_cflag = param2Termios.c_cflag;
/* 181 */         this.c_lflag = param2Termios.c_lflag;
/* 182 */         System.arraycopy(param2Termios.c_cc, 0, this.c_cc, 0, param2Termios.c_cc.length);
/* 183 */         this.c_ispeed = param2Termios.c_ispeed;
/* 184 */         this.c_ospeed = param2Termios.c_ospeed;
/*     */       }
/*     */       
/*     */       public void update(Termios param2Termios) {
/* 188 */         param2Termios.c_iflag = this.c_iflag;
/* 189 */         param2Termios.c_oflag = this.c_oflag;
/* 190 */         param2Termios.c_cflag = this.c_cflag;
/* 191 */         param2Termios.c_lflag = this.c_lflag;
/* 192 */         System.arraycopy(this.c_cc, 0, param2Termios.c_cc, 0, param2Termios.c_cc.length);
/* 193 */         param2Termios.c_ispeed = this.c_ispeed;
/* 194 */         param2Termios.c_ospeed = this.c_ospeed; } } } public static class termios extends Structure { public int c_iflag; public int c_oflag; public int c_cflag; public int c_lflag; public byte[] c_cc = new byte[20]; public int c_ispeed; public int c_ospeed; protected List getFieldOrder() { return Arrays.asList(new String[] { "c_iflag", "c_oflag", "c_cflag", "c_lflag", "c_cc", "c_ispeed", "c_ospeed" }); } public termios() {} public termios(Termios param1Termios) { this.c_iflag = param1Termios.c_iflag; this.c_oflag = param1Termios.c_oflag; this.c_cflag = param1Termios.c_cflag; this.c_lflag = param1Termios.c_lflag; System.arraycopy(param1Termios.c_cc, 0, this.c_cc, 0, param1Termios.c_cc.length); this.c_ispeed = param1Termios.c_ispeed; this.c_ospeed = param1Termios.c_ospeed; } public void update(Termios param1Termios) { param1Termios.c_iflag = this.c_iflag; param1Termios.c_oflag = this.c_oflag; param1Termios.c_cflag = this.c_cflag; param1Termios.c_lflag = this.c_lflag; System.arraycopy(this.c_cc, 0, param1Termios.c_cc, 0, param1Termios.c_cc.length); param1Termios.c_ispeed = this.c_ispeed; param1Termios.c_ospeed = this.c_ospeed; }
/*     */      }
/*     */ 
/*     */   
/*     */   private static class FDSetImpl
/*     */     extends FDSet
/*     */   {
/*     */     static final int FD_SET_SIZE = 1024;
/* 202 */     static final int NFBBITS = NativeLong.SIZE * 8;
/*     */     
/* 204 */     NativeLong[] bits = new NativeLong[(1024 + NFBBITS - 1) / NFBBITS];
/*     */     
/*     */     public String toString() {
/* 207 */       return String.format("%08X%08X", new Object[] { this.bits[0], this.bits[1] });
/*     */     }
/*     */     private FDSetImpl() {} }
/*     */   
/*     */   public JTermiosImpl() {
/* 212 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "instantiating %s\n", new Object[] { getClass().getCanonicalName() }));
/*     */ 
/*     */     
/* 215 */     JTermios.FIONREAD = 1074030207;
/*     */     
/* 217 */     JTermios.O_RDWR = 2;
/* 218 */     JTermios.O_NONBLOCK = 4;
/* 219 */     JTermios.O_NOCTTY = 32768;
/* 220 */     JTermios.O_NDELAY = 4;
/* 221 */     JTermios.F_GETFL = 3;
/* 222 */     JTermios.F_SETFL = 4;
/*     */     
/* 224 */     JTermios.EAGAIN = 35;
/* 225 */     JTermios.EBADF = 9;
/* 226 */     JTermios.EACCES = 22;
/* 227 */     JTermios.EEXIST = 17;
/* 228 */     JTermios.EINTR = 4;
/* 229 */     JTermios.EINVAL = 22;
/* 230 */     JTermios.EIO = 5;
/* 231 */     JTermios.EISDIR = 21;
/* 232 */     JTermios.ELOOP = 62;
/* 233 */     JTermios.EMFILE = 24;
/* 234 */     JTermios.ENAMETOOLONG = 63;
/* 235 */     JTermios.ENFILE = 23;
/* 236 */     JTermios.ENOENT = 2;
/* 237 */     JTermios.ENOSPC = 28;
/* 238 */     JTermios.ENOTDIR = 20;
/* 239 */     JTermios.ENXIO = 6;
/* 240 */     JTermios.EOVERFLOW = 84;
/* 241 */     JTermios.EROFS = 30;
/* 242 */     JTermios.ENOTSUP = 45;
/*     */     
/* 244 */     JTermios.TIOCM_RNG = 128;
/* 245 */     JTermios.TIOCM_CAR = 64;
/* 246 */     JTermios.IGNBRK = 1;
/* 247 */     JTermios.BRKINT = 2;
/* 248 */     JTermios.PARMRK = 8;
/* 249 */     JTermios.INLCR = 64;
/* 250 */     JTermios.IGNCR = 128;
/* 251 */     JTermios.ICRNL = 256;
/* 252 */     JTermios.ECHONL = 16;
/* 253 */     JTermios.IEXTEN = 1024;
/* 254 */     JTermios.CLOCAL = 32768;
/* 255 */     JTermios.OPOST = 1;
/* 256 */     JTermios.VSTART = 12;
/* 257 */     JTermios.TCSANOW = 0;
/* 258 */     JTermios.VSTOP = 13;
/* 259 */     JTermios.VMIN = 16;
/* 260 */     JTermios.VTIME = 17;
/* 261 */     JTermios.VEOF = 0;
/* 262 */     JTermios.TIOCMGET = 1074033770;
/* 263 */     JTermios.TIOCM_CTS = 32;
/* 264 */     JTermios.TIOCM_DSR = 256;
/* 265 */     JTermios.TIOCM_RI = 128;
/* 266 */     JTermios.TIOCM_CD = 64;
/* 267 */     JTermios.TIOCM_DTR = 2;
/* 268 */     JTermios.TIOCM_RTS = 4;
/* 269 */     JTermios.ICANON = 256;
/* 270 */     JTermios.ECHO = 8;
/* 271 */     JTermios.ECHOE = 2;
/* 272 */     JTermios.ISIG = 128;
/* 273 */     JTermios.TIOCMSET = -2147191699;
/* 274 */     JTermios.IXON = 512;
/* 275 */     JTermios.IXOFF = 1024;
/* 276 */     JTermios.IXANY = 2048;
/* 277 */     JTermios.CRTSCTS = 196608;
/* 278 */     JTermios.TCSADRAIN = 1;
/* 279 */     JTermios.INPCK = 16;
/* 280 */     JTermios.ISTRIP = 32;
/* 281 */     JTermios.CSIZE = 768;
/* 282 */     JTermios.TCIFLUSH = 1;
/* 283 */     JTermios.TCOFLUSH = 2;
/* 284 */     JTermios.TCIOFLUSH = 3;
/* 285 */     JTermios.CS5 = 0;
/* 286 */     JTermios.CS6 = 256;
/* 287 */     JTermios.CS7 = 512;
/* 288 */     JTermios.CS8 = 768;
/* 289 */     JTermios.CSTOPB = 1024;
/* 290 */     JTermios.CREAD = 2048;
/* 291 */     JTermios.PARENB = 4096;
/* 292 */     JTermios.PARODD = 8192;
/* 293 */     JTermios.B0 = 0;
/* 294 */     JTermios.B50 = 50;
/* 295 */     JTermios.B75 = 75;
/* 296 */     JTermios.B110 = 110;
/* 297 */     JTermios.B134 = 134;
/* 298 */     JTermios.B150 = 150;
/* 299 */     JTermios.B200 = 200;
/* 300 */     JTermios.B300 = 300;
/* 301 */     JTermios.B600 = 600;
/* 302 */     JTermios.B1200 = 600;
/* 303 */     JTermios.B1800 = 1800;
/* 304 */     JTermios.B2400 = 2400;
/* 305 */     JTermios.B4800 = 4800;
/* 306 */     JTermios.B9600 = 9600;
/* 307 */     JTermios.B19200 = 19200;
/* 308 */     JTermios.B38400 = 38400;
/* 309 */     JTermios.B7200 = 7200;
/* 310 */     JTermios.B14400 = 14400;
/* 311 */     JTermios.B28800 = 28800;
/* 312 */     JTermios.B57600 = 57600;
/* 313 */     JTermios.B76800 = 76800;
/* 314 */     JTermios.B115200 = 115200;
/* 315 */     JTermios.B230400 = 230400;
/*     */     
/* 317 */     JTermios.POLLIN = 1;
/* 318 */     JTermios.POLLPRI = 2;
/* 319 */     JTermios.POLLOUT = 4;
/* 320 */     JTermios.POLLERR = 8;
/* 321 */     JTermios.POLLNVAL = 32;
/*     */   }
/*     */ 
/*     */   
/*     */   public int errno() {
/* 326 */     return Native.getLastError();
/*     */   }
/*     */   
/*     */   public void cfmakeraw(Termios paramTermios) {
/* 330 */     FreeBSD_C_lib.termios termios = new FreeBSD_C_lib.termios(paramTermios);
/* 331 */     m_Clib.cfmakeraw(termios);
/* 332 */     termios.update(paramTermios);
/*     */   }
/*     */   
/*     */   public int fcntl(int paramInt1, int paramInt2, int[] paramArrayOfint) {
/* 336 */     return m_Clib.fcntl(paramInt1, paramInt2, paramArrayOfint);
/*     */   }
/*     */   
/*     */   public int fcntl(int paramInt1, int paramInt2, int paramInt3) {
/* 340 */     return m_Clib.fcntl(paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   public int tcdrain(int paramInt) {
/* 344 */     return m_Clib.tcdrain(paramInt);
/*     */   }
/*     */   
/*     */   public int cfgetispeed(Termios paramTermios) {
/* 348 */     return m_Clib.cfgetispeed(new FreeBSD_C_lib.termios(paramTermios)).intValue();
/*     */   }
/*     */   
/*     */   public int cfgetospeed(Termios paramTermios) {
/* 352 */     return m_Clib.cfgetospeed(new FreeBSD_C_lib.termios(paramTermios)).intValue();
/*     */   }
/*     */   
/*     */   public int cfsetispeed(Termios paramTermios, int paramInt) {
/* 356 */     FreeBSD_C_lib.termios termios = new FreeBSD_C_lib.termios(paramTermios);
/* 357 */     int i = m_Clib.cfsetispeed(termios, new NativeLong(paramInt));
/* 358 */     termios.update(paramTermios);
/* 359 */     return i;
/*     */   }
/*     */   
/*     */   public int cfsetospeed(Termios paramTermios, int paramInt) {
/* 363 */     FreeBSD_C_lib.termios termios = new FreeBSD_C_lib.termios(paramTermios);
/* 364 */     int i = m_Clib.cfsetospeed(termios, new NativeLong(paramInt));
/* 365 */     termios.update(paramTermios);
/* 366 */     return i;
/*     */   }
/*     */   
/*     */   public int open(String paramString, int paramInt) {
/* 370 */     if (paramString != null && !paramString.startsWith("/"))
/* 371 */       paramString = DEVICE_DIR_PATH + paramString; 
/* 372 */     return m_Clib.open(paramString, paramInt);
/*     */   }
/*     */   
/*     */   public int read(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
/* 376 */     return m_Clib.read(paramInt1, ByteBuffer.wrap(paramArrayOfbyte), new NativeLong(paramInt2)).intValue();
/*     */   }
/*     */   
/*     */   public int write(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
/* 380 */     return m_Clib.write(paramInt1, ByteBuffer.wrap(paramArrayOfbyte), new NativeLong(paramInt2)).intValue();
/*     */   }
/*     */   
/*     */   public int close(int paramInt) {
/* 384 */     return m_Clib.close(paramInt);
/*     */   }
/*     */   
/*     */   public int tcflush(int paramInt1, int paramInt2) {
/* 388 */     return m_Clib.tcflush(paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public int tcgetattr(int paramInt, Termios paramTermios) {
/* 392 */     FreeBSD_C_lib.termios termios = new FreeBSD_C_lib.termios();
/* 393 */     int i = m_Clib.tcgetattr(paramInt, termios);
/* 394 */     termios.update(paramTermios);
/* 395 */     return i;
/*     */   }
/*     */   
/*     */   public void perror(String paramString) {
/* 399 */     m_Clib.perror(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int tcsendbreak(int paramInt1, int paramInt2) {
/* 405 */     return m_Clib.tcsendbreak(paramInt1, paramInt2 / 250);
/*     */   }
/*     */   
/*     */   public int tcsetattr(int paramInt1, int paramInt2, Termios paramTermios) {
/* 409 */     return m_Clib.tcsetattr(paramInt1, paramInt2, new FreeBSD_C_lib.termios(paramTermios));
/*     */   }
/*     */   
/*     */   public void FD_CLR(int paramInt, FDSet paramFDSet) {
/* 413 */     if (paramFDSet == null)
/*     */       return; 
/* 415 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/*     */     
/* 417 */     int i = paramInt / FDSetImpl.NFBBITS;
/* 418 */     fDSetImpl.bits[i] = new NativeLong(fDSetImpl.bits[i].longValue() & (1 << paramInt % FDSetImpl.NFBBITS ^ 0xFFFFFFFF));
/*     */   }
/*     */   
/*     */   public boolean FD_ISSET(int paramInt, FDSet paramFDSet) {
/* 422 */     if (paramFDSet == null)
/* 423 */       return false; 
/* 424 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/*     */     
/* 426 */     int i = paramInt / FDSetImpl.NFBBITS;
/* 427 */     return ((fDSetImpl.bits[i].longValue() & (1 << paramInt % FDSetImpl.NFBBITS)) != 0L);
/*     */   }
/*     */   
/*     */   public void FD_SET(int paramInt, FDSet paramFDSet) {
/* 431 */     if (paramFDSet == null)
/*     */       return; 
/* 433 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/*     */     
/* 435 */     int i = paramInt / FDSetImpl.NFBBITS;
/* 436 */     fDSetImpl.bits[i] = new NativeLong(fDSetImpl.bits[i].longValue() | (1 << paramInt % FDSetImpl.NFBBITS));
/*     */   }
/*     */   
/*     */   public void FD_ZERO(FDSet paramFDSet) {
/* 440 */     if (paramFDSet == null)
/*     */       return; 
/* 442 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/*     */     
/* 444 */     Arrays.fill((Object[])fDSetImpl.bits, new NativeLong(0L));
/*     */   }
/*     */   
/*     */   public int select(int paramInt, FDSet paramFDSet1, FDSet paramFDSet2, FDSet paramFDSet3, TimeVal paramTimeVal) {
/* 448 */     FreeBSD_C_lib.timeval timeval = null;
/* 449 */     if (paramTimeVal != null) {
/* 450 */       timeval = new FreeBSD_C_lib.timeval(paramTimeVal);
/*     */     }
/*     */     
/* 453 */     NativeLong[] arrayOfNativeLong1 = (paramFDSet1 != null) ? ((FDSetImpl)paramFDSet1).bits : null;
/*     */     
/* 455 */     NativeLong[] arrayOfNativeLong2 = (paramFDSet2 != null) ? ((FDSetImpl)paramFDSet2).bits : null;
/*     */     
/* 457 */     NativeLong[] arrayOfNativeLong3 = (paramFDSet3 != null) ? ((FDSetImpl)paramFDSet3).bits : null;
/* 458 */     return m_Clib.select(paramInt, arrayOfNativeLong1, arrayOfNativeLong2, arrayOfNativeLong3, timeval);
/*     */   }
/*     */   
/*     */   public int poll(Pollfd[] paramArrayOfPollfd, int paramInt1, int paramInt2) {
/* 462 */     FreeBSD_C_lib.pollfd[] arrayOfPollfd = new FreeBSD_C_lib.pollfd[paramArrayOfPollfd.length]; int i;
/* 463 */     for (i = 0; i < paramInt1; i++)
/* 464 */       arrayOfPollfd[i] = new FreeBSD_C_lib.pollfd(paramArrayOfPollfd[i]); 
/* 465 */     i = m_Clib.poll(arrayOfPollfd, paramInt1, paramInt2);
/* 466 */     for (byte b = 0; b < paramInt1; b++)
/* 467 */       (paramArrayOfPollfd[b]).revents = (arrayOfPollfd[b]).revents; 
/* 468 */     return i;
/*     */   }
/*     */   
/*     */   public int poll(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/* 472 */     return m_Clib.poll(paramArrayOfint, paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public FDSet newFDSet() {
/* 476 */     return new FDSetImpl();
/*     */   }
/*     */   
/*     */   public int ioctl(int paramInt1, int paramInt2, int[] paramArrayOfint) {
/* 480 */     return m_Clib.ioctl(paramInt1, paramInt2, paramArrayOfint);
/*     */   }
/*     */   
/*     */   public List<String> getPortList() {
/* 484 */     File file = new File(DEVICE_DIR_PATH);
/* 485 */     if (!file.isDirectory()) {
/* 486 */       JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "device directory %s does not exist\n", new Object[] { DEVICE_DIR_PATH }));
/* 487 */       return null;
/*     */     } 
/* 489 */     String[] arrayOfString = file.list();
/* 490 */     LinkedList<String> linkedList = new LinkedList();
/* 491 */     if (arrayOfString != null) {
/* 492 */       for (byte b = 0; b < arrayOfString.length; b++) {
/* 493 */         String str = arrayOfString[b];
/* 494 */         if (str.startsWith("cua") || str.startsWith("tty")) {
/* 495 */           linkedList.add(str);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 500 */     return linkedList;
/*     */   }
/*     */ 
/*     */   
/*     */   public void shutDown() {}
/*     */ 
/*     */   
/*     */   public String getPortNamePattern() {
/* 508 */     return "^(tty\\.|cu\\.).*";
/*     */   }
/*     */ 
/*     */   
/*     */   public int setspeed(int paramInt1, Termios paramTermios, int paramInt2) {
/* 513 */     int i = cfsetispeed(paramTermios, paramInt2);
/* 514 */     if (i == 0)
/* 515 */       i = cfsetospeed(paramTermios, paramInt2); 
/* 516 */     if (i == 0)
/* 517 */       i = tcsetattr(paramInt1, JTermios.TCSANOW, paramTermios); 
/* 518 */     return i;
/*     */   }
/*     */   
/*     */   public int pipe(int[] paramArrayOfint) {
/* 522 */     return m_Clib.pipe(paramArrayOfint);
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\jtermios\freebsd\JTermiosImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */