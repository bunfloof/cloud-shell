/*     */ package jtermios;
/*     */ 
/*     */ import com.sun.jna.Platform;
/*     */ import com.sun.jna.Structure;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import jtermios.freebsd.JTermiosImpl;
/*     */ import jtermios.linux.JTermiosImpl;
/*     */ import jtermios.macosx.JTermiosImpl;
/*     */ import jtermios.solaris.JTermiosImpl;
/*     */ import jtermios.windows.JTermiosImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JTermios
/*     */ {
/*  74 */   public static int FIONREAD = 1074030207;
/*     */   
/*  76 */   public static int O_RDWR = 2;
/*  77 */   public static int O_NONBLOCK = 4;
/*  78 */   public static int O_NOCTTY = 131072;
/*  79 */   public static int O_NDELAY = 4;
/*  80 */   public static int O_CREAT = 512;
/*  81 */   public static int F_GETFL = 3;
/*  82 */   public static int F_SETFL = 4;
/*     */   
/*  84 */   public static int EAGAIN = 35;
/*  85 */   public static int EBADF = 9;
/*  86 */   public static int EACCES = 22;
/*  87 */   public static int EEXIST = 17;
/*  88 */   public static int EINTR = 4;
/*  89 */   public static int EINVAL = 22;
/*  90 */   public static int EIO = 5;
/*  91 */   public static int EISDIR = 21;
/*  92 */   public static int ELOOP = 62;
/*  93 */   public static int EMFILE = 24;
/*  94 */   public static int ENAMETOOLONG = 63;
/*  95 */   public static int ENFILE = 23;
/*  96 */   public static int ENOENT = 2;
/*  97 */   public static int ENOSR = 98;
/*  98 */   public static int ENOSPC = 28;
/*  99 */   public static int ENOTDIR = 20;
/* 100 */   public static int ENXIO = 6;
/* 101 */   public static int EOVERFLOW = 84;
/* 102 */   public static int EROFS = 30;
/* 103 */   public static int ENOTSUP = 45;
/* 104 */   public static int EBUSY = 16;
/*     */   
/* 106 */   public static int TIOCM_RNG = 128;
/* 107 */   public static int TIOCM_CAR = 64;
/* 108 */   public static int IGNBRK = 1;
/* 109 */   public static int BRKINT = 2;
/* 110 */   public static int IGNPAR = 4;
/* 111 */   public static int PARMRK = 8;
/* 112 */   public static int INLCR = 64;
/* 113 */   public static int IGNCR = 128;
/* 114 */   public static int ICRNL = 256;
/* 115 */   public static int ECHONL = 16;
/* 116 */   public static int IEXTEN = 1024;
/* 117 */   public static int CLOCAL = 32768;
/* 118 */   public static int OPOST = 1;
/* 119 */   public static int VSTART = 12;
/* 120 */   public static int TCSANOW = 0;
/* 121 */   public static int VSTOP = 13;
/* 122 */   public static int VMIN = 16;
/* 123 */   public static int VTIME = 17;
/* 124 */   public static int VEOF = 0;
/* 125 */   public static int TIOCMGET = 1074033770;
/* 126 */   public static int TIOCM_CTS = 32;
/* 127 */   public static int TIOCM_DSR = 256;
/* 128 */   public static int TIOCM_RI = 128;
/* 129 */   public static int TIOCM_CD = 64;
/* 130 */   public static int TIOCM_DTR = 2;
/* 131 */   public static int TIOCM_RTS = 4;
/* 132 */   public static int ICANON = 256;
/* 133 */   public static int ECHO = 8;
/* 134 */   public static int ECHOE = 2;
/* 135 */   public static int ISIG = 128;
/* 136 */   public static int TIOCMSET = -2147191699;
/* 137 */   public static int IXON = 512;
/* 138 */   public static int IXOFF = 1024;
/* 139 */   public static int IXANY = 2048;
/* 140 */   public static int CRTSCTS = 196608;
/* 141 */   public static int TCSADRAIN = 1;
/* 142 */   public static int INPCK = 16;
/* 143 */   public static int ISTRIP = 32;
/* 144 */   public static int CSIZE = 768;
/* 145 */   public static int TCIFLUSH = 1;
/* 146 */   public static int TCOFLUSH = 2;
/* 147 */   public static int TCIOFLUSH = 3;
/* 148 */   public static int CS5 = 0;
/* 149 */   public static int CS6 = 256;
/* 150 */   public static int CS7 = 512;
/* 151 */   public static int CS8 = 768;
/* 152 */   public static int CSTOPB = 1024;
/* 153 */   public static int CREAD = 2048;
/* 154 */   public static int PARENB = 4096;
/* 155 */   public static int PARODD = 8192;
/* 156 */   public static int CMSPAR = 1073741824;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 162 */   public static int B0 = 0;
/* 163 */   public static int B50 = 50;
/* 164 */   public static int B75 = 75;
/* 165 */   public static int B110 = 110;
/* 166 */   public static int B134 = 134;
/* 167 */   public static int B150 = 150;
/* 168 */   public static int B200 = 200;
/* 169 */   public static int B300 = 300;
/* 170 */   public static int B600 = 600;
/* 171 */   public static int B1200 = 1200;
/* 172 */   public static int B1800 = 1800;
/* 173 */   public static int B2400 = 2400;
/* 174 */   public static int B4800 = 4800;
/* 175 */   public static int B9600 = 9600;
/* 176 */   public static int B19200 = 19200;
/* 177 */   public static int B38400 = 38400;
/* 178 */   public static int B7200 = 7200;
/* 179 */   public static int B14400 = 14400;
/* 180 */   public static int B28800 = 28800;
/* 181 */   public static int B57600 = 57600;
/* 182 */   public static int B76800 = 76800;
/* 183 */   public static int B115200 = 115200;
/* 184 */   public static int B230400 = 230400;
/*     */   
/* 186 */   public static short POLLIN = 1;
/* 187 */   public static int POLLIN_IN = 1;
/* 188 */   public static int POLLIN_OUT = 1;
/*     */ 
/*     */   
/* 191 */   public static short POLLPRI = 2;
/* 192 */   public static short POLLOUT = 4;
/* 193 */   public static int POLLOUT_IN = 4;
/* 194 */   public static int POLLOUT_OUT = 4;
/*     */ 
/*     */   
/* 197 */   public static short POLLERR = 8;
/* 198 */   public static short POLLERR_OUT = 8;
/* 199 */   public static short POLLNVAL = 32;
/* 200 */   public static int POLLNVAL_OUT = 32;
/*     */ 
/*     */   
/* 203 */   public static int DC1 = 17;
/* 204 */   public static int DC3 = 19;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static JTermiosInterface m_Termios;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown() {
/* 278 */     if (m_Termios != null)
/* 279 */       m_Termios.shutDown(); 
/*     */   }
/*     */   
/*     */   static {
/* 283 */     if (Platform.isMac()) {
/* 284 */       m_Termios = (JTermiosInterface)new JTermiosImpl();
/* 285 */     } else if (Platform.isWindows()) {
/* 286 */       m_Termios = (JTermiosInterface)new JTermiosImpl();
/* 287 */     } else if (Platform.isLinux()) {
/* 288 */       m_Termios = (JTermiosInterface)new JTermiosImpl();
/* 289 */     } else if (Platform.isSolaris()) {
/* 290 */       m_Termios = (JTermiosInterface)new JTermiosImpl();
/* 291 */     } else if (Platform.isFreeBSD()) {
/* 292 */       m_Termios = (JTermiosInterface)new JTermiosImpl();
/*     */     } else {
/* 294 */       JTermiosLogging.log(0, "JTermios has no support for OS %s\n", new Object[] { System.getProperty("os.name") });
/*     */     } 
/*     */   }
/*     */   
/*     */   public static int errno() {
/* 299 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> errno()\n", new Object[0]));
/* 300 */     int i = m_Termios.errno();
/* 301 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< errno() => %d\n", new Object[] { Integer.valueOf(i) }));
/* 302 */     return i;
/*     */   }
/*     */   
/*     */   public static int fcntl(int paramInt1, int paramInt2, int paramInt3) {
/* 306 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> fcntl(%d, %d, %d)\n", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(paramInt3) }));
/* 307 */     int i = m_Termios.fcntl(paramInt1, paramInt2, paramInt3);
/* 308 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< fcntl(%d, %d, %d) => %d\n", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), Integer.valueOf(i) }));
/* 309 */     return i;
/*     */   }
/*     */   
/*     */   public static int cfgetispeed(Termios paramTermios) {
/* 313 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> cfgetispeed(%s)\n", new Object[] { paramTermios }));
/* 314 */     int i = m_Termios.cfgetispeed(paramTermios);
/* 315 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< cfgetispeed(%s) => %d\n", new Object[] { paramTermios, Integer.valueOf(i) }));
/* 316 */     return i;
/*     */   }
/*     */   
/*     */   public static int cfgetospeed(Termios paramTermios) {
/* 320 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> cfgetospeed(%s)\n", new Object[] { paramTermios }));
/* 321 */     int i = m_Termios.cfgetospeed(paramTermios);
/* 322 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< cfgetospeed(%s) => %d\n", new Object[] { paramTermios, Integer.valueOf(i) }));
/* 323 */     return i;
/*     */   }
/*     */   
/*     */   public static int cfsetispeed(Termios paramTermios, int paramInt) {
/* 327 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> cfgetospeed(%s,%d)\n", new Object[] { paramTermios, Integer.valueOf(paramInt) }));
/* 328 */     int i = m_Termios.cfsetispeed(paramTermios, paramInt);
/* 329 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< cfgetospeed(%s,%d) => %d\n", new Object[] { paramTermios, Integer.valueOf(paramInt), Integer.valueOf(i) }));
/* 330 */     return i;
/*     */   }
/*     */   
/*     */   public static int cfsetospeed(Termios paramTermios, int paramInt) {
/* 334 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> cfgetospeed(%s,%d)\n", new Object[] { paramTermios, Integer.valueOf(paramInt) }));
/* 335 */     int i = m_Termios.cfsetospeed(paramTermios, paramInt);
/* 336 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< cfgetospeed(%s,%d) => %d\n", new Object[] { paramTermios, Integer.valueOf(paramInt), Integer.valueOf(i) }));
/* 337 */     return i;
/*     */   }
/*     */   
/*     */   public static int setspeed(int paramInt1, Termios paramTermios, int paramInt2) {
/* 341 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> setspeed(%d,%s,%d)\n", new Object[] { Integer.valueOf(paramInt1), paramTermios, Integer.valueOf(paramInt2) }));
/* 342 */     int i = m_Termios.setspeed(paramInt1, paramTermios, paramInt2);
/* 343 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< setspeed(%d,%s,%d) => %d\n", new Object[] { Integer.valueOf(paramInt1), paramTermios, Integer.valueOf(paramInt2), Integer.valueOf(i) }));
/* 344 */     return i;
/*     */   }
/*     */   
/*     */   public static int tcflush(int paramInt1, int paramInt2) {
/* 348 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> tcflush(%d,%d)\n", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }));
/* 349 */     int i = m_Termios.tcflush(paramInt1, paramInt2);
/* 350 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< tcflush(%d,%d) => %d\n", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(i) }));
/* 351 */     return i;
/*     */   }
/*     */   
/*     */   public static int tcdrain(int paramInt) {
/* 355 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> tcdrain(%d)\n", new Object[] { Integer.valueOf(paramInt) }));
/* 356 */     int i = m_Termios.tcdrain(paramInt);
/* 357 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< tcdrain(%d) => %d\n", new Object[] { Integer.valueOf(paramInt), Integer.valueOf(i) }));
/* 358 */     return i;
/*     */   }
/*     */   
/*     */   public static void cfmakeraw(int paramInt, Termios paramTermios) {
/* 362 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> cfmakeraw(%d,%s)\n", new Object[] { Integer.valueOf(paramInt), paramTermios }));
/* 363 */     m_Termios.cfmakeraw(paramTermios);
/* 364 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< cfmakeraw(%d,%s)\n", new Object[] { Integer.valueOf(paramInt), paramTermios }));
/*     */   }
/*     */   
/*     */   public static int tcgetattr(int paramInt, Termios paramTermios) {
/* 368 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> tcgetattr(%d,%s)\n", new Object[] { Integer.valueOf(paramInt), paramTermios }));
/* 369 */     int i = m_Termios.tcgetattr(paramInt, paramTermios);
/* 370 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< tcgetattr(%d,%s) => %d\n", new Object[] { Integer.valueOf(paramInt), paramTermios, Integer.valueOf(i) }));
/* 371 */     return i;
/*     */   }
/*     */   
/*     */   public static int tcsetattr(int paramInt1, int paramInt2, Termios paramTermios) {
/* 375 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> tcsetattr(%d,%d,%s)\n", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), paramTermios }));
/* 376 */     int i = m_Termios.tcsetattr(paramInt1, paramInt2, paramTermios);
/* 377 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< tcsetattr(%d,%d,%s) => %d\n", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), paramTermios, Integer.valueOf(i) }));
/* 378 */     return i;
/*     */   }
/*     */   
/*     */   public static int tcsendbreak(int paramInt1, int paramInt2) {
/* 382 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> tcsendbreak(%d,%d,%s)\n", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }));
/* 383 */     int i = m_Termios.tcsendbreak(paramInt1, paramInt2);
/* 384 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< tcsendbreak(%d,%d,%s) => %d\n", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(i) }));
/* 385 */     return i;
/*     */   }
/*     */   
/*     */   public static int open(String paramString, int paramInt) {
/* 389 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> open('%s',%08X)\n", new Object[] { paramString, Integer.valueOf(paramInt) }));
/* 390 */     int i = m_Termios.open(paramString, paramInt);
/* 391 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< open('%s',%08X) => %d\n", new Object[] { paramString, Integer.valueOf(paramInt), Integer.valueOf(i) }));
/* 392 */     return i;
/*     */   }
/*     */   
/*     */   public static int close(int paramInt) {
/* 396 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> close(%d)\n", new Object[] { Integer.valueOf(paramInt) }));
/* 397 */     int i = m_Termios.close(paramInt);
/* 398 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< close(%d) => %d\n", new Object[] { Integer.valueOf(paramInt), Integer.valueOf(i) }));
/* 399 */     return i;
/*     */   }
/*     */   
/*     */   public static int write(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
/* 403 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> write(%d,%s,%d)\n", new Object[] { Integer.valueOf(paramInt1), JTermiosLogging.log(paramArrayOfbyte, 8), Integer.valueOf(paramInt2) }));
/* 404 */     int i = m_Termios.write(paramInt1, paramArrayOfbyte, paramInt2);
/* 405 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< write(%d,%s,%d) => %d\n", new Object[] { Integer.valueOf(paramInt1), JTermiosLogging.log(paramArrayOfbyte, 8), Integer.valueOf(paramInt2), Integer.valueOf(i) }));
/* 406 */     return i;
/*     */   }
/*     */   
/*     */   public static int read(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
/* 410 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> read(%d,%s,%d)\n", new Object[] { Integer.valueOf(paramInt1), JTermiosLogging.log(paramArrayOfbyte, 8), Integer.valueOf(paramInt2) }));
/* 411 */     int i = m_Termios.read(paramInt1, paramArrayOfbyte, paramInt2);
/* 412 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< read(%d,%s,%d) => %d\n", new Object[] { Integer.valueOf(paramInt1), JTermiosLogging.log(paramArrayOfbyte, 8), Integer.valueOf(paramInt2), Integer.valueOf(i) }));
/* 413 */     return i;
/*     */   }
/*     */   
/*     */   public static int ioctl(int paramInt1, int paramInt2, int[] paramArrayOfint) {
/* 417 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> ioctl(%d,%d,[%08X])\n", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(paramArrayOfint[0]) }));
/* 418 */     int i = m_Termios.ioctl(paramInt1, paramInt2, paramArrayOfint);
/* 419 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< ioctl(%d,%d,[%08X]) => %d\n", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(paramArrayOfint[0]), Integer.valueOf(i) }));
/* 420 */     return i;
/*     */   }
/*     */   
/*     */   private static String toString(int paramInt, FDSet paramFDSet) {
/* 424 */     StringBuffer stringBuffer = new StringBuffer("[");
/* 425 */     for (byte b = 0; b < paramInt; b++) {
/* 426 */       if (FD_ISSET(b, paramFDSet))
/* 427 */         stringBuffer.append(Integer.toString(b)); 
/* 428 */     }  stringBuffer.append("]");
/* 429 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int select(int paramInt, FDSet paramFDSet1, FDSet paramFDSet2, FDSet paramFDSet3, TimeVal paramTimeVal) {
/* 437 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> select(%d,%s,%s,%s,%s)\n", new Object[] { Integer.valueOf(paramInt), toString(paramInt, paramFDSet1), toString(paramInt, paramFDSet2), toString(paramInt, paramFDSet3), paramTimeVal }));
/* 438 */     int i = m_Termios.select(paramInt, paramFDSet1, paramFDSet2, paramFDSet3, paramTimeVal);
/* 439 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< select(%d,%s,%s,%s,%s) => %d\n", new Object[] { Integer.valueOf(paramInt), toString(paramInt, paramFDSet1), toString(paramInt, paramFDSet2), toString(paramInt, paramFDSet3), paramTimeVal, Integer.valueOf(i) }));
/* 440 */     return i;
/*     */   }
/*     */   
/*     */   public static int poll(Pollfd[] paramArrayOfPollfd, int paramInt1, int paramInt2) {
/* 444 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> poll(%s,%d,%d)\n", new Object[] { JTermiosLogging.log((Object[])paramArrayOfPollfd, 8), Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }));
/* 445 */     int i = m_Termios.poll(paramArrayOfPollfd, paramInt1, paramInt2);
/* 446 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< poll(%s,%d,%d) => %d\n", new Object[] { JTermiosLogging.log((Object[])paramArrayOfPollfd, 8), Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(i) }));
/* 447 */     return i;
/*     */   }
/*     */   
/*     */   public static int poll(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/* 451 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> poll(%s,%d,%d)\n", new Object[] { JTermiosLogging.log(paramArrayOfint, 8), Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }));
/* 452 */     int i = m_Termios.poll(paramArrayOfint, paramInt1, paramInt2);
/* 453 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< poll(%s,%d,%d) => %d\n", new Object[] { JTermiosLogging.log(paramArrayOfint, 8), Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(i) }));
/* 454 */     return i;
/*     */   }
/*     */   
/*     */   public static int pipe(int[] paramArrayOfint) {
/* 458 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(5, "> pipe([%d,%d,%d])\n", new Object[] { Integer.valueOf(paramArrayOfint.length), Integer.valueOf(paramArrayOfint[0]), Integer.valueOf(paramArrayOfint[1]) }));
/* 459 */     int i = m_Termios.pipe(paramArrayOfint);
/* 460 */     JTermiosLogging.log = (JTermiosLogging.log && JTermiosLogging.log(3, "< pipe([%d,%d,%d]) => %d\n", new Object[] { Integer.valueOf(paramArrayOfint.length), Integer.valueOf(paramArrayOfint[0]), Integer.valueOf(paramArrayOfint[1]), Integer.valueOf(i) }));
/* 461 */     return i;
/*     */   }
/*     */   
/*     */   public static void perror(String paramString) {
/* 465 */     m_Termios.perror(paramString);
/*     */   }
/*     */   
/*     */   public static FDSet newFDSet() {
/* 469 */     return m_Termios.newFDSet();
/*     */   }
/*     */   
/*     */   public static void FD_SET(int paramInt, FDSet paramFDSet) {
/* 473 */     m_Termios.FD_SET(paramInt, paramFDSet);
/*     */   }
/*     */   
/*     */   public static void FD_CLR(int paramInt, FDSet paramFDSet) {
/* 477 */     m_Termios.FD_CLR(paramInt, paramFDSet);
/*     */   }
/*     */   
/*     */   public static boolean FD_ISSET(int paramInt, FDSet paramFDSet) {
/* 481 */     return m_Termios.FD_ISSET(paramInt, paramFDSet);
/*     */   }
/*     */   
/*     */   public static void FD_ZERO(FDSet paramFDSet) {
/* 485 */     m_Termios.FD_ZERO(paramFDSet);
/*     */   }
/*     */   
/*     */   public static List<String> getPortList() {
/* 489 */     return m_Termios.getPortList();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Pattern getPortNamePattern(JTermiosInterface paramJTermiosInterface) {
/* 494 */     String str = System.getProperty("purejavacomm.portnamepattern." + paramJTermiosInterface.getClass().getName());
/* 495 */     if (str == null)
/* 496 */       str = System.getProperty("purejavacomm.portnamepattern"); 
/* 497 */     if (str == null)
/* 498 */       str = paramJTermiosInterface.getPortNamePattern(); 
/* 499 */     return Pattern.compile(str);
/*     */   }
/*     */   
/*     */   public static class JTermiosLogging {
/* 503 */     private static int LOG_MASK = 0;
/*     */     public static boolean log = false;
/*     */     
/*     */     static {
/* 507 */       String str = System.getProperty("purejavacomm.loglevel");
/* 508 */       if (str != null)
/* 509 */         setLogLevel(Integer.parseInt(str)); 
/*     */     }
/*     */     
/*     */     public static String lineno() {
/* 513 */       return lineno(0);
/*     */     }
/*     */     
/*     */     public static String lineno(int param1Int) {
/* 517 */       StackTraceElement stackTraceElement = Thread.currentThread().getStackTrace()[2 + param1Int];
/* 518 */       return String.format("class %s line% d", new Object[] { stackTraceElement.getClassName(), Integer.valueOf(stackTraceElement.getLineNumber()) });
/*     */     }
/*     */     
/*     */     public static String ref(Structure param1Structure) {
/* 522 */       if (param1Structure == null) {
/* 523 */         return "null";
/*     */       }
/* 525 */       return param1Structure.getPointer().toString();
/*     */     }
/*     */     
/*     */     public static String log(byte[] param1ArrayOfbyte, int param1Int) {
/* 529 */       StringBuffer stringBuffer = new StringBuffer();
/* 530 */       if (param1Int < 0 || param1Int > param1ArrayOfbyte.length)
/* 531 */         param1Int = param1ArrayOfbyte.length; 
/* 532 */       stringBuffer.append(String.format("[%d", new Object[] { Integer.valueOf(param1ArrayOfbyte.length) }));
/* 533 */       for (byte b = 0; b < param1Int; b++) {
/* 534 */         stringBuffer.append(String.format(",0x%02X", new Object[] { Byte.valueOf(param1ArrayOfbyte[b]) }));
/* 535 */       }  if (param1Int < param1ArrayOfbyte.length)
/* 536 */         stringBuffer.append("..."); 
/* 537 */       stringBuffer.append("]");
/* 538 */       return stringBuffer.toString();
/*     */     }
/*     */     
/*     */     public static String log(int[] param1ArrayOfint, int param1Int) {
/* 542 */       StringBuffer stringBuffer = new StringBuffer();
/* 543 */       if (param1Int < 0 || param1Int > param1ArrayOfint.length)
/* 544 */         param1Int = param1ArrayOfint.length; 
/* 545 */       stringBuffer.append(String.format("[%d", new Object[] { Integer.valueOf(param1ArrayOfint.length) }));
/* 546 */       for (byte b = 0; b < param1Int; b++) {
/* 547 */         stringBuffer.append(String.format(",0x%08X", new Object[] { Integer.valueOf(param1ArrayOfint[b]) }));
/* 548 */       }  if (param1Int < param1ArrayOfint.length)
/* 549 */         stringBuffer.append("..."); 
/* 550 */       stringBuffer.append("]");
/* 551 */       return stringBuffer.toString();
/*     */     }
/*     */     
/*     */     public static String log(char[] param1ArrayOfchar, int param1Int) {
/* 555 */       StringBuffer stringBuffer = new StringBuffer();
/* 556 */       if (param1Int < 0 || param1Int > param1ArrayOfchar.length)
/* 557 */         param1Int = param1ArrayOfchar.length; 
/* 558 */       stringBuffer.append(String.format("[%d", new Object[] { Integer.valueOf(param1ArrayOfchar.length) }));
/* 559 */       for (byte b = 0; b < param1Int; b++) {
/* 560 */         stringBuffer.append(String.format(",%c", new Object[] { Character.valueOf(param1ArrayOfchar[b]) }));
/* 561 */       }  if (param1Int < param1ArrayOfchar.length)
/* 562 */         stringBuffer.append("..."); 
/* 563 */       stringBuffer.append("]");
/* 564 */       return stringBuffer.toString();
/*     */     }
/*     */     
/*     */     public static String log(Object[] param1ArrayOfObject, int param1Int) {
/* 568 */       StringBuffer stringBuffer = new StringBuffer();
/* 569 */       if (param1Int < 0 || param1Int > param1ArrayOfObject.length)
/* 570 */         param1Int = param1ArrayOfObject.length; 
/* 571 */       stringBuffer.append(String.format("[%d", new Object[] { Integer.valueOf(param1ArrayOfObject.length) }));
/* 572 */       for (byte b = 0; b < param1Int; b++) {
/* 573 */         stringBuffer.append(",");
/* 574 */         stringBuffer.append((param1ArrayOfObject[b] != null) ? param1ArrayOfObject[b].toString() : "null");
/*     */       } 
/* 576 */       if (param1Int < param1ArrayOfObject.length)
/* 577 */         stringBuffer.append("..."); 
/* 578 */       stringBuffer.append("]");
/* 579 */       return stringBuffer.toString();
/*     */     }
/*     */     
/* 582 */     private static StringBuffer buffer = new StringBuffer();
/*     */     
/*     */     public static boolean log(int param1Int, String param1String, Object... param1VarArgs) {
/* 585 */       if (param1Int == 0 || LOG_MASK != 0) {
/* 586 */         synchronized (buffer) {
/* 587 */           buffer.setLength(0);
/* 588 */           if ((LOG_MASK & 0x20) != 0)
/* 589 */             buffer.append(String.format("%06d,", new Object[] { Long.valueOf(System.currentTimeMillis() % 1000000L) })); 
/* 590 */           if ((LOG_MASK & 0x40) != 0) {
/* 591 */             buffer.append(lineno(2));
/* 592 */             buffer.append(", ");
/*     */           } 
/* 594 */           if ((LOG_MASK & 0x80) != 0) {
/* 595 */             buffer.append("thread id ");
/* 596 */             buffer.append(Thread.currentThread().getId());
/* 597 */             buffer.append(", ");
/* 598 */             buffer.append(Thread.currentThread().getName());
/* 599 */             buffer.append(", ");
/*     */           } 
/* 601 */           if (param1Int == 0 || (LOG_MASK & 1 << param1Int - 1) != 0)
/* 602 */             buffer.append(String.format(param1String, param1VarArgs)); 
/* 603 */           if (buffer.length() > 0) {
/* 604 */             System.err.printf("log: " + buffer.toString(), new Object[0]);
/*     */           }
/*     */         } 
/*     */       }
/* 608 */       return true;
/*     */     }
/*     */     
/*     */     public static void setLogLevel(int param1Int) {
/* 612 */       LOG_MASK = 0;
/* 613 */       for (byte b = 0; b < param1Int; b++) {
/* 614 */         LOG_MASK = (LOG_MASK << 1) + 1;
/*     */       }
/* 616 */       log = (LOG_MASK != 0);
/*     */     }
/*     */     
/*     */     public static void setLogMask(int param1Int) {
/* 620 */       LOG_MASK = param1Int;
/* 621 */       log = (LOG_MASK != 0);
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface JTermiosInterface {
/*     */     int pipe(int[] param1ArrayOfint);
/*     */     
/*     */     void shutDown();
/*     */     
/*     */     int errno();
/*     */     
/*     */     int fcntl(int param1Int1, int param1Int2, int param1Int3);
/*     */     
/*     */     int setspeed(int param1Int1, Termios param1Termios, int param1Int2);
/*     */     
/*     */     int cfgetispeed(Termios param1Termios);
/*     */     
/*     */     int cfgetospeed(Termios param1Termios);
/*     */     
/*     */     int cfsetispeed(Termios param1Termios, int param1Int);
/*     */     
/*     */     int cfsetospeed(Termios param1Termios, int param1Int);
/*     */     
/*     */     int tcflush(int param1Int1, int param1Int2);
/*     */     
/*     */     int tcdrain(int param1Int);
/*     */     
/*     */     void cfmakeraw(Termios param1Termios);
/*     */     
/*     */     int tcgetattr(int param1Int, Termios param1Termios);
/*     */     
/*     */     int tcsetattr(int param1Int1, int param1Int2, Termios param1Termios);
/*     */     
/*     */     int tcsendbreak(int param1Int1, int param1Int2);
/*     */     
/*     */     int open(String param1String, int param1Int);
/*     */     
/*     */     int close(int param1Int);
/*     */     
/*     */     int write(int param1Int1, byte[] param1ArrayOfbyte, int param1Int2);
/*     */     
/*     */     int read(int param1Int1, byte[] param1ArrayOfbyte, int param1Int2);
/*     */     
/*     */     int ioctl(int param1Int1, int param1Int2, int[] param1ArrayOfint);
/*     */     
/*     */     int select(int param1Int, FDSet param1FDSet1, FDSet param1FDSet2, FDSet param1FDSet3, TimeVal param1TimeVal);
/*     */     
/*     */     int poll(Pollfd[] param1ArrayOfPollfd, int param1Int1, int param1Int2);
/*     */     
/*     */     int poll(int[] param1ArrayOfint, int param1Int1, int param1Int2);
/*     */     
/*     */     void perror(String param1String);
/*     */     
/*     */     FDSet newFDSet();
/*     */     
/*     */     void FD_SET(int param1Int, FDSet param1FDSet);
/*     */     
/*     */     void FD_CLR(int param1Int, FDSet param1FDSet);
/*     */     
/*     */     boolean FD_ISSET(int param1Int, FDSet param1FDSet);
/*     */     
/*     */     void FD_ZERO(FDSet param1FDSet);
/*     */     
/*     */     List<String> getPortList();
/*     */     
/*     */     String getPortNamePattern();
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\jtermios\JTermios.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */