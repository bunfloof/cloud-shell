/*    */ package jtermios;
/*    */ 
/*    */ import com.sun.jna.FunctionMapper;
/*    */ import com.sun.jna.NativeLibrary;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class YJPFunctionMapper
/*    */   implements FunctionMapper
/*    */ {
/* 20 */   public static final Map OPTIONS = new HashMap<Object, Object>();
/*    */   
/*    */   static {
/* 23 */     OPTIONS.put("function-mapper", new YJPFunctionMapper());
/*    */   }
/*    */ 
/*    */   
/*    */   private static final String YJP_PREFIX = "$$YJP$$";
/*    */   
/*    */   public String getFunctionName(NativeLibrary paramNativeLibrary, Method paramMethod) {
/* 30 */     if (paramMethod.getName().startsWith("$$YJP$$")) {
/* 31 */       return paramMethod.getName().substring("$$YJP$$".length());
/*    */     }
/* 33 */     return paramMethod.getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\jtermios\YJPFunctionMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */