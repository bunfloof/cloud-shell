/*     */ package jtermios.solaris;
/*     */ 
/*     */ import com.sun.jna.Library;
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.NativeLong;
/*     */ import com.sun.jna.Structure;
/*     */ import java.io.File;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import jtermios.FDSet;
/*     */ import jtermios.JTermios;
/*     */ import jtermios.Pollfd;
/*     */ import jtermios.Termios;
/*     */ import jtermios.TimeVal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JTermiosImpl
/*     */   implements JTermios.JTermiosInterface
/*     */ {
/*  62 */   private static String DEVICE_DIR_PATH = "/dev/term/";
/*  63 */   static Solaris_C_lib m_Clib = (Solaris_C_lib)Native.loadLibrary("c", Solaris_C_lib.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class timeval
/*     */     extends Structure
/*     */   {
/*     */     public NativeLong tv_sec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public NativeLong tv_usec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected List getFieldOrder() {
/* 115 */       return Arrays.asList(new String[] { "tv_sec", "tv_usec" });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public timeval(TimeVal param1TimeVal) {
/* 122 */       this.tv_sec = new NativeLong(param1TimeVal.tv_sec);
/* 123 */       this.tv_usec = new NativeLong(param1TimeVal.tv_usec);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class pollfd
/*     */     extends Structure
/*     */   {
/*     */     public int fd;
/*     */     public short events;
/*     */     public short revents;
/*     */     
/*     */     protected List getFieldOrder() {
/* 135 */       return Arrays.asList(new String[] { "fd", "events", "revents" });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public pollfd(Pollfd param1Pollfd)
/*     */     {
/* 143 */       this.fd = param1Pollfd.fd;
/* 144 */       this.events = param1Pollfd.events;
/* 145 */       this.revents = param1Pollfd.revents; } } public static interface Solaris_C_lib extends Library { int pipe(int[] param1ArrayOfint); int tcdrain(int param1Int); int fcntl(int param1Int1, int param1Int2, int[] param1ArrayOfint); int fcntl(int param1Int1, int param1Int2, int param1Int3); int ioctl(int param1Int1, int param1Int2, int[] param1ArrayOfint); int open(String param1String, int param1Int); int close(int param1Int); int tcgetattr(int param1Int, termios param1termios); int tcsetattr(int param1Int1, int param1Int2, termios param1termios); int cfsetispeed(termios param1termios, NativeLong param1NativeLong); int cfsetospeed(termios param1termios, NativeLong param1NativeLong); NativeLong cfgetispeed(termios param1termios); NativeLong cfgetospeed(termios param1termios); NativeLong write(int param1Int, ByteBuffer param1ByteBuffer, NativeLong param1NativeLong); NativeLong read(int param1Int, ByteBuffer param1ByteBuffer, NativeLong param1NativeLong); int select(int param1Int, int[] param1ArrayOfint1, int[] param1ArrayOfint2, int[] param1ArrayOfint3, timeval param1timeval); int poll(pollfd[] param1ArrayOfpollfd, int param1Int1, int param1Int2); int poll(int[] param1ArrayOfint, int param1Int1, int param1Int2); int tcflush(int param1Int1, int param1Int2); void perror(String param1String); int tcsendbreak(int param1Int1, int param1Int2); public static class timeval extends Structure { public NativeLong tv_sec; public NativeLong tv_usec; protected List getFieldOrder() { return Arrays.asList(new String[] { "tv_sec", "tv_usec" }); } public timeval(TimeVal param2TimeVal) { this.tv_sec = new NativeLong(param2TimeVal.tv_sec); this.tv_usec = new NativeLong(param2TimeVal.tv_usec); } } public static class pollfd extends Structure { public int fd; public pollfd(Pollfd param2Pollfd) { this.fd = param2Pollfd.fd; this.events = param2Pollfd.events; this.revents = param2Pollfd.revents; }
/*     */       
/*     */       public short events; public short revents;
/*     */       protected List getFieldOrder() {
/*     */         return Arrays.asList(new String[] { "fd", "events", "revents" });
/*     */       } }
/*     */     public static class termios extends Structure { public int c_iflag;
/*     */       public int c_oflag;
/*     */       public int c_cflag;
/*     */       public int c_lflag;
/* 155 */       public byte[] c_cc = new byte[32];
/*     */ 
/*     */       
/*     */       protected List getFieldOrder() {
/* 159 */         return Arrays.asList(new String[] { "c_iflag", "c_oflag", "c_cflag", "c_lflag", "c_cc" });
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public termios() {}
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public termios(Termios param2Termios) {
/* 172 */         this.c_iflag = param2Termios.c_iflag;
/* 173 */         this.c_oflag = param2Termios.c_oflag;
/* 174 */         this.c_cflag = param2Termios.c_cflag;
/* 175 */         this.c_lflag = param2Termios.c_lflag;
/* 176 */         System.arraycopy(param2Termios.c_cc, 0, this.c_cc, 0, param2Termios.c_cc.length);
/*     */       }
/*     */       
/*     */       public void update(Termios param2Termios) {
/* 180 */         param2Termios.c_iflag = this.c_iflag;
/* 181 */         param2Termios.c_oflag = this.c_oflag;
/* 182 */         param2Termios.c_cflag = this.c_cflag;
/* 183 */         param2Termios.c_lflag = this.c_lflag;
/* 184 */         System.arraycopy(this.c_cc, 0, param2Termios.c_cc, 0, param2Termios.c_cc.length); } } } public static class termios extends Structure { public int c_iflag; public int c_oflag; public int c_cflag; public int c_lflag; public byte[] c_cc = new byte[32]; protected List getFieldOrder() { return Arrays.asList(new String[] { "c_iflag", "c_oflag", "c_cflag", "c_lflag", "c_cc" }); } public termios() {} public termios(Termios param1Termios) { this.c_iflag = param1Termios.c_iflag; this.c_oflag = param1Termios.c_oflag; this.c_cflag = param1Termios.c_cflag; this.c_lflag = param1Termios.c_lflag; System.arraycopy(param1Termios.c_cc, 0, this.c_cc, 0, param1Termios.c_cc.length); } public void update(Termios param1Termios) { param1Termios.c_iflag = this.c_iflag; param1Termios.c_oflag = this.c_oflag; param1Termios.c_cflag = this.c_cflag; param1Termios.c_lflag = this.c_lflag; System.arraycopy(this.c_cc, 0, param1Termios.c_cc, 0, param1Termios.c_cc.length); }
/*     */      }
/*     */ 
/*     */   
/*     */   private static class FDSetImpl
/*     */     extends FDSet
/*     */   {
/*     */     static final int FD_SET_SIZE = 1024;
/*     */     static final int NFBBITS = 32;
/* 193 */     int[] bits = new int[32];
/*     */     
/*     */     public String toString() {
/* 196 */       return String.format("%08X%08X", new Object[] { Integer.valueOf(this.bits[0]), Integer.valueOf(this.bits[1]) });
/*     */     }
/*     */     private FDSetImpl() {} }
/*     */   
/*     */   public JTermiosImpl() {
/* 201 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "instantiating %s\n", new Object[] { getClass().getCanonicalName() }));
/*     */ 
/*     */     
/* 204 */     JTermios.FIONREAD = 1074030207;
/*     */ 
/*     */     
/* 207 */     JTermios.O_RDWR = 2;
/* 208 */     JTermios.O_NONBLOCK = 128;
/* 209 */     JTermios.O_NOCTTY = 2048;
/* 210 */     JTermios.O_NDELAY = 4;
/* 211 */     JTermios.F_GETFL = 3;
/* 212 */     JTermios.F_SETFL = 4;
/*     */ 
/*     */     
/* 215 */     JTermios.EAGAIN = 11;
/* 216 */     JTermios.EBADF = 9;
/* 217 */     JTermios.EACCES = 22;
/* 218 */     JTermios.EEXIST = 17;
/* 219 */     JTermios.EINTR = 4;
/* 220 */     JTermios.EINVAL = 22;
/* 221 */     JTermios.EIO = 5;
/* 222 */     JTermios.EISDIR = 21;
/* 223 */     JTermios.ELOOP = 90;
/* 224 */     JTermios.EMFILE = 24;
/* 225 */     JTermios.ENAMETOOLONG = 78;
/* 226 */     JTermios.ENFILE = 23;
/* 227 */     JTermios.ENOENT = 2;
/* 228 */     JTermios.ENOSR = 63;
/* 229 */     JTermios.ENOSPC = 28;
/* 230 */     JTermios.ENOTDIR = 20;
/* 231 */     JTermios.ENXIO = 6;
/* 232 */     JTermios.EOVERFLOW = 79;
/* 233 */     JTermios.EROFS = 30;
/* 234 */     JTermios.ENOTSUP = 48;
/*     */ 
/*     */     
/* 237 */     JTermios.TIOCM_RNG = 128;
/* 238 */     JTermios.TIOCM_CAR = 64;
/* 239 */     JTermios.IGNBRK = 1;
/* 240 */     JTermios.BRKINT = 2;
/* 241 */     JTermios.IGNPAR = 4;
/* 242 */     JTermios.PARMRK = 8;
/* 243 */     JTermios.INLCR = 64;
/* 244 */     JTermios.IGNCR = 128;
/* 245 */     JTermios.ICRNL = 256;
/* 246 */     JTermios.ECHONL = 64;
/* 247 */     JTermios.IEXTEN = 32768;
/* 248 */     JTermios.CLOCAL = 2048;
/* 249 */     JTermios.OPOST = 1;
/* 250 */     JTermios.VSTART = 8;
/* 251 */     JTermios.TCSANOW = 21518;
/* 252 */     JTermios.VSTOP = 9;
/* 253 */     JTermios.VMIN = 4;
/* 254 */     JTermios.VTIME = 5;
/* 255 */     JTermios.VEOF = 4;
/* 256 */     JTermios.TIOCMGET = 29725;
/* 257 */     JTermios.TIOCM_CTS = 32;
/* 258 */     JTermios.TIOCM_DSR = 256;
/* 259 */     JTermios.TIOCM_RI = 128;
/* 260 */     JTermios.TIOCM_CD = 64;
/* 261 */     JTermios.TIOCM_DTR = 2;
/* 262 */     JTermios.TIOCM_RTS = 4;
/* 263 */     JTermios.ICANON = 2;
/* 264 */     JTermios.ECHO = 8;
/* 265 */     JTermios.ECHOE = 16;
/* 266 */     JTermios.ISIG = 1;
/* 267 */     JTermios.TIOCMSET = 29722;
/* 268 */     JTermios.IXON = 1024;
/* 269 */     JTermios.IXOFF = 4096;
/* 270 */     JTermios.IXANY = 2048;
/* 271 */     JTermios.CRTSCTS = Integer.MIN_VALUE;
/* 272 */     JTermios.TCSADRAIN = 21519;
/* 273 */     JTermios.INPCK = 16;
/* 274 */     JTermios.ISTRIP = 32;
/* 275 */     JTermios.CSIZE = 48;
/* 276 */     JTermios.TCIFLUSH = 0;
/* 277 */     JTermios.TCOFLUSH = 1;
/* 278 */     JTermios.TCIOFLUSH = 2;
/* 279 */     JTermios.CS5 = 0;
/* 280 */     JTermios.CS6 = 16;
/* 281 */     JTermios.CS7 = 32;
/* 282 */     JTermios.CS8 = 48;
/* 283 */     JTermios.CSTOPB = 64;
/* 284 */     JTermios.CREAD = 128;
/* 285 */     JTermios.PARENB = 256;
/* 286 */     JTermios.PARODD = 512;
/* 287 */     JTermios.B0 = 0;
/* 288 */     JTermios.B50 = 1;
/* 289 */     JTermios.B75 = 2;
/* 290 */     JTermios.B110 = 3;
/* 291 */     JTermios.B134 = 4;
/* 292 */     JTermios.B150 = 5;
/* 293 */     JTermios.B200 = 6;
/* 294 */     JTermios.B300 = 7;
/* 295 */     JTermios.B600 = 8;
/* 296 */     JTermios.B1200 = 8;
/* 297 */     JTermios.B1800 = 10;
/* 298 */     JTermios.B2400 = 11;
/* 299 */     JTermios.B4800 = 12;
/* 300 */     JTermios.B9600 = 13;
/* 301 */     JTermios.B19200 = 14;
/* 302 */     JTermios.B38400 = 15;
/* 303 */     JTermios.B57600 = 16;
/* 304 */     JTermios.B76800 = 17;
/* 305 */     JTermios.B115200 = 18;
/* 306 */     JTermios.B230400 = 20;
/*     */ 
/*     */     
/* 309 */     JTermios.POLLIN = 1;
/* 310 */     JTermios.POLLPRI = 2;
/* 311 */     JTermios.POLLOUT = 4;
/* 312 */     JTermios.POLLERR = 8;
/* 313 */     JTermios.POLLNVAL = 32;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int errno() {
/* 320 */     return Native.getLastError();
/*     */   }
/*     */   
/*     */   public void cfmakeraw(Termios paramTermios) {
/* 324 */     Solaris_C_lib.termios termios = new Solaris_C_lib.termios(paramTermios);
/* 325 */     termios.c_iflag &= (JTermios.IGNBRK | JTermios.BRKINT | JTermios.PARMRK | JTermios.ISTRIP | JTermios.INLCR | JTermios.IGNCR | JTermios.ICRNL | JTermios.IXON) ^ 0xFFFFFFFF;
/* 326 */     termios.c_oflag &= JTermios.OPOST ^ 0xFFFFFFFF;
/* 327 */     termios.c_lflag &= (JTermios.ECHO | JTermios.ECHONL | JTermios.ICANON | JTermios.ISIG | JTermios.IEXTEN) ^ 0xFFFFFFFF;
/* 328 */     termios.c_cflag &= (JTermios.CSIZE | JTermios.PARENB) ^ 0xFFFFFFFF;
/* 329 */     termios.c_cflag |= JTermios.CS8;
/* 330 */     termios.update(paramTermios);
/*     */   }
/*     */   
/*     */   public int fcntl(int paramInt1, int paramInt2, int[] paramArrayOfint) {
/* 334 */     return m_Clib.fcntl(paramInt1, paramInt2, paramArrayOfint);
/*     */   }
/*     */   
/*     */   public int fcntl(int paramInt1, int paramInt2, int paramInt3) {
/* 338 */     return m_Clib.fcntl(paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   public int tcdrain(int paramInt) {
/* 342 */     return m_Clib.tcdrain(paramInt);
/*     */   }
/*     */   
/*     */   public int cfgetispeed(Termios paramTermios) {
/* 346 */     return m_Clib.cfgetispeed(new Solaris_C_lib.termios(paramTermios)).intValue();
/*     */   }
/*     */   
/*     */   public int cfgetospeed(Termios paramTermios) {
/* 350 */     return m_Clib.cfgetospeed(new Solaris_C_lib.termios(paramTermios)).intValue();
/*     */   }
/*     */   
/*     */   public int cfsetispeed(Termios paramTermios, int paramInt) {
/* 354 */     Solaris_C_lib.termios termios = new Solaris_C_lib.termios(paramTermios);
/* 355 */     int i = m_Clib.cfsetispeed(termios, new NativeLong(paramInt));
/* 356 */     termios.update(paramTermios);
/* 357 */     return i;
/*     */   }
/*     */   
/*     */   public int cfsetospeed(Termios paramTermios, int paramInt) {
/* 361 */     Solaris_C_lib.termios termios = new Solaris_C_lib.termios(paramTermios);
/* 362 */     int i = m_Clib.cfsetospeed(termios, new NativeLong(paramInt));
/* 363 */     termios.update(paramTermios);
/* 364 */     return i;
/*     */   }
/*     */   
/*     */   public int open(String paramString, int paramInt) {
/* 368 */     if (paramString != null && !paramString.startsWith("/")) {
/* 369 */       paramString = DEVICE_DIR_PATH + paramString;
/*     */     }
/* 371 */     return m_Clib.open(paramString, paramInt);
/*     */   }
/*     */   
/*     */   public int read(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
/* 375 */     return m_Clib.read(paramInt1, ByteBuffer.wrap(paramArrayOfbyte), new NativeLong(paramInt2)).intValue();
/*     */   }
/*     */   
/*     */   public int write(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
/* 379 */     return m_Clib.write(paramInt1, ByteBuffer.wrap(paramArrayOfbyte), new NativeLong(paramInt2)).intValue();
/*     */   }
/*     */   
/*     */   public int close(int paramInt) {
/* 383 */     return m_Clib.close(paramInt);
/*     */   }
/*     */   
/*     */   public int tcflush(int paramInt1, int paramInt2) {
/* 387 */     return m_Clib.tcflush(paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public int tcgetattr(int paramInt, Termios paramTermios) {
/* 391 */     Solaris_C_lib.termios termios = new Solaris_C_lib.termios();
/* 392 */     int i = m_Clib.tcgetattr(paramInt, termios);
/* 393 */     termios.update(paramTermios);
/* 394 */     return i;
/*     */   }
/*     */   
/*     */   public void perror(String paramString) {
/* 398 */     m_Clib.perror(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int tcsendbreak(int paramInt1, int paramInt2) {
/* 404 */     return m_Clib.tcsendbreak(paramInt1, paramInt2 / 250);
/*     */   }
/*     */   
/*     */   public int tcsetattr(int paramInt1, int paramInt2, Termios paramTermios) {
/* 408 */     return m_Clib.tcsetattr(paramInt1, paramInt2, new Solaris_C_lib.termios(paramTermios));
/*     */   }
/*     */   
/*     */   public void FD_CLR(int paramInt, FDSet paramFDSet) {
/* 412 */     if (paramFDSet == null) {
/*     */       return;
/*     */     }
/* 415 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/* 416 */     fDSetImpl.bits[paramInt / 32] = fDSetImpl.bits[paramInt / 32] & (1 << paramInt % 32 ^ 0xFFFFFFFF);
/*     */   }
/*     */   
/*     */   public boolean FD_ISSET(int paramInt, FDSet paramFDSet) {
/* 420 */     if (paramFDSet == null) {
/* 421 */       return false;
/*     */     }
/* 423 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/* 424 */     return ((fDSetImpl.bits[paramInt / 32] & 1 << paramInt % 32) != 0);
/*     */   }
/*     */   
/*     */   public void FD_SET(int paramInt, FDSet paramFDSet) {
/* 428 */     if (paramFDSet == null) {
/*     */       return;
/*     */     }
/* 431 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/* 432 */     fDSetImpl.bits[paramInt / 32] = fDSetImpl.bits[paramInt / 32] | 1 << paramInt % 32;
/*     */   }
/*     */   
/*     */   public void FD_ZERO(FDSet paramFDSet) {
/* 436 */     if (paramFDSet == null) {
/*     */       return;
/*     */     }
/* 439 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/* 440 */     Arrays.fill(fDSetImpl.bits, 0);
/*     */   }
/*     */   
/*     */   public int select(int paramInt, FDSet paramFDSet1, FDSet paramFDSet2, FDSet paramFDSet3, TimeVal paramTimeVal) {
/* 444 */     Solaris_C_lib.timeval timeval = null;
/* 445 */     if (paramTimeVal != null) {
/* 446 */       timeval = new Solaris_C_lib.timeval(paramTimeVal);
/*     */     }
/*     */     
/* 449 */     int[] arrayOfInt1 = (paramFDSet1 != null) ? ((FDSetImpl)paramFDSet1).bits : null;
/* 450 */     int[] arrayOfInt2 = (paramFDSet2 != null) ? ((FDSetImpl)paramFDSet2).bits : null;
/* 451 */     int[] arrayOfInt3 = (paramFDSet3 != null) ? ((FDSetImpl)paramFDSet3).bits : null;
/* 452 */     return m_Clib.select(paramInt, arrayOfInt1, arrayOfInt2, arrayOfInt3, timeval);
/*     */   }
/*     */   
/*     */   public int poll(Pollfd[] paramArrayOfPollfd, int paramInt1, int paramInt2) {
/* 456 */     Solaris_C_lib.pollfd[] arrayOfPollfd = new Solaris_C_lib.pollfd[paramArrayOfPollfd.length]; int i;
/* 457 */     for (i = 0; i < paramInt1; i++)
/* 458 */       arrayOfPollfd[i] = new Solaris_C_lib.pollfd(paramArrayOfPollfd[i]); 
/* 459 */     i = m_Clib.poll(arrayOfPollfd, paramInt1, paramInt2);
/* 460 */     for (byte b = 0; b < paramInt1; b++)
/* 461 */       (paramArrayOfPollfd[b]).revents = (arrayOfPollfd[b]).revents; 
/* 462 */     return i;
/*     */   }
/*     */   
/*     */   public int poll(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/* 466 */     return m_Clib.poll(paramArrayOfint, paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public FDSet newFDSet() {
/* 470 */     return new FDSetImpl();
/*     */   }
/*     */   
/*     */   public int ioctl(int paramInt1, int paramInt2, int[] paramArrayOfint) {
/* 474 */     return m_Clib.ioctl(paramInt1, paramInt2, paramArrayOfint);
/*     */   }
/*     */   
/*     */   public String getPortNamePattern() {
/* 478 */     return ".*";
/*     */   }
/*     */   
/*     */   public List<String> getPortList() {
/* 482 */     File file = new File(DEVICE_DIR_PATH);
/* 483 */     if (!file.isDirectory()) {
/* 484 */       JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "device directory %s does not exist\n", new Object[] { DEVICE_DIR_PATH }));
/* 485 */       return null;
/*     */     } 
/* 487 */     String[] arrayOfString = file.list();
/* 488 */     LinkedList<String> linkedList = new LinkedList();
/*     */     
/* 490 */     Pattern pattern = JTermios.getPortNamePattern(this);
/* 491 */     if (arrayOfString != null)
/* 492 */       for (byte b = 0; b < arrayOfString.length; b++) {
/* 493 */         String str = arrayOfString[b];
/* 494 */         if (pattern.matcher(str).matches()) {
/* 495 */           linkedList.add(str);
/*     */         }
/*     */       }  
/* 498 */     return linkedList;
/*     */   }
/*     */ 
/*     */   
/*     */   public void shutDown() {}
/*     */   
/*     */   public int setspeed(int paramInt1, Termios paramTermios, int paramInt2) {
/* 505 */     int i = paramInt2;
/* 506 */     switch (paramInt2) {
/*     */       case 50:
/* 508 */         i = JTermios.B50;
/*     */         break;
/*     */       case 75:
/* 511 */         i = JTermios.B75;
/*     */         break;
/*     */       case 110:
/* 514 */         i = JTermios.B110;
/*     */         break;
/*     */       case 134:
/* 517 */         i = JTermios.B134;
/*     */         break;
/*     */       case 150:
/* 520 */         i = JTermios.B150;
/*     */         break;
/*     */       case 200:
/* 523 */         i = JTermios.B200;
/*     */         break;
/*     */       case 300:
/* 526 */         i = JTermios.B300;
/*     */         break;
/*     */       case 600:
/* 529 */         i = JTermios.B600;
/*     */         break;
/*     */       case 1200:
/* 532 */         i = JTermios.B1200;
/*     */         break;
/*     */       case 1800:
/* 535 */         i = JTermios.B1800;
/*     */         break;
/*     */       case 2400:
/* 538 */         i = JTermios.B2400;
/*     */         break;
/*     */       case 4800:
/* 541 */         i = JTermios.B4800;
/*     */         break;
/*     */       case 9600:
/* 544 */         i = JTermios.B9600;
/*     */         break;
/*     */       case 19200:
/* 547 */         i = JTermios.B19200;
/*     */         break;
/*     */       case 38400:
/* 550 */         i = JTermios.B38400;
/*     */         break;
/*     */       case 7200:
/* 553 */         i = JTermios.B7200;
/*     */         break;
/*     */       case 14400:
/* 556 */         i = JTermios.B14400;
/*     */         break;
/*     */       case 28800:
/* 559 */         i = JTermios.B28800;
/*     */         break;
/*     */       case 57600:
/* 562 */         i = JTermios.B57600;
/*     */         break;
/*     */       case 76800:
/* 565 */         i = JTermios.B76800;
/*     */         break;
/*     */       case 115200:
/* 568 */         i = JTermios.B115200;
/*     */         break;
/*     */       case 230400:
/* 571 */         i = JTermios.B230400;
/*     */         break;
/*     */     } 
/*     */     int j;
/* 575 */     if ((j = cfsetispeed(paramTermios, i)) != 0)
/* 576 */       return j; 
/* 577 */     if ((j = cfsetospeed(paramTermios, i)) != 0)
/* 578 */       return j; 
/* 579 */     if ((j = tcsetattr(paramInt1, JTermios.TCSANOW, paramTermios)) != 0)
/* 580 */       return j; 
/* 581 */     return 0;
/*     */   }
/*     */   
/*     */   public int pipe(int[] paramArrayOfint) {
/* 585 */     return m_Clib.pipe(paramArrayOfint);
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\jtermios\solaris\JTermiosImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */