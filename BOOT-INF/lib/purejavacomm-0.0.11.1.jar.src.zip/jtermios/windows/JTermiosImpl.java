/*      */ package jtermios.windows;
/*      */ 
/*      */ import com.sun.jna.Memory;
/*      */ import com.sun.jna.Pointer;
/*      */ import com.sun.jna.WString;
/*      */ import com.sun.jna.ptr.IntByReference;
/*      */ import java.util.Arrays;
/*      */ import java.util.Hashtable;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.regex.Pattern;
/*      */ import jtermios.FDSet;
/*      */ import jtermios.JTermios;
/*      */ import jtermios.Pollfd;
/*      */ import jtermios.Termios;
/*      */ import jtermios.TimeVal;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JTermiosImpl
/*      */   implements JTermios.JTermiosInterface
/*      */ {
/*   50 */   private volatile int m_ErrNo = 0;
/*      */   
/*   52 */   private volatile boolean[] m_PortFDs = new boolean[256];
/*      */   
/*   54 */   private volatile Hashtable<Integer, Port> m_OpenPorts = new Hashtable<Integer, Port>();
/*      */   
/*      */   private class Port {
/*   57 */     volatile int m_FD = -1;
/*      */     volatile boolean m_Locked;
/*      */     volatile WinAPI.HANDLE m_Comm;
/*      */     volatile int m_OpenFlags;
/*   61 */     volatile WinAPI.DCB m_DCB = new WinAPI.DCB();
/*   62 */     volatile WinAPI.COMMTIMEOUTS m_Timeouts = new WinAPI.COMMTIMEOUTS();
/*   63 */     volatile WinAPI.COMSTAT m_COMSTAT = new WinAPI.COMSTAT();
/*   64 */     volatile int[] m_ClearErr = new int[] { 0 };
/*   65 */     volatile Memory m_RdBuffer = new Memory(2048L);
/*   66 */     volatile int[] m_RdErr = new int[] { 0 };
/*   67 */     volatile int[] m_RdN = new int[] { 0 };
/*   68 */     volatile WinAPI.OVERLAPPED m_RdOVL = new WinAPI.OVERLAPPED();
/*   69 */     volatile Memory m_WrBuffer = new Memory(2048L);
/*   70 */     volatile WinAPI.COMSTAT m_WrStat = new WinAPI.COMSTAT();
/*   71 */     volatile int[] m_WrErr = new int[] { 0 };
/*   72 */     volatile int[] m_WrN = new int[] { 0 };
/*      */     volatile int m_WritePending;
/*   74 */     volatile WinAPI.OVERLAPPED m_WrOVL = new WinAPI.OVERLAPPED();
/*   75 */     volatile int[] m_SelN = new int[] { 0 };
/*      */     volatile WinAPI.HANDLE m_CancelWaitSema4;
/*   77 */     volatile WinAPI.OVERLAPPED m_SelOVL = new WinAPI.OVERLAPPED();
/*   78 */     volatile IntByReference m_EventFlags = new IntByReference();
/*   79 */     volatile Termios m_Termios = new Termios();
/*      */     
/*      */     volatile int MSR;
/*   82 */     volatile int m_VTIME = -1;
/*   83 */     volatile int m_VMIN = -1;
/*   84 */     volatile int m_c_speed = -1;
/*   85 */     volatile int m_c_cflag = -1;
/*   86 */     volatile int m_c_iflag = -1;
/*   87 */     volatile int m_c_oflag = -1;
/*      */     
/*      */     public synchronized void fail() throws JTermiosImpl.Fail {
/*   90 */       int i = WinAPI.GetLastError();
/*   91 */       Memory memory = new Memory(2048L);
/*   92 */       int j = WinAPI.FormatMessageW(4608, null, i, WinAPI.MAKELANGID(0, 1), (Pointer)memory, (int)memory.size(), null);
/*      */       
/*   94 */       JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "fail() %s, Windows GetLastError()= %d, %s\n", new Object[] { JTermios.JTermiosLogging.lineno(1), Integer.valueOf(i), memory.getString(0L, true) }));
/*      */ 
/*      */ 
/*      */       
/*   98 */       JTermiosImpl.Fail fail = new JTermiosImpl.Fail();
/*   99 */       throw fail;
/*      */     }
/*      */     
/*      */     public synchronized void lock() throws InterruptedException {
/*  103 */       while (this.m_Locked)
/*  104 */         wait(); 
/*  105 */       this.m_Locked = true;
/*      */     }
/*      */     
/*      */     public synchronized void unlock() {
/*  109 */       if (!this.m_Locked)
/*  110 */         throw new IllegalArgumentException("Port was not locked"); 
/*  111 */       this.m_Locked = false;
/*  112 */       notifyAll();
/*      */     }
/*      */     
/*      */     public synchronized void waitUnlock() {
/*  116 */       while (this.m_Locked) {
/*      */         try {
/*  118 */           wait();
/*  119 */         } catch (InterruptedException interruptedException) {}
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Port() {
/*  126 */       synchronized (JTermiosImpl.this) {
/*  127 */         this.m_FD = -1;
/*  128 */         for (byte b = 0; b < JTermiosImpl.this.m_PortFDs.length; b++) {
/*  129 */           if (!JTermiosImpl.this.m_PortFDs[b]) {
/*  130 */             this.m_FD = b;
/*  131 */             JTermiosImpl.this.m_PortFDs[b] = true;
/*  132 */             JTermiosImpl.this.m_OpenPorts.put(Integer.valueOf(this.m_FD), this);
/*  133 */             this.m_CancelWaitSema4 = WinAPI.CreateEventA(null, false, false, null);
/*  134 */             if (this.m_CancelWaitSema4 == null)
/*  135 */               throw new RuntimeException("Unexpected failure of CreateEvent() call"); 
/*      */             return;
/*      */           } 
/*      */         } 
/*  139 */         throw new RuntimeException("Too many ports open");
/*      */       } 
/*      */     }
/*      */     
/*      */     public void close() {
/*  144 */       synchronized (JTermiosImpl.this) {
/*  145 */         if (this.m_FD >= 0) {
/*  146 */           JTermiosImpl.this.m_OpenPorts.remove(Integer.valueOf(this.m_FD));
/*  147 */           JTermiosImpl.this.m_PortFDs[this.m_FD] = false;
/*  148 */           this.m_FD = -1;
/*      */         } 
/*      */         
/*  151 */         if (this.m_CancelWaitSema4 != null)
/*  152 */           WinAPI.SetEvent(this.m_CancelWaitSema4); 
/*  153 */         if (this.m_Comm != null) {
/*  154 */           WinAPI.ResetEvent(this.m_SelOVL.hEvent);
/*      */           
/*  156 */           if (!WinAPI.CancelIo(this.m_Comm))
/*  157 */             JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "CancelIo() failed, GetLastError()= %d, %s\n", new Object[] { Integer.valueOf(WinAPI.GetLastError()), JTermios.JTermiosLogging.lineno(1) })); 
/*  158 */           if (!WinAPI.PurgeComm(this.m_Comm, 15)) {
/*  159 */             JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "PurgeComm() failed, GetLastError()= %d, %s\n", new Object[] { Integer.valueOf(WinAPI.GetLastError()), JTermios.JTermiosLogging.lineno(1) }));
/*      */           }
/*  161 */           WinAPI.GetOverlappedResult(this.m_Comm, this.m_RdOVL, this.m_RdN, true);
/*  162 */           WinAPI.GetOverlappedResult(this.m_Comm, this.m_WrOVL, this.m_WrN, true);
/*  163 */           WinAPI.GetOverlappedResult(this.m_Comm, this.m_SelOVL, this.m_SelN, true);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  169 */         synchronized (this.m_RdBuffer) {
/*  170 */           WinAPI.HANDLE hANDLE1 = (WinAPI.HANDLE)this.m_RdOVL.readField("hEvent");
/*  171 */           this.m_RdOVL = null;
/*  172 */           if (hANDLE1 != null && !hANDLE1.equals(WinAPI.NULL) && !hANDLE1.equals(WinAPI.INVALID_HANDLE_VALUE)) {
/*  173 */             WinAPI.CloseHandle(hANDLE1);
/*      */           }
/*      */         } 
/*  176 */         synchronized (this.m_WrBuffer) {
/*  177 */           WinAPI.HANDLE hANDLE1 = (WinAPI.HANDLE)this.m_WrOVL.readField("hEvent");
/*  178 */           this.m_WrOVL = null;
/*      */           
/*  180 */           if (hANDLE1 != null && !hANDLE1.equals(WinAPI.NULL) && !hANDLE1.equals(WinAPI.INVALID_HANDLE_VALUE)) {
/*  181 */             WinAPI.CloseHandle(hANDLE1);
/*      */           }
/*      */         } 
/*      */         
/*  185 */         waitUnlock();
/*      */         
/*  187 */         WinAPI.HANDLE hANDLE = (WinAPI.HANDLE)this.m_SelOVL.readField("hEvent");
/*  188 */         this.m_SelOVL = null;
/*  189 */         if (hANDLE != null && !hANDLE.equals(WinAPI.NULL) && !hANDLE.equals(WinAPI.INVALID_HANDLE_VALUE)) {
/*  190 */           WinAPI.CloseHandle(hANDLE);
/*      */         }
/*  192 */         if (this.m_Comm != null && this.m_Comm != WinAPI.NULL && this.m_Comm != WinAPI.INVALID_HANDLE_VALUE)
/*  193 */           WinAPI.CloseHandle(this.m_Comm); 
/*  194 */         this.m_Comm = null;
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   static class Fail
/*      */     extends Exception {}
/*      */   
/*      */   private static class FDSetImpl extends FDSet {
/*      */     static final int FD_SET_SIZE = 256;
/*      */     static final int NFBBITS = 32;
/*      */     
/*      */     private FDSetImpl() {}
/*      */     
/*  208 */     int[] bits = new int[8];
/*      */   }
/*      */   
/*      */   public JTermiosImpl() {
/*  212 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "instantiating %s\n", new Object[] { getClass().getCanonicalName() }));
/*      */   }
/*      */   
/*      */   public int errno() {
/*  216 */     return this.m_ErrNo;
/*      */   }
/*      */   
/*      */   public void cfmakeraw(Termios paramTermios) {
/*  220 */     paramTermios.c_iflag &= (JTermios.IGNBRK | JTermios.BRKINT | JTermios.PARMRK | JTermios.ISTRIP | JTermios.INLCR | JTermios.IGNCR | JTermios.ICRNL | JTermios.IXON) ^ 0xFFFFFFFF;
/*  221 */     paramTermios.c_oflag &= JTermios.OPOST ^ 0xFFFFFFFF;
/*  222 */     paramTermios.c_lflag &= (JTermios.ECHO | JTermios.ECHONL | JTermios.ICANON | JTermios.ISIG | JTermios.IEXTEN) ^ 0xFFFFFFFF;
/*  223 */     paramTermios.c_cflag &= (JTermios.CSIZE | JTermios.PARENB) ^ 0xFFFFFFFF;
/*  224 */     paramTermios.c_cflag |= JTermios.CS8;
/*      */   }
/*      */ 
/*      */   
/*      */   public int fcntl(int paramInt1, int paramInt2, int paramInt3) {
/*  229 */     Port port = getPort(paramInt1);
/*  230 */     if (port == null)
/*  231 */       return -1; 
/*  232 */     if (JTermios.F_SETFL == paramInt2)
/*  233 */     { port.m_OpenFlags = paramInt3; }
/*  234 */     else { if (JTermios.F_GETFL == paramInt2) {
/*  235 */         return port.m_OpenFlags;
/*      */       }
/*  237 */       this.m_ErrNo = JTermios.ENOTSUP;
/*  238 */       return -1; }
/*      */     
/*  240 */     return 0;
/*      */   }
/*      */   
/*      */   public int tcdrain(int paramInt) {
/*  244 */     Port port = getPort(paramInt);
/*  245 */     if (port == null)
/*  246 */       return -1; 
/*      */     try {
/*  248 */       synchronized (port.m_WrBuffer) {
/*  249 */         if (!WinAPI.FlushFileBuffers(port.m_Comm))
/*  250 */           port.fail(); 
/*  251 */         return 0;
/*      */       } 
/*  253 */     } catch (Fail fail) {
/*  254 */       return -1;
/*      */     } 
/*      */   }
/*      */   
/*      */   public int cfgetispeed(Termios paramTermios) {
/*  259 */     return paramTermios.c_ispeed;
/*      */   }
/*      */   
/*      */   public int cfgetospeed(Termios paramTermios) {
/*  263 */     return paramTermios.c_ospeed;
/*      */   }
/*      */   
/*      */   public int cfsetispeed(Termios paramTermios, int paramInt) {
/*  267 */     paramTermios.c_ispeed = paramInt;
/*  268 */     return 0;
/*      */   }
/*      */   
/*      */   public int cfsetospeed(Termios paramTermios, int paramInt) {
/*  272 */     paramTermios.c_ospeed = paramInt;
/*  273 */     return 0;
/*      */   }
/*      */   
/*      */   public int open(String paramString, int paramInt) {
/*  277 */     Port port = new Port();
/*  278 */     port.m_OpenFlags = paramInt;
/*      */     try {
/*  280 */       if (!paramString.startsWith("\\\\")) {
/*  281 */         paramString = "\\\\.\\" + paramString;
/*      */       }
/*  283 */       port.m_Comm = WinAPI.CreateFileW(new WString(paramString), -1073741824, 0, null, 3, 1073741824, null);
/*      */       
/*  285 */       if (WinAPI.INVALID_HANDLE_VALUE == port.m_Comm) {
/*  286 */         if (WinAPI.GetLastError() == 2) {
/*  287 */           this.m_ErrNo = JTermios.ENOENT;
/*      */         } else {
/*  289 */           this.m_ErrNo = JTermios.EBUSY;
/*  290 */         }  port.fail();
/*      */       } 
/*      */       
/*  293 */       if (!WinAPI.SetupComm(port.m_Comm, (int)port.m_RdBuffer.size(), (int)port.m_WrBuffer.size())) {
/*  294 */         port.fail();
/*      */       }
/*  296 */       cfmakeraw(port.m_Termios);
/*  297 */       cfsetispeed(port.m_Termios, JTermios.B9600);
/*  298 */       cfsetospeed(port.m_Termios, JTermios.B9600);
/*  299 */       port.m_Termios.c_cc[JTermios.VTIME] = 0;
/*  300 */       port.m_Termios.c_cc[JTermios.VMIN] = 0;
/*  301 */       updateFromTermios(port);
/*      */       
/*  303 */       port.m_RdOVL.writeField("hEvent", WinAPI.CreateEventA(null, true, false, null));
/*  304 */       if (port.m_RdOVL.hEvent == WinAPI.INVALID_HANDLE_VALUE) {
/*  305 */         port.fail();
/*      */       }
/*  307 */       port.m_WrOVL.writeField("hEvent", WinAPI.CreateEventA(null, true, false, null));
/*  308 */       if (port.m_WrOVL.hEvent == WinAPI.INVALID_HANDLE_VALUE) {
/*  309 */         port.fail();
/*      */       }
/*  311 */       port.m_SelOVL.writeField("hEvent", WinAPI.CreateEventA(null, true, false, null));
/*  312 */       if (port.m_SelOVL.hEvent == WinAPI.INVALID_HANDLE_VALUE) {
/*  313 */         port.fail();
/*      */       }
/*  315 */       return port.m_FD;
/*  316 */     } catch (Exception exception) {
/*  317 */       if (port != null)
/*  318 */         port.close(); 
/*  319 */       return -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void nanoSleep(long paramLong) throws Fail {
/*      */     try {
/*  326 */       Thread.sleep((int)(paramLong / 1000000L), (int)(paramLong % 1000000L));
/*  327 */     } catch (InterruptedException interruptedException) {
/*  328 */       throw new Fail();
/*      */     } 
/*      */   }
/*      */   
/*      */   private int getCharBits(Termios paramTermios) {
/*  333 */     byte b = 8;
/*  334 */     if ((paramTermios.c_cflag & JTermios.CSIZE) == JTermios.CS5)
/*  335 */       b = 5; 
/*  336 */     if ((paramTermios.c_cflag & JTermios.CSIZE) == JTermios.CS6)
/*  337 */       b = 6; 
/*  338 */     if ((paramTermios.c_cflag & JTermios.CSIZE) == JTermios.CS7)
/*  339 */       b = 7; 
/*  340 */     if ((paramTermios.c_cflag & JTermios.CSIZE) == JTermios.CS8)
/*  341 */       b = 8; 
/*  342 */     if ((paramTermios.c_cflag & JTermios.CSTOPB) != 0)
/*  343 */       b++; 
/*  344 */     if ((paramTermios.c_cflag & JTermios.PARENB) != 0)
/*  345 */       b++; 
/*  346 */     b += 2;
/*  347 */     return b;
/*      */   }
/*      */   
/*      */   private static int min(int paramInt1, int paramInt2) {
/*  351 */     return (paramInt1 < paramInt2) ? paramInt1 : paramInt2;
/*      */   }
/*      */   
/*      */   private static int max(int paramInt1, int paramInt2) {
/*  355 */     return (paramInt1 > paramInt2) ? paramInt1 : paramInt2;
/*      */   }
/*      */ 
/*      */   
/*      */   public int read(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
/*  360 */     Port port = getPort(paramInt1);
/*  361 */     if (port == null)
/*  362 */       return -1; 
/*  363 */     synchronized (port.m_RdBuffer) {
/*      */ 
/*      */       
/*  366 */       if (paramInt2 > port.m_RdBuffer.size()) {
/*  367 */         paramInt2 = (int)port.m_RdBuffer.size();
/*      */       }
/*  369 */       if (paramInt2 == 0) {
/*  370 */         return 0;
/*      */       }
/*      */ 
/*      */       
/*  374 */       if ((port.m_OpenFlags & JTermios.O_NONBLOCK) != 0) {
/*  375 */         clearCommErrors(port);
/*  376 */         int i = port.m_COMSTAT.cbInQue;
/*  377 */         if (i == 0) {
/*  378 */           this.m_ErrNo = JTermios.EAGAIN;
/*  379 */           return -1;
/*      */         } 
/*  381 */         paramInt2 = min(paramInt2, i);
/*      */       } else {
/*  383 */         clearCommErrors(port);
/*  384 */         int i = port.m_COMSTAT.cbInQue;
/*  385 */         int j = 0xFF & port.m_Termios.c_cc[JTermios.VTIME];
/*  386 */         int k = 0xFF & port.m_Termios.c_cc[JTermios.VMIN];
/*      */         
/*  388 */         if (k == 0 && j == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  395 */           if (i == 0)
/*  396 */             return 0; 
/*  397 */           paramInt2 = min(paramInt2, i);
/*      */         } 
/*  399 */         if (k != 0 || j > 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  413 */         if (k > 0 && j > 0)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  420 */           paramInt2 = min(max(k, i), paramInt2);
/*      */         }
/*  422 */         if (k > 0 && j == 0)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  429 */           paramInt2 = min(max(k, i), paramInt2);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  434 */       if (!WinAPI.ResetEvent(port.m_RdOVL.hEvent)) {
/*  435 */         port.fail();
/*      */       }
/*  437 */       if (!WinAPI.ReadFile(port.m_Comm, (Pointer)port.m_RdBuffer, paramInt2, port.m_RdN, port.m_RdOVL)) {
/*  438 */         if (WinAPI.GetLastError() != 997)
/*  439 */           port.fail(); 
/*  440 */         if (WinAPI.WaitForSingleObject(port.m_RdOVL.hEvent, -1) != 0)
/*  441 */           port.fail(); 
/*  442 */         if (!WinAPI.GetOverlappedResult(port.m_Comm, port.m_RdOVL, port.m_RdN, true)) {
/*  443 */           port.fail();
/*      */         }
/*      */       } 
/*  446 */       port.m_RdBuffer.read(0L, paramArrayOfbyte, 0, port.m_RdN[0]);
/*  447 */       return port.m_RdN[0];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int write(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
/*  455 */     Port port = getPort(paramInt1);
/*  456 */     if (port == null) {
/*  457 */       return -1;
/*      */     }
/*  459 */     synchronized (port.m_WrBuffer) {
/*      */       
/*  461 */       if (port.m_WritePending > 0) {
/*      */         while (true) {
/*  463 */           int i = WinAPI.WaitForSingleObject(port.m_WrOVL.hEvent, -1);
/*  464 */           if (i == 258) {
/*  465 */             clearCommErrors(port);
/*  466 */             JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "write pending, cbInQue %d cbOutQue %d\n", new Object[] { Integer.valueOf(port.m_COMSTAT.cbInQue), Integer.valueOf(port.m_COMSTAT.cbOutQue) })); continue;
/*      */           }  break;
/*      */         } 
/*  469 */         if (!WinAPI.GetOverlappedResult(port.m_Comm, port.m_WrOVL, port.m_WrN, false))
/*  470 */           port.fail(); 
/*  471 */         if (port.m_WrN[0] != port.m_WritePending) {
/*  472 */           new RuntimeException("Windows OVERLAPPED WriteFile failed to write all, tried to write " + port.m_WritePending + " but got " + port.m_WrN[0]);
/*      */         }
/*      */         
/*  475 */         port.m_WritePending = 0;
/*      */       } 
/*  477 */       if ((port.m_OpenFlags & JTermios.O_NONBLOCK) != 0) {
/*  478 */         if (!WinAPI.ClearCommError(port.m_Comm, port.m_WrErr, port.m_WrStat))
/*  479 */           port.fail(); 
/*  480 */         int i = (int)port.m_WrBuffer.size() - port.m_WrStat.cbOutQue;
/*  481 */         if (paramInt2 > i) {
/*  482 */           paramInt2 = i;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  487 */       if (!WinAPI.ResetEvent(port.m_WrOVL.hEvent)) {
/*  488 */         port.fail();
/*      */       }
/*  490 */       if (paramInt2 > port.m_WrBuffer.size())
/*  491 */         paramInt2 = (int)port.m_WrBuffer.size(); 
/*  492 */       port.m_WrBuffer.write(0L, paramArrayOfbyte, 0, paramInt2);
/*  493 */       boolean bool = WinAPI.WriteFile(port.m_Comm, (Pointer)port.m_WrBuffer, paramInt2, port.m_WrN, port.m_WrOVL);
/*      */       
/*  495 */       if (!bool) {
/*  496 */         if (WinAPI.GetLastError() != 997)
/*  497 */           port.fail(); 
/*  498 */         port.m_WritePending = paramInt2;
/*      */       } 
/*      */       
/*  501 */       return paramInt2;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int close(int paramInt) {
/*  509 */     Port port = getPort(paramInt);
/*  510 */     if (port == null)
/*  511 */       return -1; 
/*  512 */     port.close();
/*  513 */     return 0;
/*      */   }
/*      */   
/*      */   public int tcflush(int paramInt1, int paramInt2) {
/*  517 */     Port port = getPort(paramInt1);
/*  518 */     if (port == null)
/*  519 */       return -1; 
/*      */     try {
/*  521 */       if (paramInt2 == JTermios.TCIFLUSH) {
/*  522 */         if (!WinAPI.PurgeComm(port.m_Comm, 2))
/*  523 */           port.fail(); 
/*  524 */       } else if (paramInt2 == JTermios.TCOFLUSH) {
/*  525 */         if (!WinAPI.PurgeComm(port.m_Comm, 1))
/*  526 */           port.fail(); 
/*  527 */       } else if (paramInt2 == JTermios.TCIOFLUSH) {
/*  528 */         if (!WinAPI.PurgeComm(port.m_Comm, 1))
/*  529 */           port.fail(); 
/*  530 */         if (!WinAPI.PurgeComm(port.m_Comm, 2))
/*  531 */           port.fail(); 
/*      */       } else {
/*  533 */         this.m_ErrNo = JTermios.ENOTSUP;
/*  534 */         return -1;
/*      */       } 
/*      */       
/*  537 */       return 0;
/*  538 */     } catch (Fail fail) {
/*  539 */       return -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int tcgetattr(int paramInt, Termios paramTermios) {
/*  555 */     Port port = getPort(paramInt);
/*  556 */     if (port == null)
/*  557 */       return -1; 
/*  558 */     paramTermios.set(port.m_Termios);
/*  559 */     return 0;
/*      */   }
/*      */   
/*      */   public int tcsendbreak(int paramInt1, int paramInt2) {
/*  563 */     Port port = getPort(paramInt1);
/*  564 */     if (port == null)
/*  565 */       return -1; 
/*      */     try {
/*  567 */       if (!WinAPI.SetCommBreak(port.m_Comm))
/*  568 */         port.fail(); 
/*  569 */       nanoSleep(paramInt2 * 250000000L);
/*  570 */       if (!WinAPI.ClearCommBreak(port.m_Comm))
/*  571 */         port.fail(); 
/*  572 */       return 0;
/*  573 */     } catch (Fail fail) {
/*  574 */       return -1;
/*      */     } 
/*      */   }
/*      */   
/*      */   public int tcsetattr(int paramInt1, int paramInt2, Termios paramTermios) {
/*  579 */     if (paramInt2 != JTermios.TCSANOW) {
/*  580 */       JTermios.JTermiosLogging.log(0, "tcsetattr only supports TCSANOW\n", new Object[0]);
/*      */     }
/*  582 */     Port port = getPort(paramInt1);
/*  583 */     if (port == null)
/*  584 */       return -1; 
/*  585 */     synchronized (port.m_Termios) {
/*      */       
/*  587 */       port.m_Termios.set(paramTermios);
/*  588 */       updateFromTermios(port);
/*  589 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int updateFromTermios(Port paramPort) throws Fail {
/*  598 */     Termios termios = paramPort.m_Termios;
/*  599 */     int i = termios.c_ospeed;
/*  600 */     int j = termios.c_cflag;
/*  601 */     int k = termios.c_iflag;
/*  602 */     int m = termios.c_oflag;
/*      */     
/*  604 */     if (i != paramPort.m_c_speed || j != paramPort.m_c_cflag || k != paramPort.m_c_iflag || m != paramPort.m_c_oflag) {
/*  605 */       WinAPI.DCB dCB = paramPort.m_DCB;
/*  606 */       if (!WinAPI.GetCommState(paramPort.m_Comm, dCB)) {
/*  607 */         paramPort.fail();
/*      */       }
/*  609 */       dCB.DCBlength = dCB.size();
/*  610 */       dCB.BaudRate = i;
/*  611 */       if (termios.c_ospeed != termios.c_ispeed)
/*  612 */         JTermios.JTermiosLogging.log(0, "c_ospeed (%d) != c_ispeed (%d)\n", new Object[] { Integer.valueOf(termios.c_ospeed), Integer.valueOf(termios.c_ispeed) }); 
/*  613 */       int i2 = 0;
/*      */ 
/*      */       
/*  616 */       i2 |= 0x1;
/*  617 */       if ((j & JTermios.PARENB) != 0) {
/*  618 */         i2 |= 0x2;
/*      */       }
/*  620 */       if ((k & JTermios.IXON) != 0)
/*  621 */         i2 |= 0x100; 
/*  622 */       if ((k & JTermios.IXOFF) != 0)
/*  623 */         i2 |= 0x200; 
/*  624 */       if ((k & JTermios.IXANY) != 0) {
/*  625 */         i2 |= 0x80;
/*      */       }
/*  627 */       if ((k & JTermios.CRTSCTS) != 0) {
/*  628 */         i2 |= 0x3000;
/*  629 */         i2 |= 0x4;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  640 */       dCB.fFlags = i2;
/*      */ 
/*      */ 
/*      */       
/*  644 */       byte b = 8;
/*  645 */       int i3 = j & JTermios.CSIZE;
/*  646 */       if (i3 == JTermios.CS5)
/*  647 */         b = 5; 
/*  648 */       if (i3 == JTermios.CS6)
/*  649 */         b = 6; 
/*  650 */       if (i3 == JTermios.CS7)
/*  651 */         b = 7; 
/*  652 */       if (i3 == JTermios.CS8)
/*  653 */         b = 8; 
/*  654 */       dCB.ByteSize = b;
/*      */       
/*  656 */       if ((j & JTermios.PARENB) != 0)
/*  657 */       { if ((j & JTermios.PARODD) != 0 && (j & JTermios.CMSPAR) != 0) {
/*  658 */           dCB.Parity = 3;
/*  659 */         } else if ((j & JTermios.PARODD) != 0) {
/*  660 */           dCB.Parity = 1;
/*  661 */         } else if ((j & JTermios.CMSPAR) != 0) {
/*  662 */           dCB.Parity = 4;
/*      */         } else {
/*  664 */           dCB.Parity = 2;
/*      */         }  }
/*  666 */       else { dCB.Parity = 0; }
/*      */       
/*  668 */       dCB.StopBits = ((j & JTermios.CSTOPB) != 0) ? 2 : 0;
/*  669 */       dCB.XonChar = termios.c_cc[JTermios.VSTART];
/*  670 */       dCB.XoffChar = termios.c_cc[JTermios.VSTOP];
/*  671 */       dCB.ErrorChar = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  681 */       dCB.EvtChar = 10;
/*  682 */       dCB.EofChar = termios.c_cc[JTermios.VEOF];
/*      */       
/*  684 */       if (!WinAPI.SetCommState(paramPort.m_Comm, dCB)) {
/*  685 */         paramPort.fail();
/*      */       }
/*  687 */       paramPort.m_c_speed = i;
/*  688 */       paramPort.m_c_cflag = j;
/*  689 */       paramPort.m_c_iflag = k;
/*  690 */       paramPort.m_c_oflag = m;
/*      */     } 
/*      */     
/*  693 */     int n = paramPort.m_Termios.c_cc[JTermios.VMIN] & 0xFF;
/*  694 */     int i1 = (paramPort.m_Termios.c_cc[JTermios.VTIME] & 0xFF) * 100;
/*  695 */     if (n != paramPort.m_VMIN || i1 != paramPort.m_VTIME) {
/*  696 */       WinAPI.COMMTIMEOUTS cOMMTIMEOUTS = paramPort.m_Timeouts;
/*      */ 
/*      */       
/*  699 */       cOMMTIMEOUTS.WriteTotalTimeoutConstant = 0;
/*  700 */       cOMMTIMEOUTS.WriteTotalTimeoutMultiplier = 0;
/*  701 */       if (n == 0 && i1 == 0) {
/*      */ 
/*      */         
/*  704 */         cOMMTIMEOUTS.ReadIntervalTimeout = -1;
/*  705 */         cOMMTIMEOUTS.ReadTotalTimeoutConstant = 0;
/*  706 */         cOMMTIMEOUTS.ReadTotalTimeoutMultiplier = 0;
/*      */       } 
/*  708 */       if (n == 0 && i1 > 0) {
/*      */ 
/*      */         
/*  711 */         cOMMTIMEOUTS.ReadIntervalTimeout = 0;
/*  712 */         cOMMTIMEOUTS.ReadTotalTimeoutConstant = i1;
/*  713 */         cOMMTIMEOUTS.ReadTotalTimeoutMultiplier = 0;
/*      */       } 
/*  715 */       if (n > 0 && i1 > 0) {
/*      */ 
/*      */         
/*  718 */         cOMMTIMEOUTS.ReadIntervalTimeout = i1;
/*  719 */         cOMMTIMEOUTS.ReadTotalTimeoutConstant = 0;
/*  720 */         cOMMTIMEOUTS.ReadTotalTimeoutMultiplier = 0;
/*      */       } 
/*  722 */       if (n > 0 && i1 == 0) {
/*      */ 
/*      */         
/*  725 */         cOMMTIMEOUTS.ReadIntervalTimeout = 0;
/*  726 */         cOMMTIMEOUTS.ReadTotalTimeoutConstant = 0;
/*  727 */         cOMMTIMEOUTS.ReadTotalTimeoutMultiplier = 0;
/*      */       } 
/*  729 */       if (!WinAPI.SetCommTimeouts(paramPort.m_Comm, paramPort.m_Timeouts))
/*  730 */         paramPort.fail(); 
/*  731 */       paramPort.m_VMIN = n;
/*  732 */       paramPort.m_VTIME = i1;
/*  733 */       JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(2, "vmin %d vtime %d ReadIntervalTimeout %d ReadTotalTimeoutConstant %d ReadTotalTimeoutMultiplier %d\n", new Object[] { Integer.valueOf(n), Integer.valueOf(i1), Integer.valueOf(cOMMTIMEOUTS.ReadIntervalTimeout), Integer.valueOf(cOMMTIMEOUTS.ReadTotalTimeoutConstant), Integer.valueOf(cOMMTIMEOUTS.ReadTotalTimeoutMultiplier) }));
/*      */     } 
/*      */     
/*  736 */     return 0;
/*      */   }
/*      */   
/*      */   private int maskToFDSets(Port paramPort, FDSet paramFDSet1, FDSet paramFDSet2, FDSet paramFDSet3, int paramInt) throws Fail {
/*  740 */     clearCommErrors(paramPort);
/*  741 */     int i = paramPort.m_EventFlags.getValue();
/*  742 */     int j = paramPort.m_FD;
/*  743 */     if ((i & 0x1) != 0 && paramPort.m_COMSTAT.cbInQue > 0) {
/*  744 */       FD_SET(j, paramFDSet1);
/*  745 */       paramInt++;
/*      */     } 
/*  747 */     if ((i & 0x4) != 0 && paramPort.m_COMSTAT.cbOutQue == 0) {
/*  748 */       FD_SET(j, paramFDSet2);
/*  749 */       paramInt++;
/*      */     } 
/*  751 */     return paramInt;
/*      */   }
/*      */   
/*      */   private void clearCommErrors(Port paramPort) throws Fail {
/*  755 */     synchronized (paramPort.m_COMSTAT) {
/*  756 */       if (!WinAPI.ClearCommError(paramPort.m_Comm, paramPort.m_ClearErr, paramPort.m_COMSTAT)) {
/*  757 */         paramPort.fail();
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public int select(int paramInt, FDSet paramFDSet1, FDSet paramFDSet2, FDSet paramFDSet3, TimeVal paramTimeVal) {
/*  763 */     int i = 0;
/*  764 */     LinkedList<Port> linkedList = new LinkedList();
/*      */     
/*      */     try {
/*  767 */       LinkedList<Port> linkedList1 = new LinkedList(); int j;
/*  768 */       for (j = 0; j < paramInt; j++) {
/*  769 */         boolean bool1 = FD_ISSET(j, paramFDSet1);
/*  770 */         boolean bool2 = FD_ISSET(j, paramFDSet2);
/*  771 */         FD_CLR(j, paramFDSet1);
/*  772 */         FD_CLR(j, paramFDSet2);
/*  773 */         if (bool1 || bool2) {
/*  774 */           Port port = getPort(j);
/*  775 */           if (port == null)
/*  776 */             return -1; 
/*      */           try {
/*  778 */             port.lock();
/*  779 */             linkedList.add(port);
/*  780 */             clearCommErrors(port);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  787 */             if (bool1 && port.m_COMSTAT.cbInQue > 0) {
/*  788 */               FD_SET(j, paramFDSet1);
/*  789 */               i++;
/*      */             } 
/*      */             
/*  792 */             if (bool2 && port.m_COMSTAT.cbOutQue == 0) {
/*  793 */               FD_SET(j, paramFDSet2);
/*  794 */               i++;
/*      */             } 
/*      */             
/*  797 */             int k = 0;
/*  798 */             if (bool1)
/*  799 */               k |= 0x1; 
/*  800 */             if (bool2) {
/*  801 */               k |= 0x4;
/*      */             }
/*  803 */             int[] arrayOfInt = { 0 };
/*  804 */             if (!WinAPI.GetCommMask(port.m_Comm, arrayOfInt)) {
/*  805 */               port.fail();
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  813 */             boolean bool = true;
/*  814 */             if (arrayOfInt[0] == k) {
/*  815 */               WinAPI.GetOverlappedResult(port.m_Comm, port.m_SelOVL, port.m_SelN, false);
/*  816 */               int m = WinAPI.GetLastError();
/*  817 */               bool = (m != 996 && m != 997) ? true : false;
/*      */             }
/*  819 */             else if (!WinAPI.SetCommMask(port.m_Comm, k)) {
/*  820 */               port.fail();
/*      */             } 
/*  822 */             if (bool) {
/*  823 */               if (!WinAPI.ResetEvent(port.m_SelOVL.hEvent))
/*  824 */                 port.fail(); 
/*  825 */               if (WinAPI.WaitCommEvent(port.m_Comm, port.m_EventFlags, port.m_SelOVL)) {
/*  826 */                 if (!WinAPI.GetOverlappedResult(port.m_Comm, port.m_SelOVL, port.m_SelN, false)) {
/*  827 */                   port.fail();
/*      */                 }
/*      */                 
/*  830 */                 i = maskToFDSets(port, paramFDSet1, paramFDSet2, paramFDSet3, i);
/*      */               } else {
/*      */                 
/*  833 */                 if (WinAPI.GetLastError() != 997)
/*  834 */                   port.fail(); 
/*  835 */                 linkedList1.add(port);
/*      */               } 
/*      */             } 
/*  838 */           } catch (InterruptedException interruptedException) {
/*  839 */             this.m_ErrNo = JTermios.EINTR;
/*  840 */             return -1;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  845 */       if (i == 0) {
/*  846 */         j = linkedList1.size();
/*  847 */         if (j > 0) {
/*  848 */           WinAPI.HANDLE[] arrayOfHANDLE = new WinAPI.HANDLE[linkedList1.size() * 2];
/*  849 */           int k = 0;
/*  850 */           for (Port port : linkedList1) {
/*  851 */             arrayOfHANDLE[k++] = port.m_SelOVL.hEvent;
/*  852 */             arrayOfHANDLE[k++] = port.m_CancelWaitSema4;
/*      */           } 
/*  854 */           boolean bool = (paramTimeVal != null) ? (int)(paramTimeVal.tv_sec * 1000L + paramTimeVal.tv_usec / 1000L) : true;
/*      */           
/*  856 */           int m = WinAPI.WaitForMultipleObjects(j * 2, arrayOfHANDLE, false, bool);
/*      */           
/*  858 */           if (m == 258)
/*      */           {
/*      */             
/*  861 */             for (Port port : linkedList1) {
/*  862 */               clearCommErrors(port);
/*  863 */               int[] arrayOfInt = { 0 };
/*      */               
/*  865 */               if (!WinAPI.GetCommMask(port.m_Comm, arrayOfInt))
/*  866 */                 port.fail(); 
/*  867 */               if (port.m_COMSTAT.cbInQue > 0 && (arrayOfInt[0] & 0x1) != 0) {
/*  868 */                 FD_SET(port.m_FD, paramFDSet1);
/*  869 */                 JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "missed EV_RXCHAR event\n", new Object[0]));
/*  870 */                 return 1;
/*      */               } 
/*  872 */               if (port.m_COMSTAT.cbOutQue == 0 && (arrayOfInt[0] & 0x4) != 0) {
/*  873 */                 FD_SET(port.m_FD, paramFDSet2);
/*  874 */                 JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "missed EV_TXEMPTY event\n", new Object[0]));
/*  875 */                 return 1;
/*      */               } 
/*      */             } 
/*      */           }
/*      */           
/*  880 */           if (m != 258) {
/*  881 */             k = (m - 0) / 2;
/*  882 */             if (k < 0 || k >= j) {
/*  883 */               throw new Fail();
/*      */             }
/*  885 */             Port port = linkedList1.get(k);
/*  886 */             if (!WinAPI.GetOverlappedResult(port.m_Comm, port.m_SelOVL, port.m_SelN, false)) {
/*  887 */               port.fail();
/*      */             }
/*  889 */             i = maskToFDSets(port, paramFDSet1, paramFDSet2, paramFDSet3, i);
/*      */           } 
/*      */         } else {
/*  892 */           if (paramTimeVal != null) {
/*  893 */             nanoSleep(paramTimeVal.tv_sec * 1000000000L + paramTimeVal.tv_usec * 1000L);
/*      */           } else {
/*  895 */             this.m_ErrNo = JTermios.EINVAL;
/*  896 */             return -1;
/*      */           } 
/*  898 */           return 0;
/*      */         } 
/*      */       } 
/*  901 */     } catch (Fail fail) {
/*  902 */       return -1;
/*      */     } finally {
/*      */       
/*  905 */       for (Port port : linkedList) {
/*  906 */         port.unlock();
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  912 */     return i;
/*      */   }
/*      */   
/*      */   public int poll(Pollfd[] paramArrayOfPollfd, int paramInt1, int paramInt2) {
/*  916 */     this.m_ErrNo = JTermios.EINVAL;
/*  917 */     return -1;
/*      */   }
/*      */   
/*      */   public int poll(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/*  921 */     this.m_ErrNo = JTermios.EINVAL;
/*  922 */     return -1;
/*      */   }
/*      */   
/*      */   public void perror(String paramString) {
/*  926 */     if (paramString != null && paramString.length() > 0)
/*  927 */       System.out.print(paramString + ": "); 
/*  928 */     System.out.printf("%d\n", new Object[] { Integer.valueOf(this.m_ErrNo) });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int baudToDCB(int paramInt) {
/*  936 */     switch (paramInt) {
/*      */       case 110:
/*  938 */         return 110;
/*      */       case 300:
/*  940 */         return 300;
/*      */       case 600:
/*  942 */         return 600;
/*      */       case 1200:
/*  944 */         return 1200;
/*      */       case 2400:
/*  946 */         return 2400;
/*      */       case 4800:
/*  948 */         return 4800;
/*      */       case 9600:
/*  950 */         return 9600;
/*      */       case 14400:
/*  952 */         return 14400;
/*      */       case 19200:
/*  954 */         return 19200;
/*      */       case 38400:
/*  956 */         return 38400;
/*      */       case 57600:
/*  958 */         return 57600;
/*      */       case 115200:
/*  960 */         return 115200;
/*      */       case 128000:
/*  962 */         return 128000;
/*      */       case 256000:
/*  964 */         return 256000;
/*      */     } 
/*      */     
/*  967 */     return paramInt;
/*      */   }
/*      */ 
/*      */   
/*      */   public FDSet newFDSet() {
/*  972 */     return new FDSetImpl();
/*      */   }
/*      */   
/*      */   public void FD_CLR(int paramInt, FDSet paramFDSet) {
/*  976 */     if (paramFDSet == null)
/*      */       return; 
/*  978 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/*  979 */     fDSetImpl.bits[paramInt / 32] = fDSetImpl.bits[paramInt / 32] & (1 << paramInt % 32 ^ 0xFFFFFFFF);
/*      */   }
/*      */   
/*      */   public boolean FD_ISSET(int paramInt, FDSet paramFDSet) {
/*  983 */     if (paramFDSet == null)
/*  984 */       return false; 
/*  985 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/*  986 */     return ((fDSetImpl.bits[paramInt / 32] & 1 << paramInt % 32) != 0);
/*      */   }
/*      */   
/*      */   public void FD_SET(int paramInt, FDSet paramFDSet) {
/*  990 */     if (paramFDSet == null)
/*      */       return; 
/*  992 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/*  993 */     fDSetImpl.bits[paramInt / 32] = fDSetImpl.bits[paramInt / 32] | 1 << paramInt % 32;
/*      */   }
/*      */   
/*      */   public void FD_ZERO(FDSet paramFDSet) {
/*  997 */     if (paramFDSet == null)
/*      */       return; 
/*  999 */     FDSetImpl fDSetImpl = (FDSetImpl)paramFDSet;
/* 1000 */     Arrays.fill(fDSetImpl.bits, 0);
/*      */   }
/*      */   
/*      */   public int ioctl(int paramInt1, int paramInt2, int[] paramArrayOfint) {
/* 1004 */     Port port = getPort(paramInt1);
/* 1005 */     if (port == null)
/* 1006 */       return -1; 
/*      */     try {
/* 1008 */       if (paramInt2 == JTermios.FIONREAD) {
/* 1009 */         clearCommErrors(port);
/* 1010 */         paramArrayOfint[0] = port.m_COMSTAT.cbInQue;
/* 1011 */         return 0;
/* 1012 */       }  if (paramInt2 == JTermios.TIOCMSET) {
/* 1013 */         int i = paramArrayOfint[0];
/* 1014 */         if ((i & JTermios.TIOCM_DTR) != 0) {
/* 1015 */           port.MSR |= JTermios.TIOCM_DTR;
/*      */         } else {
/* 1017 */           port.MSR &= JTermios.TIOCM_DTR ^ 0xFFFFFFFF;
/*      */         } 
/* 1019 */         if (!WinAPI.EscapeCommFunction(port.m_Comm, ((i & JTermios.TIOCM_DTR) != 0) ? 5 : 6)) {
/* 1020 */           port.fail();
/*      */         }
/* 1022 */         if ((i & JTermios.TIOCM_RTS) != 0) {
/* 1023 */           port.MSR |= JTermios.TIOCM_RTS;
/*      */         } else {
/* 1025 */           port.MSR &= JTermios.TIOCM_RTS ^ 0xFFFFFFFF;
/* 1026 */         }  if (!WinAPI.EscapeCommFunction(port.m_Comm, ((i & JTermios.TIOCM_RTS) != 0) ? 3 : 4))
/* 1027 */           port.fail(); 
/* 1028 */         return 0;
/* 1029 */       }  if (paramInt2 == JTermios.TIOCMGET) {
/* 1030 */         int[] arrayOfInt = { 0 };
/* 1031 */         if (!WinAPI.GetCommModemStatus(port.m_Comm, arrayOfInt))
/* 1032 */           port.fail(); 
/* 1033 */         int i = arrayOfInt[0];
/* 1034 */         int j = paramArrayOfint[0];
/* 1035 */         if ((i & 0x80) != 0) {
/* 1036 */           j |= JTermios.TIOCM_CAR;
/*      */         } else {
/* 1038 */           j &= JTermios.TIOCM_CAR ^ 0xFFFFFFFF;
/* 1039 */         }  if ((i & 0x40) != 0) {
/* 1040 */           j |= JTermios.TIOCM_RNG;
/*      */         } else {
/* 1042 */           j &= JTermios.TIOCM_RNG ^ 0xFFFFFFFF;
/* 1043 */         }  if ((i & 0x20) != 0) {
/* 1044 */           j |= JTermios.TIOCM_DSR;
/*      */         } else {
/* 1046 */           j &= JTermios.TIOCM_DSR ^ 0xFFFFFFFF;
/* 1047 */         }  if ((i & 0x10) != 0) {
/* 1048 */           j |= JTermios.TIOCM_CTS;
/*      */         } else {
/* 1050 */           j &= JTermios.TIOCM_CTS ^ 0xFFFFFFFF;
/*      */         } 
/* 1052 */         if ((port.MSR & JTermios.TIOCM_DTR) != 0) {
/* 1053 */           j |= JTermios.TIOCM_DTR;
/*      */         } else {
/* 1055 */           j &= JTermios.TIOCM_DTR ^ 0xFFFFFFFF;
/* 1056 */         }  if ((port.MSR & JTermios.TIOCM_RTS) != 0) {
/* 1057 */           j |= JTermios.TIOCM_RTS;
/*      */         } else {
/* 1059 */           j &= JTermios.TIOCM_RTS ^ 0xFFFFFFFF;
/* 1060 */         }  paramArrayOfint[0] = j;
/*      */         
/* 1062 */         return 0;
/*      */       } 
/* 1064 */       this.m_ErrNo = JTermios.ENOTSUP;
/* 1065 */       return -1;
/*      */     }
/* 1067 */     catch (Fail fail) {
/* 1068 */       return -1;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void set_errno(int paramInt) {
/* 1073 */     this.m_ErrNo = paramInt;
/*      */   }
/*      */   
/*      */   private void report(String paramString) {
/* 1077 */     System.err.print(paramString);
/*      */   }
/*      */   
/*      */   private Port getPort(int paramInt) {
/* 1081 */     synchronized (this) {
/* 1082 */       Port port = this.m_OpenPorts.get(Integer.valueOf(paramInt));
/* 1083 */       if (port == null)
/* 1084 */         this.m_ErrNo = JTermios.EBADF; 
/* 1085 */       return port;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static String getString(char[] paramArrayOfchar, int paramInt) {
/* 1090 */     StringBuffer stringBuffer = new StringBuffer();
/*      */     char c;
/* 1092 */     while ((c = paramArrayOfchar[paramInt++]) != '\000')
/* 1093 */       stringBuffer.append(c); 
/* 1094 */     return stringBuffer.toString();
/*      */   }
/*      */   
/*      */   public String getPortNamePattern() {
/* 1098 */     return "^COM.*";
/*      */   }
/*      */   
/*      */   public List<String> getPortList() {
/* 1102 */     Pattern pattern = JTermios.getPortNamePattern(this);
/*      */     
/* 1104 */     int i = 0;
/* 1105 */     for (i = 16384; i < 262144; i *= 2) {
/* 1106 */       char[] arrayOfChar = new char[i];
/* 1107 */       int j = WinAPI.QueryDosDeviceW(null, arrayOfChar, arrayOfChar.length);
/* 1108 */       if (j > 0) {
/* 1109 */         LinkedList<String> linkedList = new LinkedList();
/* 1110 */         int m = 0;
/*      */         String str;
/* 1112 */         while ((str = getString(arrayOfChar, m)).length() > 0) {
/* 1113 */           if (pattern.matcher(str).matches()) {
/* 1114 */             linkedList.add(str);
/*      */           }
/* 1116 */           m += str.length() + 1;
/*      */         } 
/* 1118 */         return linkedList;
/*      */       } 
/* 1120 */       int k = WinAPI.GetLastError();
/* 1121 */       if (k != 122) {
/* 1122 */         JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "QueryDosDeviceW() failed with GetLastError() = %d\n", new Object[] { Integer.valueOf(k) }));
/* 1123 */         return null;
/*      */       } 
/*      */     } 
/*      */     
/* 1127 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "Repeated QueryDosDeviceW() calls failed up to buffer size %d\n", new Object[] { Integer.valueOf(i) }));
/* 1128 */     return null;
/*      */   }
/*      */   
/*      */   public void shutDown() {
/* 1132 */     for (Port port : this.m_OpenPorts.values()) {
/*      */       try {
/* 1134 */         JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(1, "shutDown() closing port %d\n", new Object[] { Integer.valueOf(port.m_FD) }));
/* 1135 */         port.close();
/* 1136 */       } catch (Exception exception) {
/*      */         
/* 1138 */         exception.printStackTrace();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public int setspeed(int paramInt1, Termios paramTermios, int paramInt2) {
/* 1144 */     int i = paramInt2;
/* 1145 */     switch (paramInt2) {
/*      */       case 50:
/* 1147 */         i = JTermios.B50;
/*      */         break;
/*      */       case 75:
/* 1150 */         i = JTermios.B75;
/*      */         break;
/*      */       case 110:
/* 1153 */         i = JTermios.B110;
/*      */         break;
/*      */       case 134:
/* 1156 */         i = JTermios.B134;
/*      */         break;
/*      */       case 150:
/* 1159 */         i = JTermios.B150;
/*      */         break;
/*      */       case 200:
/* 1162 */         i = JTermios.B200;
/*      */         break;
/*      */       case 300:
/* 1165 */         i = JTermios.B300;
/*      */         break;
/*      */       case 600:
/* 1168 */         i = JTermios.B600;
/*      */         break;
/*      */       case 1200:
/* 1171 */         i = JTermios.B1200;
/*      */         break;
/*      */       case 1800:
/* 1174 */         i = JTermios.B1800;
/*      */         break;
/*      */       case 2400:
/* 1177 */         i = JTermios.B2400;
/*      */         break;
/*      */       case 4800:
/* 1180 */         i = JTermios.B4800;
/*      */         break;
/*      */       case 9600:
/* 1183 */         i = JTermios.B9600;
/*      */         break;
/*      */       case 19200:
/* 1186 */         i = JTermios.B19200;
/*      */         break;
/*      */       case 38400:
/* 1189 */         i = JTermios.B38400;
/*      */         break;
/*      */       case 7200:
/* 1192 */         i = JTermios.B7200;
/*      */         break;
/*      */       case 14400:
/* 1195 */         i = JTermios.B14400;
/*      */         break;
/*      */       case 28800:
/* 1198 */         i = JTermios.B28800;
/*      */         break;
/*      */       case 57600:
/* 1201 */         i = JTermios.B57600;
/*      */         break;
/*      */       case 76800:
/* 1204 */         i = JTermios.B76800;
/*      */         break;
/*      */       case 115200:
/* 1207 */         i = JTermios.B115200;
/*      */         break;
/*      */       case 230400:
/* 1210 */         i = JTermios.B230400;
/*      */         break;
/*      */     } 
/*      */     int j;
/* 1214 */     if ((j = cfsetispeed(paramTermios, i)) != 0)
/* 1215 */       return j; 
/* 1216 */     if ((j = cfsetospeed(paramTermios, i)) != 0)
/* 1217 */       return j; 
/* 1218 */     if ((j = tcsetattr(paramInt1, JTermios.TCSANOW, paramTermios)) != 0)
/* 1219 */       return j; 
/* 1220 */     return 0;
/*      */   }
/*      */   
/*      */   public int pipe(int[] paramArrayOfint) {
/* 1224 */     this.m_ErrNo = JTermios.EMFILE;
/* 1225 */     return -1;
/*      */   }
/*      */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\jtermios\windows\JTermiosImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */