/*     */ package jtermios.windows;
/*     */ 
/*     */ import com.sun.jna.FromNativeContext;
/*     */ import com.sun.jna.IntegerType;
/*     */ import com.sun.jna.Library;
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.PointerType;
/*     */ import com.sun.jna.Structure;
/*     */ import com.sun.jna.WString;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import jtermios.JTermios;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WinAPI
/*     */ {
/*  95 */   static Windows_kernel32_lib m_K32lib = (Windows_kernel32_lib)Native.loadLibrary("kernel32", Windows_kernel32_lib.class);
/*     */   private static boolean TRACE = true;
/*     */   
/*     */   public static class HANDLE
/*     */     extends PointerType {
/*     */     private boolean immutable;
/*     */     
/*     */     public HANDLE() {}
/*     */     
/*     */     public HANDLE(Pointer param1Pointer) {
/* 105 */       setPointer(param1Pointer);
/* 106 */       this.immutable = true;
/*     */     }
/*     */     
/*     */     public Object fromNative(Object param1Object, FromNativeContext param1FromNativeContext) {
/* 110 */       Object object = super.fromNative(param1Object, param1FromNativeContext);
/* 111 */       if (WinAPI.NULL.equals(object))
/* 112 */         return WinAPI.NULL; 
/* 113 */       if (WinAPI.INVALID_HANDLE_VALUE.equals(object))
/* 114 */         return WinAPI.INVALID_HANDLE_VALUE; 
/* 115 */       return object;
/*     */     }
/*     */     
/*     */     public void setPointer(Pointer param1Pointer) {
/* 119 */       if (this.immutable) {
/* 120 */         throw new UnsupportedOperationException("immutable");
/*     */       }
/*     */       
/* 123 */       super.setPointer(param1Pointer);
/*     */     }
/*     */   }
/*     */   
/* 127 */   public static HANDLE INVALID_HANDLE_VALUE = new HANDLE(Pointer.createConstant((Pointer.SIZE == 8) ? -1L : 4294967295L));
/* 128 */   public static HANDLE NULL = new HANDLE(Pointer.createConstant(0));
/*     */   
/*     */   public static final int ERROR_INSUFFICIENT_BUFFER = 122;
/*     */   
/*     */   public static final int MAXDWORD = -1;
/*     */   
/*     */   public static final int STATUS_WAIT_0 = 0;
/*     */   
/*     */   public static final int STATUS_ABANDONED_WAIT_0 = 128;
/*     */   
/*     */   public static final int WAIT_ABANDONED = 128;
/*     */   
/*     */   public static final int WAIT_ABANDONED_0 = 128;
/*     */   
/*     */   public static final int WAIT_OBJECT_0 = 0;
/*     */   public static final int WAIT_FAILED = -1;
/*     */   public static final int INFINITE = -1;
/*     */   public static final int WAIT_TIMEOUT = 258;
/*     */   public static final int GENERIC_READ = -2147483648;
/*     */   public static final int GENERIC_WRITE = 1073741824;
/*     */   public static final int GENERIC_EXECUTE = 536870912;
/*     */   public static final int GENERIC_ALL = 268435456;
/*     */   public static final int CREATE_NEW = 1;
/*     */   public static final int CREATE_ALWAYS = 2;
/*     */   public static final int OPEN_EXISTING = 3;
/*     */   public static final int OPEN_ALWAYS = 4;
/*     */   public static final int TRUNCATE_EXISTING = 5;
/*     */   public static final int PURGE_TXABORT = 1;
/*     */   public static final int PURGE_RXABORT = 2;
/*     */   public static final int PURGE_TXCLEAR = 4;
/*     */   public static final int PURGE_RXCLEAR = 8;
/*     */   public static final int MS_CTS_ON = 16;
/*     */   public static final int MS_DSR_ON = 32;
/*     */   public static final int MS_RING_ON = 64;
/*     */   public static final int MS_RLSD_ON = 128;
/*     */   public static final int SETXOFF = 1;
/*     */   public static final int SETXON = 2;
/*     */   public static final int SETRTS = 3;
/*     */   public static final int CLRRTS = 4;
/*     */   public static final int SETDTR = 5;
/*     */   public static final int CLRDTR = 6;
/*     */   public static final int RESETDEV = 7;
/*     */   public static final int SETBREAK = 8;
/*     */   public static final int CLRBREAK = 9;
/*     */   public static final int FILE_FLAG_WRITE_THROUGH = -2147483648;
/*     */   public static final int FILE_FLAG_OVERLAPPED = 1073741824;
/*     */   public static final int FILE_FLAG_NO_BUFFERING = 536870912;
/*     */   public static final int FILE_FLAG_RANDOM_ACCESS = 268435456;
/*     */   public static final int FILE_FLAG_SEQUENTIAL_SCAN = 134217728;
/*     */   public static final int FILE_FLAG_DELETE_ON_CLOSE = 67108864;
/*     */   public static final int FILE_FLAG_BACKUP_SEMANTICS = 33554432;
/*     */   public static final int FILE_FLAG_POSIX_SEMANTICS = 16777216;
/*     */   public static final int FILE_FLAG_OPEN_REPARSE_POINT = 2097152;
/*     */   public static final int FILE_FLAG_OPEN_NO_RECALL = 1048576;
/*     */   public static final int FILE_FLAG_FIRST_PIPE_INSTANCE = 524288;
/*     */   public static final int ERROR_IO_INCOMPLETE = 996;
/*     */   public static final int ERROR_IO_PENDING = 997;
/*     */   public static final int ERROR_BROKEN_PIPE = 109;
/*     */   public static final int ERROR_MORE_DATA = 234;
/*     */   public static final int ERROR_FILE_NOT_FOUND = 2;
/*     */   public static final byte NOPARITY = 0;
/*     */   public static final byte ODDPARITY = 1;
/*     */   public static final byte EVENPARITY = 2;
/*     */   public static final byte MARKPARITY = 3;
/*     */   public static final byte SPACEPARITY = 4;
/*     */   public static final byte ONESTOPBIT = 0;
/*     */   public static final byte ONE5STOPBITS = 1;
/*     */   public static final byte TWOSTOPBITS = 2;
/*     */   public static final int CBR_110 = 110;
/*     */   public static final int CBR_300 = 300;
/*     */   public static final int CBR_600 = 600;
/*     */   public static final int CBR_1200 = 1200;
/*     */   public static final int CBR_2400 = 2400;
/*     */   public static final int CBR_4800 = 4800;
/*     */   public static final int CBR_9600 = 9600;
/*     */   public static final int CBR_14400 = 14400;
/*     */   public static final int CBR_19200 = 19200;
/*     */   public static final int CBR_38400 = 38400;
/*     */   public static final int CBR_56000 = 56000;
/*     */   public static final int CBR_57600 = 57600;
/*     */   public static final int CBR_115200 = 115200;
/*     */   public static final int CBR_128000 = 128000;
/*     */   public static final int CBR_256000 = 256000;
/*     */   public static final int CE_RXOVER = 1;
/*     */   public static final int CE_OVERRUN = 2;
/*     */   public static final int CE_RXPARITY = 4;
/*     */   public static final int CE_FRAME = 8;
/*     */   public static final int CE_BREAK = 16;
/*     */   public static final int CE_TXFULL = 256;
/*     */   public static final int CE_PTO = 512;
/*     */   public static final int CE_IOE = 1024;
/*     */   public static final int CE_DNS = 2048;
/*     */   public static final int CE_OOP = 4096;
/*     */   public static final int CE_MODE = 32768;
/*     */   public static final int IE_BADID = -1;
/*     */   public static final int IE_OPEN = -2;
/*     */   public static final int IE_NOPEN = -3;
/*     */   public static final int IE_MEMORY = -4;
/*     */   public static final int IE_DEFAULT = -5;
/*     */   public static final int IE_HARDWARE = -10;
/*     */   public static final int IE_BYTESIZE = -11;
/*     */   public static final int IE_BAUDRATE = -12;
/*     */   public static final int EV_RXCHAR = 1;
/*     */   public static final int EV_RXFLAG = 2;
/*     */   public static final int EV_TXEMPTY = 4;
/*     */   public static final int EV_CTS = 8;
/*     */   public static final int EV_DSR = 16;
/*     */   public static final int EV_RLSD = 32;
/*     */   public static final int EV_BREAK = 64;
/*     */   public static final int EV_ERR = 128;
/*     */   public static final int EV_RING = 256;
/*     */   public static final int EV_PERR = 512;
/*     */   public static final int EV_RX80FULL = 1024;
/*     */   public static final int EV_EVENT1 = 2048;
/*     */   public static final int EV_EVENT2 = 4096;
/*     */   public static final int FORMAT_MESSAGE_ALLOCATE_BUFFER = 256;
/*     */   public static final int FORMAT_MESSAGE_IGNORE_INSERTS = 512;
/*     */   public static final int FORMAT_MESSAGE_FROM_STRING = 1024;
/*     */   public static final int FORMAT_MESSAGE_FROM_HMODULE = 2048;
/*     */   public static final int FORMAT_MESSAGE_FROM_SYSTEM = 4096;
/*     */   public static final int FORMAT_MESSAGE_ARGUMENT_ARRAY = 8192;
/*     */   public static final int FORMAT_MESSAGE_MAX_WIDTH_MASK = 255;
/*     */   public static final int LANG_NEUTRAL = 0;
/*     */   public static final int SUBLANG_DEFAULT = 1;
/*     */   
/*     */   public static interface Windows_kernel32_lib
/*     */     extends Library
/*     */   {
/*     */     WinAPI.HANDLE CreateFileW(WString param1WString, int param1Int1, int param1Int2, WinAPI.SECURITY_ATTRIBUTES param1SECURITY_ATTRIBUTES, int param1Int3, int param1Int4, Pointer param1Pointer);
/*     */     
/*     */     WinAPI.HANDLE CreateFileA(String param1String, int param1Int1, int param1Int2, WinAPI.SECURITY_ATTRIBUTES param1SECURITY_ATTRIBUTES, int param1Int3, int param1Int4, Pointer param1Pointer);
/*     */     
/*     */     boolean WriteFile(WinAPI.HANDLE param1HANDLE, byte[] param1ArrayOfbyte, int param1Int, int[] param1ArrayOfint, Pointer param1Pointer);
/*     */     
/*     */     boolean WriteFile(WinAPI.HANDLE param1HANDLE, Pointer param1Pointer, int param1Int, int[] param1ArrayOfint, WinAPI.OVERLAPPED param1OVERLAPPED);
/*     */     
/*     */     boolean ReadFile(WinAPI.HANDLE param1HANDLE, byte[] param1ArrayOfbyte, int param1Int, int[] param1ArrayOfint, Pointer param1Pointer);
/*     */     
/*     */     boolean ReadFile(WinAPI.HANDLE param1HANDLE, Pointer param1Pointer, int param1Int, int[] param1ArrayOfint, WinAPI.OVERLAPPED param1OVERLAPPED);
/*     */     
/*     */     boolean FlushFileBuffers(WinAPI.HANDLE param1HANDLE);
/*     */     
/*     */     boolean PurgeComm(WinAPI.HANDLE param1HANDLE, int param1Int);
/*     */     
/*     */     boolean CancelIo(WinAPI.HANDLE param1HANDLE);
/*     */     
/*     */     boolean CloseHandle(WinAPI.HANDLE param1HANDLE);
/*     */     
/*     */     boolean ClearCommError(WinAPI.HANDLE param1HANDLE, int[] param1ArrayOfint, WinAPI.COMSTAT param1COMSTAT);
/*     */     
/*     */     boolean SetCommMask(WinAPI.HANDLE param1HANDLE, int param1Int);
/*     */     
/*     */     boolean GetCommMask(WinAPI.HANDLE param1HANDLE, int[] param1ArrayOfint);
/*     */     
/*     */     boolean GetCommState(WinAPI.HANDLE param1HANDLE, WinAPI.DCB param1DCB);
/*     */     
/*     */     boolean SetCommState(WinAPI.HANDLE param1HANDLE, WinAPI.DCB param1DCB);
/*     */     
/*     */     boolean SetCommTimeouts(WinAPI.HANDLE param1HANDLE, WinAPI.COMMTIMEOUTS param1COMMTIMEOUTS);
/*     */     
/*     */     boolean SetupComm(WinAPI.HANDLE param1HANDLE, int param1Int1, int param1Int2);
/*     */     
/*     */     boolean SetCommBreak(WinAPI.HANDLE param1HANDLE);
/*     */     
/*     */     boolean ClearCommBreak(WinAPI.HANDLE param1HANDLE);
/*     */     
/*     */     boolean GetCommModemStatus(WinAPI.HANDLE param1HANDLE, int[] param1ArrayOfint);
/*     */     
/*     */     boolean EscapeCommFunction(WinAPI.HANDLE param1HANDLE, int param1Int);
/*     */     
/*     */     WinAPI.HANDLE CreateEventA(WinAPI.SECURITY_ATTRIBUTES param1SECURITY_ATTRIBUTES, boolean param1Boolean1, boolean param1Boolean2, String param1String);
/*     */     
/*     */     WinAPI.HANDLE CreateEventW(WinAPI.SECURITY_ATTRIBUTES param1SECURITY_ATTRIBUTES, boolean param1Boolean1, boolean param1Boolean2, WString param1WString);
/*     */     
/*     */     boolean ResetEvent(WinAPI.HANDLE param1HANDLE);
/*     */     
/*     */     boolean SetEvent(WinAPI.HANDLE param1HANDLE);
/*     */     
/*     */     boolean WaitCommEvent(WinAPI.HANDLE param1HANDLE, IntByReference param1IntByReference, WinAPI.OVERLAPPED param1OVERLAPPED);
/*     */     
/*     */     boolean WaitCommEvent(WinAPI.HANDLE param1HANDLE, int[] param1ArrayOfint, WinAPI.OVERLAPPED param1OVERLAPPED);
/*     */     
/*     */     int WaitForSingleObject(WinAPI.HANDLE param1HANDLE, int param1Int);
/*     */     
/*     */     int WaitForMultipleObjects(int param1Int1, WinAPI.HANDLE[] param1ArrayOfHANDLE, boolean param1Boolean, int param1Int2);
/*     */     
/*     */     boolean GetOverlappedResult(WinAPI.HANDLE param1HANDLE, WinAPI.OVERLAPPED param1OVERLAPPED, int[] param1ArrayOfint, boolean param1Boolean);
/*     */     
/*     */     int GetLastError();
/*     */     
/*     */     int FormatMessageW(int param1Int1, Pointer param1Pointer1, int param1Int2, int param1Int3, Pointer param1Pointer2, int param1Int4, Pointer param1Pointer3);
/*     */     
/*     */     int QueryDosDeviceA(String param1String, byte[] param1ArrayOfbyte, int param1Int);
/*     */     
/*     */     int QueryDosDeviceW(WString param1WString, char[] param1ArrayOfchar, int param1Int);
/*     */   }
/*     */   
/*     */   public static int MAKELANGID(int paramInt1, int paramInt2) {
/* 326 */     return paramInt2 << 10 | paramInt1;
/*     */   }
/*     */   
/*     */   public static class ULONG_PTR extends IntegerType {
/*     */     public ULONG_PTR() {
/* 331 */       this(0L);
/*     */     }
/*     */     
/*     */     public ULONG_PTR(long param1Long) {
/* 335 */       super(Pointer.SIZE, param1Long);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class OVERLAPPED
/*     */     extends Structure
/*     */   {
/*     */     private static boolean TRACE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WinAPI.ULONG_PTR Internal;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WinAPI.ULONG_PTR InternalHigh;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int Offset;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int OffsetHigh;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WinAPI.HANDLE hEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected List getFieldOrder() {
/* 379 */       return Arrays.asList(new String[] { "Internal", "InternalHigh", "Offset", "OffsetHigh", "hEvent" });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public OVERLAPPED() {
/* 388 */       setAutoSynch(false);
/*     */     }
/*     */     
/*     */     public String toString() {
/* 392 */       return String.format("[Offset %d OffsetHigh %d hEvent %s]", new Object[] { Integer.valueOf(this.Offset), Integer.valueOf(this.OffsetHigh), this.hEvent.toString() });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class SECURITY_ATTRIBUTES
/*     */     extends Structure
/*     */   {
/*     */     public int nLength;
/*     */     public Pointer lpSecurityDescriptor;
/*     */     public boolean bInheritHandle;
/*     */     
/*     */     protected List getFieldOrder() {
/* 405 */       return Arrays.asList(new String[] { "nLength", "lpSecurityDescriptor", "bInheritHandle" });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class DCB
/*     */     extends Structure
/*     */   {
/*     */     public int DCBlength;
/*     */     
/*     */     public int BaudRate;
/*     */     public int fFlags;
/*     */     public static final int fBinary = 1;
/*     */     public static final int fParity = 2;
/*     */     public static final int fOutxCtsFlow = 4;
/*     */     public static final int fOutxDsrFlow = 8;
/*     */     public static final int fDtrControl = 48;
/*     */     public static final int fDsrSensitivity = 64;
/*     */     public static final int fTXContinueOnXoff = 128;
/*     */     public static final int fOutX = 256;
/*     */     public static final int fInX = 512;
/*     */     public static final int fErrorChar = 1024;
/*     */     public static final int fNull = 2048;
/*     */     public static final int fRtsControl = 12288;
/*     */     public static final int fAbortOnError = 16384;
/*     */     public static final int fDummy2 = -32768;
/*     */     public short wReserved;
/*     */     public short XonLim;
/*     */     public short XoffLim;
/*     */     public byte ByteSize;
/*     */     public byte Parity;
/*     */     public byte StopBits;
/*     */     public byte XonChar;
/*     */     public byte XoffChar;
/*     */     public byte ErrorChar;
/*     */     public byte EofChar;
/*     */     public byte EvtChar;
/*     */     public short wReserved1;
/*     */     
/*     */     protected List getFieldOrder() {
/* 445 */       return Arrays.asList(new String[] { "DCBlength", "BaudRate", "fFlags", "wReserved", "XonLim", "XoffLim", "ByteSize", "Parity", "StopBits", "XonChar", "XoffChar", "ErrorChar", "EofChar", "EvtChar", "wReserved1" });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 464 */       return String.format("[BaudRate %d fFlags %04X wReserved %d XonLim %d XoffLim %d ByteSize %d Parity %d StopBits %d XonChar %02X XoffChar %02X ErrorChar %02X EofChar %02X EvtChar %02X wReserved1 %d]", new Object[] { Integer.valueOf(this.BaudRate), Integer.valueOf(this.fFlags), Short.valueOf(this.wReserved), Short.valueOf(this.XonLim), Short.valueOf(this.XoffLim), Byte.valueOf(this.ByteSize), Byte.valueOf(this.Parity), Byte.valueOf(this.StopBits), Byte.valueOf(this.XonChar), Byte.valueOf(this.XoffChar), Byte.valueOf(this.ErrorChar), Byte.valueOf(this.EofChar), Byte.valueOf(this.EvtChar), Short.valueOf(this.wReserved1) });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class COMMTIMEOUTS
/*     */     extends Structure
/*     */   {
/*     */     public int ReadIntervalTimeout;
/*     */     
/*     */     public int ReadTotalTimeoutMultiplier;
/*     */     public int ReadTotalTimeoutConstant;
/*     */     public int WriteTotalTimeoutMultiplier;
/*     */     public int WriteTotalTimeoutConstant;
/*     */     
/*     */     protected List getFieldOrder() {
/* 480 */       return Arrays.asList(new String[] { "ReadIntervalTimeout", "ReadTotalTimeoutMultiplier", "ReadTotalTimeoutConstant", "WriteTotalTimeoutMultiplier", "WriteTotalTimeoutConstant" });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 489 */       return String.format("[ReadIntervalTimeout %d ReadTotalTimeoutMultiplier %d ReadTotalTimeoutConstant %d WriteTotalTimeoutMultiplier %d WriteTotalTimeoutConstant %d]", new Object[] { Integer.valueOf(this.ReadIntervalTimeout), Integer.valueOf(this.ReadTotalTimeoutMultiplier), Integer.valueOf(this.ReadTotalTimeoutConstant), Integer.valueOf(this.WriteTotalTimeoutMultiplier), Integer.valueOf(this.WriteTotalTimeoutConstant) });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class COMSTAT
/*     */     extends Structure
/*     */   {
/*     */     public int fFlags;
/*     */     
/*     */     public static final int fCtsHold = 1;
/*     */     public static final int fDsrHold = 2;
/*     */     public static final int fRlsdHold = 4;
/*     */     public static final int fXoffHold = 8;
/*     */     public static final int fXoffSent = 16;
/*     */     public static final int fEof = 32;
/*     */     public static final int fTxim = 64;
/*     */     public static final int fReserved = -128;
/*     */     public int cbInQue;
/*     */     public int cbOutQue;
/*     */     
/*     */     protected List getFieldOrder() {
/* 511 */       return Arrays.asList(new String[] { "fFlags", "cbInQue", "cbOutQue" });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 518 */       return String.format("[fFlags %04X cbInQue %d cbInQue %d]", new Object[] { Integer.valueOf(this.fFlags), Integer.valueOf(this.cbInQue), Integer.valueOf(this.cbOutQue) });
/*     */     }
/*     */   }
/*     */   
/*     */   public static HANDLE CreateFileA(String paramString, int paramInt1, int paramInt2, SECURITY_ATTRIBUTES paramSECURITY_ATTRIBUTES, int paramInt3, int paramInt4, Pointer paramPointer) {
/* 523 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> CreateFileA(%s, 0x%08X, 0x%08X, %s, 0x%08X, 0x%08X,%s)\n", new Object[] { paramString, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), paramSECURITY_ATTRIBUTES, Integer.valueOf(paramInt3), Integer.valueOf(paramInt4), paramPointer }));
/* 524 */     HANDLE hANDLE = m_K32lib.CreateFileA(paramString, paramInt1, paramInt2, paramSECURITY_ATTRIBUTES, paramInt3, paramInt4, paramPointer);
/* 525 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< CreateFileA(%s, 0x%08X, 0x%08X, %s, 0x%08X, 0x%08X,%s) => %s\n", new Object[] { paramString, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), paramSECURITY_ATTRIBUTES, Integer.valueOf(paramInt3), Integer.valueOf(paramInt4), paramPointer, hANDLE }));
/* 526 */     return hANDLE;
/*     */   }
/*     */   
/*     */   public static HANDLE CreateFileW(WString paramWString, int paramInt1, int paramInt2, SECURITY_ATTRIBUTES paramSECURITY_ATTRIBUTES, int paramInt3, int paramInt4, Pointer paramPointer) {
/* 530 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> CreateFileW(%s, 0x%08X, 0x%08X, %s, 0x%08X, 0x%08X,%s)\n", new Object[] { paramWString, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), paramSECURITY_ATTRIBUTES, Integer.valueOf(paramInt3), Integer.valueOf(paramInt4), paramPointer }));
/* 531 */     HANDLE hANDLE = m_K32lib.CreateFileW(paramWString, paramInt1, paramInt2, paramSECURITY_ATTRIBUTES, paramInt3, paramInt4, paramPointer);
/* 532 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< CreateFileW(%s, 0x%08X, 0x%08X, %s, 0x%08X, 0x%08X,%s) => %s\n", new Object[] { paramWString, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), paramSECURITY_ATTRIBUTES, Integer.valueOf(paramInt3), Integer.valueOf(paramInt4), paramPointer, hANDLE }));
/* 533 */     return hANDLE;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean WriteFile(HANDLE paramHANDLE, byte[] paramArrayOfbyte, int paramInt, int[] paramArrayOfint) {
/* 538 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> WriteFile(%s, %s, %d, [%d])\n", new Object[] { paramHANDLE, JTermios.JTermiosLogging.log(paramArrayOfbyte, paramInt), Integer.valueOf(paramInt), Integer.valueOf(paramArrayOfint[0]) }));
/* 539 */     boolean bool = m_K32lib.WriteFile(paramHANDLE, paramArrayOfbyte, paramInt, paramArrayOfint, (Pointer)null);
/* 540 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< WriteFile(%s, %s, %d, [%d]) => %s\n", new Object[] { paramHANDLE, JTermios.JTermiosLogging.log(paramArrayOfbyte, paramInt), Integer.valueOf(paramInt), Integer.valueOf(paramArrayOfint[0]), Boolean.valueOf(bool) }));
/* 541 */     return bool;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean WriteFile(HANDLE paramHANDLE, Pointer paramPointer, int paramInt, int[] paramArrayOfint, OVERLAPPED paramOVERLAPPED) {
/* 546 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> WriteFile(%s, %s, %d, [%d], %s)\n", new Object[] { paramHANDLE, JTermios.JTermiosLogging.log(paramPointer.getByteArray(0L, paramInt), 5), Integer.valueOf(paramInt), Integer.valueOf(paramArrayOfint[0]), JTermios.JTermiosLogging.ref(paramOVERLAPPED) }));
/* 547 */     boolean bool = m_K32lib.WriteFile(paramHANDLE, paramPointer, paramInt, paramArrayOfint, paramOVERLAPPED);
/* 548 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< WriteFile(%s, %s, %d, [%d], %s) => %s\n", new Object[] { paramHANDLE, JTermios.JTermiosLogging.log(paramPointer.getByteArray(0L, paramInt), 5), Integer.valueOf(paramInt), Integer.valueOf(paramArrayOfint[0]), JTermios.JTermiosLogging.ref(paramOVERLAPPED), Boolean.valueOf(bool) }));
/* 549 */     return bool;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean ReadFile(HANDLE paramHANDLE, byte[] paramArrayOfbyte, int paramInt, int[] paramArrayOfint) {
/* 554 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> ReadFile(%s, %s, %d, [%d])\n", new Object[] { paramHANDLE, JTermios.JTermiosLogging.log(paramArrayOfbyte, paramInt), Integer.valueOf(paramInt), Integer.valueOf(paramArrayOfint[0]) }));
/* 555 */     boolean bool = m_K32lib.ReadFile(paramHANDLE, paramArrayOfbyte, paramInt, paramArrayOfint, (Pointer)null);
/* 556 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< ReadFile(%s, %s, %d, [%d]) => %s\n", new Object[] { paramHANDLE, JTermios.JTermiosLogging.log(paramArrayOfbyte, paramInt), Integer.valueOf(paramInt), Integer.valueOf(paramArrayOfint[0]), Boolean.valueOf(bool) }));
/* 557 */     return bool;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean ReadFile(HANDLE paramHANDLE, Pointer paramPointer, int paramInt, int[] paramArrayOfint, OVERLAPPED paramOVERLAPPED) {
/* 562 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> ReadFile(%s, %s, %d, [%d], %s)\n", new Object[] { paramHANDLE, JTermios.JTermiosLogging.log(paramPointer.getByteArray(0L, paramInt), 5), Integer.valueOf(paramInt), Integer.valueOf(paramArrayOfint[0]), JTermios.JTermiosLogging.ref(paramOVERLAPPED) }));
/* 563 */     boolean bool = m_K32lib.ReadFile(paramHANDLE, paramPointer, paramInt, paramArrayOfint, paramOVERLAPPED);
/* 564 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< ReadFile(%s, %s, %d, [%d], %s) => %s\n", new Object[] { paramHANDLE, JTermios.JTermiosLogging.log(paramPointer.getByteArray(0L, paramInt), 5), Integer.valueOf(paramInt), Integer.valueOf(paramArrayOfint[0]), JTermios.JTermiosLogging.ref(paramOVERLAPPED), Boolean.valueOf(bool) }));
/* 565 */     return bool;
/*     */   }
/*     */   
/*     */   public static boolean FlushFileBuffers(HANDLE paramHANDLE) {
/* 569 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> FlushFileBuffers(%s)\n", new Object[] { paramHANDLE }));
/* 570 */     boolean bool = m_K32lib.FlushFileBuffers(paramHANDLE);
/* 571 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< FlushFileBuffers(%s) => %s\n", new Object[] { paramHANDLE, Boolean.valueOf(bool) }));
/* 572 */     return bool;
/*     */   }
/*     */   
/*     */   public static boolean PurgeComm(HANDLE paramHANDLE, int paramInt) {
/* 576 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> PurgeComm(%s,0x%08X)\n", new Object[] { paramHANDLE, Integer.valueOf(paramInt) }));
/* 577 */     boolean bool = m_K32lib.PurgeComm(paramHANDLE, paramInt);
/* 578 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< PurgeComm(%s,0x%08X) => %s\n", new Object[] { paramHANDLE, Integer.valueOf(paramInt), Boolean.valueOf(bool) }));
/* 579 */     return bool;
/*     */   }
/*     */   
/*     */   public static boolean CancelIo(HANDLE paramHANDLE) {
/* 583 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> CancelIo(%s)\n", new Object[] { paramHANDLE }));
/* 584 */     boolean bool = m_K32lib.CancelIo(paramHANDLE);
/* 585 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< CancelIo(%s) => %s\n", new Object[] { paramHANDLE, Boolean.valueOf(bool) }));
/* 586 */     return bool;
/*     */   }
/*     */   
/*     */   public static boolean CloseHandle(HANDLE paramHANDLE) {
/* 590 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> CloseHandle(%s)\n", new Object[] { paramHANDLE }));
/* 591 */     boolean bool = m_K32lib.CloseHandle(paramHANDLE);
/* 592 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< CloseHandle(%s) => %s\n", new Object[] { paramHANDLE, Boolean.valueOf(bool) }));
/* 593 */     return bool;
/*     */   }
/*     */   
/*     */   public static boolean ClearCommError(HANDLE paramHANDLE, int[] paramArrayOfint, COMSTAT paramCOMSTAT) {
/* 597 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> ClearCommError(%s, [%d], %s)\n", new Object[] { paramHANDLE, Integer.valueOf(paramArrayOfint[0]), paramCOMSTAT }));
/* 598 */     boolean bool = m_K32lib.ClearCommError(paramHANDLE, paramArrayOfint, paramCOMSTAT);
/* 599 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< ClearCommError(%s, [%d], %s) => %s\n", new Object[] { paramHANDLE, Integer.valueOf(paramArrayOfint[0]), paramCOMSTAT, Boolean.valueOf(bool) }));
/* 600 */     return bool;
/*     */   }
/*     */   
/*     */   public static boolean SetCommMask(HANDLE paramHANDLE, int paramInt) {
/* 604 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> SetCommMask(%s, 0x%08X)\n", new Object[] { paramHANDLE, Integer.valueOf(paramInt) }));
/* 605 */     boolean bool = m_K32lib.SetCommMask(paramHANDLE, paramInt);
/* 606 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< SetCommMask(%s, 0x%08X) => %s\n", new Object[] { paramHANDLE, Integer.valueOf(paramInt), Boolean.valueOf(bool) }));
/* 607 */     return bool;
/*     */   }
/*     */   
/*     */   public static boolean GetCommMask(HANDLE paramHANDLE, int[] paramArrayOfint) {
/* 611 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> GetCommMask(%s, [0x%08X])\n", new Object[] { paramHANDLE, Integer.valueOf(paramArrayOfint[0]) }));
/* 612 */     boolean bool = m_K32lib.GetCommMask(paramHANDLE, paramArrayOfint);
/* 613 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< GetCommMask(%s, [0x%08X]) => %s\n", new Object[] { paramHANDLE, Integer.valueOf(paramArrayOfint[0]), Boolean.valueOf(bool) }));
/* 614 */     return bool;
/*     */   }
/*     */   
/*     */   public static boolean GetCommState(HANDLE paramHANDLE, DCB paramDCB) {
/* 618 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> GetCommState(%s, %s)\n", new Object[] { paramHANDLE, paramDCB }));
/* 619 */     boolean bool = m_K32lib.GetCommState(paramHANDLE, paramDCB);
/* 620 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< GetCommState(%s, %s) => %s\n", new Object[] { paramHANDLE, paramDCB, Boolean.valueOf(bool) }));
/* 621 */     return bool;
/*     */   }
/*     */   
/*     */   public static boolean SetCommState(HANDLE paramHANDLE, DCB paramDCB) {
/* 625 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> SetCommState(%s, %s)\n", new Object[] { paramHANDLE, paramDCB }));
/* 626 */     boolean bool = m_K32lib.SetCommState(paramHANDLE, paramDCB);
/* 627 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< SetCommState(%s, %s) => %s\n", new Object[] { paramHANDLE, paramDCB, Boolean.valueOf(bool) }));
/* 628 */     return bool;
/*     */   }
/*     */   
/*     */   public static boolean SetCommTimeouts(HANDLE paramHANDLE, COMMTIMEOUTS paramCOMMTIMEOUTS) {
/* 632 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> SetCommTimeouts(%s, %s)\n", new Object[] { paramHANDLE, paramCOMMTIMEOUTS }));
/* 633 */     boolean bool = m_K32lib.SetCommTimeouts(paramHANDLE, paramCOMMTIMEOUTS);
/* 634 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< SetCommTimeouts(%s, %s) => %s\n", new Object[] { paramHANDLE, paramCOMMTIMEOUTS, Boolean.valueOf(bool) }));
/* 635 */     return bool;
/*     */   }
/*     */   
/*     */   public static boolean SetupComm(HANDLE paramHANDLE, int paramInt1, int paramInt2) {
/* 639 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> SetCommTimeouts(%s, %d, %d)\n", new Object[] { paramHANDLE, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }));
/* 640 */     boolean bool = m_K32lib.SetupComm(paramHANDLE, paramInt1, paramInt2);
/* 641 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< SetCommTimeouts(%s, %d, %d) => %s\n", new Object[] { paramHANDLE, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Boolean.valueOf(bool) }));
/* 642 */     return bool;
/*     */   }
/*     */   
/*     */   public static boolean SetCommBreak(HANDLE paramHANDLE) {
/* 646 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> SetCommBreak(%s)\n", new Object[] { paramHANDLE }));
/* 647 */     boolean bool = m_K32lib.SetCommBreak(paramHANDLE);
/* 648 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< SetCommBreak(%s) => %s\n", new Object[] { paramHANDLE, Boolean.valueOf(bool) }));
/* 649 */     return bool;
/*     */   }
/*     */   
/*     */   public static boolean ClearCommBreak(HANDLE paramHANDLE) {
/* 653 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> ClearCommBreak(%s)\n", new Object[] { paramHANDLE }));
/* 654 */     boolean bool = m_K32lib.ClearCommBreak(paramHANDLE);
/* 655 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< ClearCommBreak(%s) => %s\n", new Object[] { paramHANDLE, Boolean.valueOf(bool) }));
/* 656 */     return bool;
/*     */   }
/*     */   
/*     */   public static boolean GetCommModemStatus(HANDLE paramHANDLE, int[] paramArrayOfint) {
/* 660 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> GetCommModemStatus(%s,0x%08X)\n", new Object[] { paramHANDLE, Integer.valueOf(paramArrayOfint[0]) }));
/* 661 */     boolean bool = m_K32lib.GetCommModemStatus(paramHANDLE, paramArrayOfint);
/* 662 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< GetCommModemStatus(%s,0x%08X) => %s\n", new Object[] { paramHANDLE, Integer.valueOf(paramArrayOfint[0]), Boolean.valueOf(bool) }));
/* 663 */     return bool;
/*     */   }
/*     */   
/*     */   public static boolean EscapeCommFunction(HANDLE paramHANDLE, int paramInt) {
/* 667 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> EscapeCommFunction(%s,0x%08X)\n", new Object[] { paramHANDLE, Integer.valueOf(paramInt) }));
/* 668 */     boolean bool = m_K32lib.EscapeCommFunction(paramHANDLE, paramInt);
/* 669 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< EscapeCommFunction(%s,0x%08X) => %s\n", new Object[] { paramHANDLE, Integer.valueOf(paramInt), Boolean.valueOf(bool) }));
/* 670 */     return bool;
/*     */   }
/*     */   
/*     */   public static HANDLE CreateEventW(SECURITY_ATTRIBUTES paramSECURITY_ATTRIBUTES, boolean paramBoolean1, boolean paramBoolean2, WString paramWString) {
/* 674 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> CreateEventW(%s, %s, %s, %s)\n", new Object[] { JTermios.JTermiosLogging.ref(paramSECURITY_ATTRIBUTES), Boolean.valueOf(paramBoolean1), Boolean.valueOf(paramBoolean2), paramWString }));
/* 675 */     HANDLE hANDLE = m_K32lib.CreateEventW(paramSECURITY_ATTRIBUTES, paramBoolean1, paramBoolean2, paramWString);
/* 676 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< CreateEventW(%s, %s, %s, %s) => %s\n", new Object[] { JTermios.JTermiosLogging.ref(paramSECURITY_ATTRIBUTES), Boolean.valueOf(paramBoolean1), Boolean.valueOf(paramBoolean2), paramWString, hANDLE }));
/* 677 */     return hANDLE;
/*     */   }
/*     */   
/*     */   public static HANDLE CreateEventA(SECURITY_ATTRIBUTES paramSECURITY_ATTRIBUTES, boolean paramBoolean1, boolean paramBoolean2, String paramString) {
/* 681 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> CreateEventA(%s, %s, %s, %s)\n", new Object[] { JTermios.JTermiosLogging.ref(paramSECURITY_ATTRIBUTES), Boolean.valueOf(paramBoolean1), Boolean.valueOf(paramBoolean2), paramString }));
/* 682 */     HANDLE hANDLE = m_K32lib.CreateEventA(paramSECURITY_ATTRIBUTES, paramBoolean1, paramBoolean2, paramString);
/* 683 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< CreateEventA(%s, %s, %s, %s) => %s\n", new Object[] { JTermios.JTermiosLogging.ref(paramSECURITY_ATTRIBUTES), Boolean.valueOf(paramBoolean1), Boolean.valueOf(paramBoolean2), paramString, hANDLE }));
/* 684 */     return hANDLE;
/*     */   }
/*     */   
/*     */   public static boolean SetEvent(HANDLE paramHANDLE) {
/* 688 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> SetEvent(%s)\n", new Object[] { paramHANDLE }));
/* 689 */     boolean bool = m_K32lib.SetEvent(paramHANDLE);
/* 690 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< SetEvent(%s) => %s\n", new Object[] { paramHANDLE, Boolean.valueOf(bool) }));
/* 691 */     return bool;
/*     */   }
/*     */   
/*     */   public static boolean ResetEvent(HANDLE paramHANDLE) {
/* 695 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> ResetEvent(%s)\n", new Object[] { paramHANDLE }));
/* 696 */     boolean bool = m_K32lib.ResetEvent(paramHANDLE);
/* 697 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< ResetEvent(%s) => %s\n", new Object[] { paramHANDLE, Boolean.valueOf(bool) }));
/* 698 */     return bool;
/*     */   }
/*     */   
/*     */   public static boolean WaitCommEvent(HANDLE paramHANDLE, IntByReference paramIntByReference, OVERLAPPED paramOVERLAPPED) {
/* 702 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> WaitCommEvent(%s, [%d], %s)\n", new Object[] { paramHANDLE, Integer.valueOf(paramIntByReference.getValue()), JTermios.JTermiosLogging.ref(paramOVERLAPPED) }));
/* 703 */     boolean bool = m_K32lib.WaitCommEvent(paramHANDLE, paramIntByReference, paramOVERLAPPED);
/* 704 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< WaitCommEvent(%s, [%d], %s) => %s\n", new Object[] { paramHANDLE, Integer.valueOf(paramIntByReference.getValue()), JTermios.JTermiosLogging.ref(paramOVERLAPPED), Boolean.valueOf(bool) }));
/* 705 */     return bool;
/*     */   }
/*     */   
/*     */   public static boolean WaitCommEvent(HANDLE paramHANDLE, int[] paramArrayOfint) {
/* 709 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> WaitCommEvent(%s, [%d], %s) => %s\n", new Object[] { paramHANDLE, Integer.valueOf(paramArrayOfint[0]), null }));
/* 710 */     boolean bool = m_K32lib.WaitCommEvent(paramHANDLE, paramArrayOfint, (OVERLAPPED)null);
/* 711 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< WaitCommEvent(%s, [%d], %s) => %s\n", new Object[] { paramHANDLE, Integer.valueOf(paramArrayOfint[0]), null, Boolean.valueOf(bool) }));
/* 712 */     return bool;
/*     */   }
/*     */   
/*     */   public static int WaitForSingleObject(HANDLE paramHANDLE, int paramInt) {
/* 716 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> WaitForSingleObject(%s, %d)\n", new Object[] { paramHANDLE, Integer.valueOf(paramInt) }));
/* 717 */     int i = m_K32lib.WaitForSingleObject(paramHANDLE, paramInt);
/* 718 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< WaitForSingleObject(%s, %d) => %s\n", new Object[] { paramHANDLE, Integer.valueOf(paramInt), Integer.valueOf(i) }));
/* 719 */     return i;
/*     */   }
/*     */   
/*     */   public static int WaitForMultipleObjects(int paramInt1, HANDLE[] paramArrayOfHANDLE, boolean paramBoolean, int paramInt2) {
/* 723 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> WaitForMultipleObjects(%d, %s, %s, %d)\n", new Object[] { Integer.valueOf(paramInt1), JTermios.JTermiosLogging.log((Object[])paramArrayOfHANDLE, 3), Boolean.valueOf(paramBoolean), Integer.valueOf(paramInt2) }));
/* 724 */     int i = m_K32lib.WaitForMultipleObjects(paramInt1, paramArrayOfHANDLE, paramBoolean, paramInt2);
/* 725 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< WaitForMultipleObjects(%d, %s, %s, %d) => %s\n", new Object[] { Integer.valueOf(paramInt1), JTermios.JTermiosLogging.log((Object[])paramArrayOfHANDLE, 3), Boolean.valueOf(paramBoolean), Integer.valueOf(paramInt2), Integer.valueOf(i) }));
/* 726 */     return i;
/*     */   }
/*     */   
/*     */   public static boolean GetOverlappedResult(HANDLE paramHANDLE, OVERLAPPED paramOVERLAPPED, int[] paramArrayOfint, boolean paramBoolean) {
/* 730 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> GetOverlappedResult(%s, %s, [%d], %s)\n", new Object[] { paramHANDLE, JTermios.JTermiosLogging.ref(paramOVERLAPPED), Integer.valueOf(paramArrayOfint[0]), Boolean.valueOf(paramBoolean) }));
/* 731 */     boolean bool = m_K32lib.GetOverlappedResult(paramHANDLE, paramOVERLAPPED, paramArrayOfint, paramBoolean);
/* 732 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< GetOverlappedResult(%s, %s, [%d], %s) => %s\n", new Object[] { paramHANDLE, JTermios.JTermiosLogging.ref(paramOVERLAPPED), Integer.valueOf(paramArrayOfint[0]), Boolean.valueOf(paramBoolean), Boolean.valueOf(bool) }));
/* 733 */     return bool;
/*     */   }
/*     */   
/*     */   public static int GetLastError() {
/* 737 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> GetLastError()\n", new Object[0]));
/* 738 */     int i = m_K32lib.GetLastError();
/* 739 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< GetLastError() => %d\n", new Object[] { Integer.valueOf(i) }));
/* 740 */     return i;
/*     */   }
/*     */   
/*     */   public static int FormatMessageW(int paramInt1, Pointer paramPointer1, int paramInt2, int paramInt3, Pointer paramPointer2, int paramInt4, Pointer paramPointer3) {
/* 744 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> FormatMessageW(%08x, %08x, %d, %d, %s, %d, %s)\n", new Object[] { Integer.valueOf(paramInt1), paramPointer1, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), paramPointer2, Integer.valueOf(paramInt4), paramPointer3 }));
/* 745 */     int i = m_K32lib.FormatMessageW(paramInt1, paramPointer1, paramInt2, paramInt3, paramPointer2, paramInt4, paramPointer3);
/* 746 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< FormatMessageW(%08x, %08x, %d, %d, %s, %d, %s) => %d\n", new Object[] { Integer.valueOf(paramInt1), paramPointer1, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), paramPointer2, Integer.valueOf(paramInt4), paramPointer3, Integer.valueOf(i) }));
/* 747 */     return i;
/*     */   }
/*     */   
/*     */   public static int QueryDosDeviceA(String paramString, byte[] paramArrayOfbyte, int paramInt) {
/* 751 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> QueryDosDeviceA(%s, %s, %d)\n", new Object[] { paramString, paramArrayOfbyte, Integer.valueOf(paramInt) }));
/* 752 */     int i = m_K32lib.QueryDosDeviceA(paramString, paramArrayOfbyte, paramInt);
/* 753 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< QueryDosDeviceA(%s, %s, %d) => %d\n", new Object[] { paramString, paramArrayOfbyte, Integer.valueOf(paramInt), Integer.valueOf(i) }));
/* 754 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int QueryDosDeviceW(WString paramWString, char[] paramArrayOfchar, int paramInt) {
/* 760 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(5, "> QueryDosDeviceW(%s,%s,%d)\n", new Object[] { paramWString, paramArrayOfchar, Integer.valueOf(paramInt) }));
/* 761 */     int i = m_K32lib.QueryDosDeviceW(paramWString, paramArrayOfchar, paramInt);
/* 762 */     JTermios.JTermiosLogging.log = (JTermios.JTermiosLogging.log && JTermios.JTermiosLogging.log(4, "< QueryDosDeviceW(%s,%s,%d) => %d\n", new Object[] { paramWString, paramArrayOfchar, Integer.valueOf(paramInt), Integer.valueOf(i) }));
/* 763 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\Bun\Downloads\cloud-shell.jar!\BOOT-INF\lib\purejavacomm-0.0.11.1.jar!\jtermios\windows\WinAPI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */